function params_lb = updateResults(params, k, params_lb, handles)

% Params lb ci permette di avere informazioni sulla tipologia di analisi
% che si sceglie di fare: contiene 0 in corrispondenza dei parametri che
% non appartegono all'analisi

[num_p, ind_p] = find(params_lb ~= 0);
[c, ind_k] = find(k ~=0);
[d, f] =ismember(ind_k,ind_p);
index = ind_p;
index(f) = [];
params_lb(index) = params;
params_lb(ind_k) = k(ind_k);
handles.a = num2str(params_lb(1));
handles.b = num2str(params_lb(2));
handles.c = num2str(params_lb(3));
handles.d = num2str(params_lb(4));
handles.Td = num2str(params_lb(5));
handles.Cs0 = num2str(params_lb(6));
handles.Cc0 = num2str(params_lb(7));
handles.Kc0 = num2str(params_lb(8));
handles.t = num2str(params_lb(9));
if length(num_p) == 5 % Modello solo troponina
    
    set(handles.cRText,'Visible','off');
    set(handles.dRText,'Visible','off');
    set(handles.Kc0RText,'Visible','off');
    set(handles.tRText,'Visible','off');
    set(handles.aRText, 'Visible','on');
    set(handles.bRText, 'Visible','on');
    set(handles.TdRText, 'Visible','on');
    set(handles.Cs0RText, 'Visible','on');
    set(handles.Cc0RText, 'Visible','on');
    
    set(handles.aRText, 'String', num2str(params_lb(1)));
    set(handles.bRText, 'String', num2str(params_lb(2)));
    set(handles.TdRText, 'String', num2str(params_lb(5)));
    set(handles.Cs0RText, 'String', num2str(params_lb(6)));
    set(handles.Cc0RText, 'String', num2str(params_lb(7)));

elseif length(num_p) == 8
    set(handles.cRText,'Visible','on');
    set(handles.dRText,'Visible','on');
    set(handles.Kc0RText,'Visible','on');
    set(handles.tRText,'Visible','off');
    set(handles.aRText, 'Visible','on');
    set(handles.bRText, 'Visible','on');
    set(handles.TdRText, 'Visible','on');
    set(handles.Cs0RText, 'Visible','on');
    set(handles.Cc0RText, 'Visible','on');
    
    set(handles.aRText, 'String', num2str(params_lb(1)));
    set(handles.bRText, 'String', num2str(params_lb(2)));
    set(handles.TdRText, 'String', num2str(params_lb(5)));
    set(handles.Cs0RText, 'String', num2str(params_lb(6)));
    set(handles.Cc0RText, 'String', num2str(params_lb(7)));   
    set(handles.cRText, 'String', num2str(params_lb(3)));
    set(handles.dRText, 'String', num2str(params_lb(4)));
    set(handles.Kc0RText, 'String', num2str(params_lb(8)));  
else
    
    set(handles.cRText,'Visible','off');
    set(handles.dRText,'Visible','off');
    set(handles.Kc0RText,'Visible','off');
    set(handles.tRText,'Visible','on');
    set(handles.aRText, 'Visible','on');
    set(handles.bRText, 'Visible','on');
    set(handles.TdRText, 'Visible','on');
    set(handles.Cs0RText, 'Visible','on');
    set(handles.Cc0RText, 'Visible','on');
    
    set(handles.aRText, 'String', num2str(params_lb(1)));
    set(handles.bRText, 'String', num2str(params_lb(2)));
    set(handles.TdRText, 'String', num2str(params_lb(5)));
    set(handles.Cs0RText, 'String', num2str(params_lb(6)));
    set(handles.Cc0RText, 'String', num2str(params_lb(7)));
    set(handles.tRText, 'String', num2str(params_lb(9)));
    
end
