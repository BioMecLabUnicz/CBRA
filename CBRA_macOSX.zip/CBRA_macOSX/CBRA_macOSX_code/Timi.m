function varargout = Timi(varargin)
% TIMI MATLAB code for Timi.fig
%      TIMI, by itself, creates a new TIMI or raises the existing
%      singleton*.
%
%      H = TIMI returns the handle to a new TIMI or the handle to
%      the existing singleton*.
%
%      TIMI('CALLBACK',hObject,eventData,handles,...) calls the local
%      function named CALLBACK in TIMI.M with the given input arguments.
%
%      TIMI('Property','Value',...) creates a new TIMI or raises the
%      existing singleton*.  Starting from the left, property value pairs are
%      applied to the GUI before Timi_OpeningFcn gets called.  An
%      unrecognized property name or invalid value makes property application
%      stop.  All inputs are passed to Timi_OpeningFcn via varargin.
%
%      *See GUI Options on GUIDE's Tools menu.  Choose "GUI allows only one
%      instance to run (singleton)".
%
% See also: GUIDE, GUIDATA, GUIHANDLES

% Edit the above text to modify the response to help Timi

% Last Modified by GUIDE v2.5 30-Sep-2020 13:33:29

% Begin initialization code - DO NOT EDIT
gui_Singleton = 1;
gui_State = struct('gui_Name',       mfilename, ...
                   'gui_Singleton',  gui_Singleton, ...
                   'gui_OpeningFcn', @Timi_OpeningFcn, ...
                   'gui_OutputFcn',  @Timi_OutputFcn, ...
                   'gui_LayoutFcn',  [] , ...
                   'gui_Callback',   []);
if nargin && ischar(varargin{1})
    gui_State.gui_Callback = str2func(varargin{1});
end

if nargout
    [varargout{1:nargout}] = gui_mainfcn(gui_State, varargin{:});
else
    gui_mainfcn(gui_State, varargin{:});
end
% End initialization code - DO NOT EDIT


% --- Executes just before Timi is made visible.
function Timi_OpeningFcn(hObject, eventdata, handles, varargin)
% This function has no output args, see OutputFcn.
% hObject    handle to figure
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
% varargin   command line arguments to Timi (see VARARGIN)

dbname = 'Biomarcatore';

% Username and Password per accedere al DB
username = 'root';
password = 'root';

% Specifichiamo la tipologia di driver utilizzato
driver = 'com.mysql.jdbc.Driver';

% Specifichiamo l'inidrizzo
dburl = 'jdbc:mysql://localhost:3306/Biomarcatore'; %/useSSL=false&? 
% useSSL=true and verifyServerCertificate=false Perch? su php ssl variables
% risultano DISABLED


% Modifichiamo il classpath 
%currentFolder = pwd;
%path_driver = strcat(currentFolder, '/mysql-connector-java-5.0.8/mysql-connector-java-5.0.8-bin.jar');
%javaclasspath(path_driver);

% Effettuiamo la connessione
handles.conn = database(dbname, username, password, driver, dburl);


% Settiamo i pulsanti a 0

set(handles.Age65, 'value', 0);
set(handles.Age6574, 'value', 0);
set(handles.Age74, 'value', 0);

set(handles.DMyes, 'value', 0);
set(handles.DMNo, 'value', 0);

set(handles.SBP100, 'value', 0);
set(handles.SBP, 'value', 0);

set(handles.HR100, 'value', 0);
set(handles.HR, 'value', 0);

set(handles.Killip24, 'value', 0);
set(handles.Killip, 'value', 0);

set(handles.W67, 'value', 0);
set(handles.W, 'value', 0);

set(handles.LBBByes, 'value', 0);
set(handles.LBBBNo, 'value', 0);

set(handles.Trx4, 'value', 0);
set(handles.Trx, 'value', 0);

set(handles.save, 'visible', 'off');
set(handles.reset, 'visible', 'off');

% Choose default command line output for Timi
handles.output = hObject;

% Update handles structure
guidata(hObject, handles);

% UIWAIT makes Timi wait for user response (see UIRESUME)
% uiwait(handles.figure1);


% --- Outputs from this function are returned to the command line.
function varargout = Timi_OutputFcn(hObject, eventdata, handles) 
% varargout  cell array for returning output args (see VARARGOUT);
% hObject    handle to figure
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Get default command line output from handles structure
varargout{1} = handles.output;


% --- Executes on button press in timiCompute.
function timiCompute_Callback(hObject, eventdata, handles)
% hObject    handle to timiCompute (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

timiscore = 0;

Agecontr = get(handles.Age6574, 'Value') + get(handles.Age65, 'Value') + get(handles.Age74, 'Value');
Dmcontr = get(handles.DMyes, 'Value') + get(handles.DMNo, 'Value');
Hrcontr = get(handles.HR100, 'Value') + get(handles.HR, 'Value');
Killipcontr = get(handles.Killip24, 'Value') + get(handles.Killip, 'Value');
Wcontr = get(handles.W67, 'Value') + get(handles.W, 'Value');
T4hcontr = get(handles.Trx4, 'Value') + get(handles.Trx, 'Value');
STLBBcontr = get(handles.LBBByes, 'Value') + get(handles.LBBBNo, 'Value');
SBPcontr = get(handles.SBP100, 'Value') + get(handles.SBP, 'Value');

if Agecontr == 0
    set(handles.agepanel, 'ShadowColor', 'red');
else
    set(handles.agepanel, 'ShadowColor', [0.7 0.7 0.7]);    
end
if Dmcontr == 0
    set(handles.dmpanel, 'ShadowColor', 'red');
else
    set(handles.dmpanel, 'ShadowColor', [0.7 0.7 0.7]);    
end
if Hrcontr == 0
    set(handles.hrpanel, 'ShadowColor', 'red');
else
    set(handles.hrpanel, 'ShadowColor', [0.7 0.7 0.7]);  
end
if Killipcontr == 0
    set(handles.klpanel, 'ShadowColor', 'red');
else
    set(handles.klpanel, 'ShadowColor', [0.7 0.7 0.7]);  
end
if Wcontr == 0
    set(handles.wpanel, 'ShadowColor', 'red');
else
    set(handles.wpanel, 'ShadowColor', [0.7 0.7 0.7]);     
end
if T4hcontr == 0
    set(handles.t4panel, 'ShadowColor', 'red');
else
    set(handles.t4panel, 'ShadowColor', [0.7 0.7 0.7]);      
end
if STLBBcontr == 0
    set(handles.stlbbbpanel, 'ShadowColor', 'red');
else
    set(handles.stlbbbpanel, 'ShadowColor', [0.7 0.7 0.7]);     
end
if SBPcontr == 0
    set(handles.sbppanel, 'ShadowColor', 'red');
else
    set(handles.sbppanel, 'ShadowColor', [0.7 0.7 0.7]);      
end

control = [Agecontr Dmcontr Hrcontr Killipcontr Wcontr T4hcontr STLBBcontr SBPcontr];

if length(find(control == 0)) == 0

    if get(handles.Age6574, 'Value') == 1
        timiscore = timiscore +2;
    elseif get(handles.Age74, 'Value') == 1
        timiscore = timiscore +3;
    end

    DM_H_A = 0;

    if get(handles.DMyes, 'Value') == 1
        timiscore = timiscore +1;
        DM_H_A = 1;
    end

    Hr = 0;

    if get(handles.HR100, 'Value') == 1
        timiscore = timiscore +2;
        Hr = 1;
    end

    Killip = 0;

    if get(handles.Killip24, 'Value') == 1
        timiscore = timiscore +2;
        Killip = 1;
    end

    W = 0;

    if get(handles.W67, 'Value') == 1
        timiscore = timiscore +1;
        W = 1;
    end

    T4h = 0;

    if get(handles.Trx4, 'Value') == 1
        timiscore = timiscore +1;
        T4h = 1;
    end

    STLBB = 0;

    if get(handles.LBBByes, 'Value') == 1
        timiscore = timiscore +1;
        STLBB = 1;
    end

    SBP = 0;

    if get(handles.SBP100, 'Value') == 1
        timiscore = timiscore +3;
        SBP = 1;
    end


    if timiscore == 0    
        set(handles.TimiText, 'String', 'Timi Score = 0. 0.8% risk of all-cause mortality at 30 days.');
    elseif timiscore == 1
        set(handles.TimiText, 'String', 'Timi Score = 1. 1.6% risk of all-cause mortality at 30 days.');
    elseif timiscore == 2
        set(handles.TimiText, 'String', 'Timi Score = 2. 2.2% risk of all-cause mortality at 30 days.');
    elseif timiscore == 3
        set(handles.TimiText, 'String', 'Timi Score = 3. 4.4% risk of all-cause mortality at 30 days.');
    elseif timiscore == 4
        set(handles.TimiText, 'String', 'Timi Score = 4. 7.3% risk of all-cause mortality at 30 days.');
    elseif timiscore == 5
        set(handles.TimiText, 'String', 'Timi Score = 5. 12.4% risk of all-cause mortality at 30 days.');
    elseif timiscore == 6
        set(handles.TimiText, 'String', 'Timi Score = 6. 16.1% risk of all-cause mortality at 30 days.');
    elseif timiscore == 7
        set(handles.TimiText, 'String', 'Timi Score = 7. 23.4% risk of all-cause mortality at 30 days.');
    elseif timiscore == 8
        set(handles.TimiText, 'String', 'Timi Score = 8. 26.8% risk of all-cause mortality at 30 days.');
    elseif timiscore >= 9
        set(handles.TimiText, 'String', 'Timi Score >= 9. 35.9% risk of all-cause mortality at 30 days.');    
    end


    handles.DM_H_Ad = DM_H_A;
    handles.Hrd = Hr;
    handles.Killipd = Killip;
    handles.Wd = W;
    handles.T4hd = T4h;
    handles.STLBBd = STLBB;
    handles.SBPd = SBP;
    handles.timiscore = timiscore;
    handles.message = get(handles.TimiText, 'String');

    set(handles.TimiText, 'visible', 'on');
    set(handles.save, 'visible', 'on');
    set(handles.reset, 'visible', 'on');
else
    set(handles.TimiText,'String', 'Please fill out required fields');
    set(handles.TimiText, 'visible', 'on');
end

guidata(hObject, handles);


% --- Executes on button press in save.
function save_Callback(hObject, eventdata, handles)
% hObject    handle to save (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
global sel_pat;
tablename = 'Timi';
colnames= {'CF','DM_H_A','Hr','Killip','W','T4h','STLBB','timiscore','SBP','message'};
insertdata_array={sel_pat, handles.DM_H_Ad, handles.Hrd, handles.Killipd, handles.Wd, handles.T4hd, handles.STLBBd, handles.timiscore, handles.SBPd, handles.message};
insertdata = cell2table(insertdata_array, 'VariableNames', colnames);
fastinsert(handles.conn,tablename,colnames,insertdata);

set(handles.save, 'ForegroundColor', 'green');

pause(2)
closereq;

%guidata(hObject, handles);


% --- Executes on button press in reset.
function reset_Callback(hObject, eventdata, handles)
% hObject    handle to reset (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
% Settiamo i pulsanti a 0

set(handles.Age65, 'value', 0);
set(handles.Age6574, 'value', 0);
set(handles.Age74, 'value', 0);

set(handles.DMyes, 'value', 0);
set(handles.DMNo, 'value', 0);

set(handles.SBP100, 'value', 0);
set(handles.SBP, 'value', 0);

set(handles.HR100, 'value', 0);
set(handles.HR, 'value', 0);

set(handles.Killip24, 'value', 0);
set(handles.Killip, 'value', 0);

set(handles.W67, 'value', 0);
set(handles.W, 'value', 0);

set(handles.LBBByes, 'value', 0);
set(handles.LBBBNo, 'value', 0);

set(handles.Trx4, 'value', 0);
set(handles.Trx, 'value', 0);

set(handles.save, 'visible', 'off');
set(handles.reset, 'visible', 'off');

handles.DM_H_Ad = 0;
handles.Hrd = 0;
handles.Killipd = 0;
handles.Wd = 0;
handles.T4hd = 0;
handles.STLBBd = 0;
handles.SBPd = 0;
handles.timiscore = 0;



set(handles.agepanel, 'ShadowColor', [0.7 0.7 0.7]);  
set(handles.dmpanel, 'ShadowColor', [0.7 0.7 0.7]);  
set(handles.hrpanel, 'ShadowColor', [0.7 0.7 0.7]);  
set(handles.klpanel, 'ShadowColor', [0.7 0.7 0.7]);  
set(handles.wpanel, 'ShadowColor', [0.7 0.7 0.7]);  
set(handles.t4panel, 'ShadowColor', [0.7 0.7 0.7]);  
set(handles.stlbbbpanel, 'ShadowColor', [0.7 0.7 0.7]);  
set(handles.sbppanel, 'ShadowColor', [0.7 0.7 0.7]);  




set(handles.TimiText, 'visible', 'off');
set(handles.save, 'visible', 'off');
guidata(hObject, handles);
