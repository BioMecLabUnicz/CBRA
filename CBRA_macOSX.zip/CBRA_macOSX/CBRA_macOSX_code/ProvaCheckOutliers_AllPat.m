%load Dataset
load('exp_data_modif.mat')
Dataset = exp_data;
figure
hold on

for i = 1 : 40
    
    %troponina = Dataset(i).ctnt;
    %tempo = Dataset(i).tempo;
    troponina = Dataset.stemi.paziente(i).valore;
    tempo = Dataset.stemi.paziente(i).tempo;
    
    [index] = FindOutliers(troponina);
    f = ceil(i/10);
    subplot(4,10,i)
    plot(tempo, troponina, 'b*')
    hold on
    plot(tempo(index), troponina(index), 'ro')
end

