function ANR = ANRCom(y_meas, y_est)
    
    ANR = sum(sqrt(((y_meas - y_est).^2)./(y_est .^2)))/length(y_meas);

end