function varargout = OutliersDetection(varargin)
% OUTLIERSDETECTION MATLAB code for OutliersDetection.fig
%      OUTLIERSDETECTION, by itself, creates a new OUTLIERSDETECTION or raises the existing
%      singleton*.
%
%      H = OUTLIERSDETECTION returns the handle to a new OUTLIERSDETECTION or the handle to
%      the existing singleton*.
%
%      OUTLIERSDETECTION('CALLBACK',hObject,eventData,handles,...) calls the local
%      function named CALLBACK in OUTLIERSDETECTION.M with the given input arguments.
%
%      OUTLIERSDETECTION('Property','Value',...) creates a new OUTLIERSDETECTION or raises the
%      existing singleton*.  Starting from the left, property value pairs are
%      applied to the GUI before OutliersDetection_OpeningFcn gets called.  An
%      unrecognized property name or invalid value makes property application
%      stop.  All inputs are passed to OutliersDetection_OpeningFcn via varargin.
%
%      *See GUI Options on GUIDE's Tools menu.  Choose "GUI allows only one
%      instance to run (singleton)".
%
% See also: GUIDE, GUIDATA, GUIHANDLES

% Edit the above text to modify the response to help OutliersDetection

% Last Modified by GUIDE v2.5 29-Jun-2020 15:30:41

% Begin initialization code - DO NOT EDIT
gui_Singleton = 1;
gui_State = struct('gui_Name',       mfilename, ...
                   'gui_Singleton',  gui_Singleton, ...
                   'gui_OpeningFcn', @OutliersDetection_OpeningFcn, ...
                   'gui_OutputFcn',  @OutliersDetection_OutputFcn, ...
                   'gui_LayoutFcn',  [] , ...
                   'gui_Callback',   []);
if nargin && ischar(varargin{1})
    gui_State.gui_Callback = str2func(varargin{1});
end

if nargout
    [varargout{1:nargout}] = gui_mainfcn(gui_State, varargin{:});
else
    gui_mainfcn(gui_State, varargin{:});
end
% End initialization code - DO NOT EDIT


% --- Executes just before OutliersDetection is made visible.
function OutliersDetection_OpeningFcn(hObject, eventdata, handles, varargin)
% This function has no output args, see OutputFcn.
% hObject    handle to figure
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
% varargin   command line arguments to OutliersDetection (see VARARGIN)

global selectPat

handles.output = hObject;
set(handles.output, 'WindowStyle', 'docked')

% Recovering Data
recoveringVector = selectPat.troponina;
recoveringVectorTime = selectPat.tempi;

%% Display Value
set(handles.NameText, 'String', selectPat.nome);
set(handles.UserNameText, 'String', selectPat.cognome);
set(handles.IDPatText, 'String',selectPat.CF);

assignin('base', 'selectPat', selectPat)
set(handles.cTnTAcquisitionsText, 'String', num2str(selectPat.troponina));
set(handles.TimeAcquisitionsText, 'String', num2str(selectPat.tempi'));

%% Plot Results
axes(handles.axes1)
plot(selectPat.tempi', selectPat.troponina', 'b*','MarkerSize', 10) 
xlabel('Time [h]', 'Interpreter', 'latex', 'FontSize', 15)
ylabel('cTnT [ng/ml]', 'Interpreter', 'latex', 'FontSize', 15)
legend({'cTnT'}, 'Interpreter', 'latex', 'FontSize', 15)
title('cTnT', 'Interpreter', 'latex', 'FontSize', 15)
set(handles.axes1,'FontSize',15)
set(handles.axes1,'TickLabelInterpreter','latex')
grid on
dcm_obj = datacursormode(gcf);
grid on
set(dcm_obj,'UpdateFcn',@myupdatefcn)

handles.vector = selectPat.troponina;
handles.time = selectPat.tempi';
handles.recoveringVector = recoveringVector;
handles.recoveringVectorTime = recoveringVectorTime;
handles.Outliers = [];
handles.timeOutliers = [];
handles.deleteV = [];
handles.deleteT = [];
handles.deleteIndex = [];
handles.recoveringOutliers = [];
handles.recoveringTimeOutliers = [];
% Choose default command line output for OutliersDetection
handles.output = hObject;

% Update handles structure
guidata(hObject, handles);

% UIWAIT makes OutliersDetection wait for user response (see UIRESUME)
% uiwait(handles.figure1);


% --- Outputs from this function are returned to the command line.
function varargout = OutliersDetection_OutputFcn(hObject, eventdata, handles) 
% varargout  cell array for returning output args (see VARARGOUT);
% hObject    handle to figure
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Get default command line output from handles structure
varargout{1} = handles.output;


% --- Executes on button press in CheckOutliersButton.
function CheckOutliersButton_Callback(hObject, eventdata, handles)
% hObject    handle to CheckOutliersButton (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
global selectPat

[index] = FindOutliers(handles.vector);
if isempty(index) ~= 1
    Outliers = handles.vector(index);
    timeOutliers = handles.time(index);

%% Recovering Data
    recoveringOutliers = Outliers;
    recoveringTimeOutliers = timeOutliers;

    handles.recoveringOutliers = recoveringOutliers;
    handles.recoveringTimeOutliers = recoveringTimeOutliers;
    handles.Outliers = Outliers;
    handles.timeOutliers = timeOutliers;
    
    
% INSERT FUNCTION OUTLIERS DETECTION


%% Show Outliers
    cla(handles.axes1)
    axes(handles.axes1)
    plot(handles.time, handles.vector, 'b*','MarkerSize', 10) 
    xlabel('Time [h]', 'Interpreter', 'latex', 'FontSize', 15)
    ylabel('cTnT [ng/ml]', 'Interpreter', 'latex', 'FontSize', 15)
    title('cTnT', 'Interpreter', 'latex', 'FontSize', 15)
    set(handles.axes1,'FontSize',15)
    set(handles.axes1,'TickLabelInterpreter','latex')
    grid on
    hold on
    plot(timeOutliers, Outliers, 'g*', 'MarkerSize', 15)
    legend({'Original Data', 'Possible Outliers'} , 'Interpreter', 'latex', 'FontSize', 15)
    hold off
else
    set(handles.OutlierCheckText, 'String', 'No Outliers Found')
end
% Update handles structure
guidata(hObject, handles);


% --- Executes on button press in ShowDetailsButton.
function ShowDetailsButton_Callback(hObject, eventdata, handles)
% hObject    handle to ShowDetailsButton (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

time = handles.time;
vector = handles.vector;
Outliers = handles.Outliers;
%% Initialized Variable

CurrentcTnTLevel = [];
CurrentTime = [];
CurrentIndex = [];
index_outliers = [];


%% Check current Point on Plot

ax = gca;
CurrentcTnTLevel = (ax.CurrentPoint(1,2));
CurrentTime = (ax.CurrentPoint(1,1));

i = find(time > CurrentTime-2 & time< CurrentTime+2);

%% Display Value

set(handles.PossibleOutlierText, 'String', num2str(vector(i)));
set(handles.TimeText, 'String', num2str(time(i)));

handles.CurrentcTnTLevel = vector(i);
handles.CurrentTime = time(i);

%% Index identification

handles.CurrentIndex = i;

%% Check on Outliers Vector

indexOutliers = find(Outliers == vector(i));

if length(indexOutliers) == 0
    set(handles.OutlierCheckText, 'String', 'Value not identified as outlier');
else
    set(handles.OutlierCheckText, 'String', 'Value identified as outlier');
end

handles.indexOutliers = indexOutliers;
%% Plot Data

[itpa, itsa] = UpdateIntervalTime(handles);

set(handles.cTnTEdit, 'String', num2str(vector(i)));
set(handles.TimeEdit, 'String', num2str(time(i)));

handles.itpa = itpa;
handles.itsa = itsa;

% Update handles structure
guidata(hObject, handles);



% % --- Executes on button press in SaveButton.
% function SaveButton_Callback(hObject, eventdata, handles)
% % hObject    handle to SaveButton (see GCBO)
% % eventdata  reserved - to be defined in a future version of MATLAB
% % handles    structure with handles and user data (see GUIDATA)
% 
% vector = handles.vector;
% time = handles.time;
% 
% Outliers = handels.Outliers;
% timeOutliers = handles.timeOutliers;
% 
% % Update handles structure
% guidata(hObject, handles);
% 
% %--- Executes on button press in RecoveringButton.
% function RecoveringButton_Callback(hObject, eventdata, handles)
% % hObject    handle to RecoveringButton (see GCBO)
% % eventdata  reserved - to be defined in a future version of MATLAB
% % handles    structure with handles and user data (see GUIDATA)
% % Update handles structure
% 
% vector = handles.recoveringVector;
% time = handles.recoveringVectorTime;
% 
% Outliers = handles.recoveringOutliers;
% timeOutliers = handles.recoveringTimeOutliers;
% 
% 
% set(handles.cTnTAcquisitionsText, 'String', num2str(vector));
% set(handles.TimeAcquisitionsText, 'String', num2str(time));
% 
% guidata(hObject, handles);

% --- Executes on button press in ClearButton.
function ClearButton_Callback(hObject, eventdata, handles)
% hObject    handle to ClearButton (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

recoveringOutliers = handles.recoveringOutliers;
recoveringTimeOutliers = handles.recoveringTimeOutliers;

recoveringValue = handles.recoveringVector;
recoveringVectorTime = handles.recoveringVectorTime;

% Clear axses
if length(recoveringOutliers) ~=0
    cla(handles.axes1)
    axes(handles.axes1)
    plot(recoveringVectorTime, recoveringValue, 'b*', 'MarkerSize', 15)
    xlabel('Time [h]', 'Interpreter', 'latex', 'FontSize', 15)
    ylabel('cTnT [ng/ml]', 'Interpreter', 'latex', 'FontSize', 15)
    legend({'cTnT'}, 'Interpreter', 'latex', 'FontSize', 15)
    title('cTnT', 'Interpreter', 'latex', 'FontSize', 15)
    set(handles.axes1,'FontSize',15)
    set(handles.axes1,'TickLabelInterpreter','latex')
    grid on

else
   cla(handles.axes1)
    axes(handles.axes1)
    plot(recoveringVectorTime, recoveringValue, 'b*', 'MarkerSize', 15)
    xlabel('Time [h]', 'Interpreter', 'latex', 'FontSize', 15)
    ylabel('cTnT [ng/ml]', 'Interpreter', 'latex', 'FontSize', 15)
    legend({'cTnT'}, 'Interpreter', 'latex', 'FontSize', 15)
    title('cTnT', 'Interpreter', 'latex', 'FontSize', 15)
    set(handles.axes1,'FontSize',15)
    set(handles.axes1,'TickLabelInterpreter','latex')
    grid on 
end
set(handles.cTnTAcquisitionsText, 'String', num2str(recoveringValue));
set(handles.TimeAcquisitionsText, 'String', num2str(recoveringVectorTime'));

handles.vector = recoveringValue;
handles.time = recoveringVectorTime;

% Update handles structure
guidata(hObject, handles);




function cTnTEdit_Callback(hObject, eventdata, handles)
% hObject    handle to cTnTEdit (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

valueModified = [];
valueModified = str2num(get(hObject, 'String'));

%% Store Data

handles.ValueModified = valueModified;

% Hints: get(hObject,'String') returns contents of cTnTEdit as text
%        str2double(get(hObject,'String')) returns contents of cTnTEdit as a double

% Update handles structure
guidata(hObject, handles);




% --- Executes during object creation, after setting all properties.
function cTnTEdit_CreateFcn(hObject, eventdata, handles)
% hObject    handle to cTnTEdit (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end

% Update handles structure
guidata(hObject, handles);



function TimeEdit_Callback(hObject, eventdata, handles)
% hObject    handle to TimeEdit (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

TimeModified = [];
TimeModified = str2num(get(hObject, 'String'));

%% Store Data

handles.TimeModified = TimeModified;


% Hints: get(hObject,'String') returns contents of TimeEdit as text
%        str2double(get(hObject,'String')) returns contents of TimeEdit as a double

% Update handles structure
guidata(hObject, handles);

% --- Executes during object creation, after setting all properties.
function TimeEdit_CreateFcn(hObject, eventdata, handles)
% hObject    handle to TimeEdit (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end


% --- Executes on button press in ChangeButton.
function ChangeButton_Callback(hObject, eventdata, handles)
% hObject    handle to ChangeButton (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
%% Import Data

CurrentcTnTLevel = handles.CurrentcTnTLevel;
CurrentTime = handles.CurrentTime;

valueModified = handles.ValueModified;
timeModified = handles.TimeModified;

Outliers = handles.Outliers;
timeOutliers = handles.timeOutliers;

indexOutliers = handles.indexOutliers;
CurrentIndex = handles.CurrentIndex;

vector = handles.vector;
time = handles.time;

%% Create a copy of current vector

ModValues = vector;
ModTime = time;

ModOutliers = Outliers;
ModTimeOutliers = timeOutliers;

%% Change Value

if (length(valueModified) == 0 )
    
    ModValues(CurrentIndex) = [];
    ModTime(CurrentIndex) = [];
    
else
    
    ModValues(CurrentIndex) = valueModified;
    ModTime(CurrentIndex) = timeModified;
    
end

%% Outliers Verify

if (find(CurrentcTnTLevel == Outliers)) ~= 0
    ModOutliers(indexOutliers) = [];
    ModTimeOutliers(indexOutliers) = [];
    
end

vector = ModValues;
time = ModTime;

Outliers = ModOutliers;
timeOutliers = ModTimeOutliers;

%% Current Index Update

if valueModified ~= 0

   CurrentIndex = find(valueModified == ModValues);
end

%% Update Data


%% Plot Data

cla(handles.axes1)
axes(handles.axes1)
plot(time, vector, 'b*', 'MarkerSize', 15)
grid on
xlabel('Time [h]', 'Interpreter', 'latex', 'FontSize', 15)
ylabel('cTnT [ng/ml]', 'Interpreter', 'latex', 'FontSize', 15)
title('cTnT', 'Interpreter', 'latex', 'FontSize', 15)
set(handles.axes1,'FontSize',15)
set(handles.axes1,'TickLabelInterpreter','latex')
hold on
if ((length(Outliers) ~= 0) && (length(valueModified) ~= 0))

    plot(timeOutliers, Outliers, 'g*', 'MarkerSize', 15)
% plot(timeModified, valueModified, 'g*', 'MarkerSize', 10)
% legend({'cTnT', 'Modified Data'}, 'Interpreter', 'latex', 'FontSize', 15)

% grid on
% hold off
    legend({'Original Data', 'Possible Outliers', 'Clear Data'}, 'Interpreter', 'latex', 'FontSize', 15);
    
elseif ((length(Outliers) == 0) && (length(valueModified) == 0))
   legend('Original Data', 'Interpreter', 'latex', 'FontSize', 15);
    
elseif ((length(Outliers) == 0) || (length(valueModified) == 0))

  if (length(Outliers) == 0)
       plot(timeModified, valueModified, 'r*', 'MarkerSize', 15)
       legend({'Original Data', 'Clear Data'}, 'Interpreter', 'latex', 'FontSize', 15);
   else
       plot(timeOutliers, Outliers, 'g*', 'MarkerSize', 15)
       legend({'Original Data', 'Possible Outliers'}, 'Interpreter', 'latex', 'FontSize', 15);
   end
    
end

hold off



set(handles.cTnTEdit, 'String', num2str(valueModified));
set(handles.TimeEdit, 'String', num2str(timeModified));
set(handles.cTnTAcquisitionsText, 'String', num2str(ModValues));
set(handles.TimeAcquisitionsText, 'String', num2str(ModTime'));


%% Update variables

handles.vector = vector;
handles.time = time;

handles.Outliers = Outliers;
handles.timeOutliers = timeOutliers;

% Update handles structure
guidata(hObject, handles);



%%*************************************************************************
% DEFINED USER FUNCTION
%%*************************************************************************
function [itpa, itsa] = UpdateIntervalTime(handles)
        index = handles.CurrentIndex;
        time = handles.time;
        %vector = handles.vector;
        
        itpa = 0;
        itsa = 0;
        if(index == 1)
            set(handles.ITPAText, 'String', 'First Acquisition');
            set(handles.ITPAText, 'Visible', 'on');
        else
            itpa = (time(index) - time(index - 1));
            set(handles.ITPAText, 'String', num2str(itpa));
            set(handles.ITPAText, 'Visible', 'on');

        end



    if(index == length(time))
        set(handles.ITSAText, 'String',  'Last Acquisition');
        set(handles.ITSAText, 'Visible', 'on');
    else
        itsa = (time(index + 1) - time(index));
        set(handles.ITSAText, 'String', num2str(itsa));
        set(handles.ITSAText, 'Visible', 'on');
    end


% --- Executes on button press in AnalysisButton.
function AnalysisButton_Callback(hObject, eventdata, handles)
% hObject    handle to AnalysisButton (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
global selectPat

selectPat.troponina = handles.vector;
selectPat.tempi = handles.time';

run('Analysis.m')


% --- Executes on button press in deselectButton.
function deselectButton_Callback(hObject, eventdata, handles)
% hObject    handle to deselectButton (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
global selectPat

ax = gca;
CurrentcTnTLevel = (ax.CurrentPoint(1,2));
CurrentTime = (ax.CurrentPoint(1,1));
time = handles.time';

i = find(time > CurrentTime-2 & time< CurrentTime+2);

handles.deleteV = [handles.deleteV selectPat.troponina(i)];
handles.deleteT = [handles.deleteT selectPat.tempi(i)'];
handles.deleteIndex = [handles.deleteIndex i];

guidata(hObject, handles);



% --- Executes on button press in PlotButton.
function PlotButton_Callback(hObject, eventdata, handles)
% hObject    handle to PlotButton (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
global selectPat
data = selectPat.troponina;
tempo = selectPat.tempi';

cla(handles.axes1)
axes(handles.axes1)
plot(tempo(setdiff(1:end,handles.deleteIndex)), data(setdiff(1:end,handles.deleteIndex)), 'b*', 'MarkerSize', 15)
grid on
xlabel('Time [h]', 'Interpreter', 'latex', 'FontSize', 15)
ylabel('cTnT [ng/ml]', 'Interpreter', 'latex', 'FontSize', 15)
title('cTnT', 'Interpreter', 'latex', 'FontSize', 15)
set(handles.axes1,'FontSize',15)
set(handles.axes1,'TickLabelInterpreter','latex')
hold on
plot(tempo(handles.deleteIndex), data(handles.deleteIndex), 'ro', 'MarkerSize', 15)
legend({'Selected Data', 'Deleted Data'}, 'Interpreter', 'latex', 'FontSize', 15);
hold off

handles.vector = data(setdiff(1:end,handles.deleteIndex));
handles.time = tempo(setdiff(1:end,handles.deleteIndex));
guidata(hObject, handles);
