%% 
function varargout = SelectPatient(varargin)
% SELECTPATIENT MATLAB code for SelectPatient.fig
%      SELECTPATIENT, by itself, creates a new SELECTPATIENT or raises the existing
%      singleton*.
%
%      H = SELECTPATIENT returns the handle to a new SELECTPATIENT or the handle to
%      the existing singleton*.
%
%      SELECTPATIENT('CALLBACK',hObject,eventData,handles,...) calls the local
%      function named CALLBACK in SELECTPATIENT.M with the given input arguments.
%
%      SELECTPATIENT('Property','Value',...) creates a new SELECTPATIENT or raises the
%      existing singleton*.  Starting from the left, property value pairs are
%      applied to the GUI before SelectPatient_OpeningFcn gets called.  An
%      unrecognized property name or invalid value makes property application
%      stop.  All inputs are passed to SelectPatient_OpeningFcn via varargin.
%
%      *See GUI Options on GUIDE's Tools menu.  Choose "GUI allows only one
%      instance to run (singleton)".
%
% See also: GUIDE, GUIDATA, GUIHANDLES

% Edit the above text to modify the response to help SelectPatient

% Last Modified by GUIDE v2.5 24-Jun-2020 14:40:30

% Begin initialization code - DO NOT EDIT
gui_Singleton = 1;
gui_State = struct('gui_Name',       mfilename, ...
                   'gui_Singleton',  gui_Singleton, ...
                   'gui_OpeningFcn', @SelectPatient_OpeningFcn, ...
                   'gui_OutputFcn',  @SelectPatient_OutputFcn, ...
                   'gui_LayoutFcn',  [] , ...
                   'gui_Callback',   []);
if nargin && ischar(varargin{1})
    gui_State.gui_Callback = str2func(varargin{1});
end

if nargout
    [varargout{1:nargout}] = gui_mainfcn(gui_State, varargin{:});
else
    gui_mainfcn(gui_State, varargin{:});
end
%% 
% End initialization code - DO NOT EDIT

%Le suddette 44 righe di codice non devono essere modificate: stampano a
%video la finestra principale. 
%% 
%% 
%% 

 

%Function SelectPatient_OpeningFcn inizializza la finestra principale prima
%che venga visualizzata.
% --- Executes just before SelectPatient is made visible.
function SelectPatient_OpeningFcn(hObject, eventdata, handles, varargin)
% This function has no output args, see OutputFcn.
% hObject    handle to figure
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
% varargin   command line arguments to SelectPatient (see VARARGIN)
set(handles.analisi_pushbutton,'Visible','off');
set(handles.tabellavalori,'Visible','off');
set(handles.medicalrecords,'Visible','off');
set(handles.dailyaverage,'Visible','off');
set(handles.admissions,'Visible','off');
set(handles.warning,'Visible','off');
set(handles.CheckOutliers, 'Visible', 'off');

% axes(handles.axes2)
% matlabImage = imread('Sfondo.jpg');
% image(matlabImage)
% axis off
% axis image
% axes(handles.axes3)
% matlabImage = imread('logo_umg_biomechatronics_lab.tif');
% image(matlabImage)
% axis off
% axis image
% axes(handles.axes4)
% matlabImage = imread('UMG.jpg');
% image(matlabImage)
% axis off
% axis image
% Choose default command line output for SelectPatient
handles.output = hObject;
set(handles.output, 'WindowStyle', 'docked')

% nome DataBase
dbname = 'Biomarcatore';

% Username and Password per accedere al DB
username = 'root';
password = 'root';

% Specifichiamo la tipologia di driver utilizzato
driver = 'com.mysql.jdbc.Driver';

% Specifichiamo l'inidrizzo
dburl = 'jdbc:mysql://localhost:3306/Biomarcatore'; %/useSSL=false&? 
% useSSL=true and verifyServerCertificate=false Perch? su php ssl variables
% risultano DISABLED

% Modifichiamo il classpath 
%currentFolder = pwd;
%path_driver = strcat(currentFolder, '/mysql-connector-java-5.0.8/mysql-connector-java-5.0.8-bin.jar');
%javaclasspath(path_driver);

% Effettuiamo la connessione (.handles aggiunto dopo)
handles.conn = database(dbname, username, password, driver, dburl);

%
sqlqery = 'SELECT CF FROM CartellaClinica';

% Eseguiamo la query con il comando exec
curs = exec(handles.conn, sqlqery);

% Importiamo i dati in matlab attraverso il comando fetch e visualizziamo i
% dati selezionati
curs = fetch(curs);

set(handles.CF,'String', curs.Data);


% Update handles structure
guidata(hObject, handles); % questo messo sempre alla fine!

% UIWAIT makes SelectPatient wait for user response (see UIRESUME)
% uiwait(handles.SelectPatient);

%Le righe successive riportano tutte le informazioni relative agli oggetti
%grafici.

% --- Outputs from this function are returned to the command line.
function varargout = SelectPatient_OutputFcn(hObject, eventdata, handles) 
% varargout  cell array for returning output args (see VARARGOUT);
% hObject    handle to figure
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Get default command line output from handles structure
varargout{1} = handles.output;






% --- Executes during object creation, after setting all properties.
function media_axes_CreateFcn(hObject, eventdata, handles)
% hObject    handle to media_axes (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called
set(get(handles.media_axes, 'xlabel'), 'Time');
set(get(handles.media_axes, 'ylabel'), 'cTnT');
guidata(hObject, handles);
% Hint: place code in OpeningFcn to populate media_axes


% --- Executes during object deletion, before destroying properties.
function media_axes_DeleteFcn(hObject, eventdata, handles)
% hObject    handle to media_axes (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)


% --- Executes on mouse press over axes background.
function media_axes_ButtonDownFcn(~, eventdata, handles)
% hObject    handle to media_axes (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)


% --- Executes on button press in radiobutton3.
function radiobutton3_Callback(hObject, eventdata, handles)
% hObject    handle to radiobutton3 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hint: get(hObject,'Value') returns toggle state of radiobutton3



% --- Executes during object creation, after setting all properties.
function mediagiornalieraacquisizioni_CreateFcn(hObject, eventdata, handles)
% hObject    handle to mediagiornalieraacquisizioni (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

function diciannove_CreateFcn(hObject, eventdata, handles)



% --- Executes during object creation, after setting all properties.
function seleziona_CreateFcn(hObject, eventdata, handles)
% hObject    handle to seleziona (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called


% --- Executes on selection change in CF.
function CF_Callback(hObject, eventdata, handles)
% hObject    handle to CF (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

indexpat = get(handles.CF,'Value');
pat = get(handles.CF, 'String'); %in pat metto tutti i pz
sel_pat = pat{indexpat}; %paz selezionato in sel
handles.sel_pat = sel_pat;

set(handles.medicalrecords,'Visible','on');

set(handles.tabellavalori, 'Visible','off');
set(handles.admissions,'Visible','on');
set(handles.warning,'Visible','off');


sqlqery= strcat('SELECT Nome, Cognome, DataDiNascita, LuogoDiNascita, Sesso, Residenza, Dislipidemia, Familiarita, Diabete, Obesita, Fumo FROM CartellaClinica WHERE CF = "', sel_pat, '"');
curs = exec(handles.conn, sqlqery);
curs = fetch(curs);
handles.pazienteSelezionato = curs.Data;
set(handles.nome,'String', curs.Data{1});
set(handles.cognome, 'String', curs.Data{2});
set(handles.datadinascita, 'String', curs.Data{3});
set(handles.luogodinascita, 'String', curs.Data{4});
set(handles.sesso, 'String', curs.Data{5});
set(handles.residenza, 'String', curs.Data{6});
set(handles.dislipidemia, 'String', curs.Data{7});
set(handles.familiarita, 'String', curs.Data{8});
set(handles.diabete, 'String', curs.Data{9});
set(handles.obesita, 'String', curs.Data{10});
set(handles.fumo, 'String', curs.Data{11});

global selectPat
selectPat = {};
selectPat.nome = curs.Data{1};
selectPat.cognome = curs.Data{2};
selectPat.CF= sel_pat;

% sqlqery= strcat('SELECTPATIENT DataRicovero, DataAcquisizione, OraAcquisizione, LivTroponina, LivSodio, LivPotassio, LivCKMB FROM Misure WHERE CF  = "', sel_pat, '"');
sqlqery= strcat('SELECT DataRicovero FROM Ricovero WHERE CF  = "', sel_pat, '"');
curs = exec(handles.conn, sqlqery);
curs = fetch(curs);

set(handles.admissions,'String',curs.Data); 

ricov = {};
[row, col] = size(curs.Data);
for i = 1 : row
    ricov{i,1} = curs.Data{i,1};
end

% Estraggo info su ricoveri - quanti e quali
num_ric_uni = unique(ricov);

% Check e visualizzazione informazioni per paziente selezionato ed
% eventualmente per data ricovero selezionata

if length(num_ric_uni) == 1
    
    compare_str = strcmp(num_ric_uni{1}, 'No Data');
    if compare_str == 1
        set(handles.admissions, 'Visible', 'off');
        set(handles.tabellavalori,'Visible','off');
        
    else 
        set(handles.admissions, 'Visible', 'on');
        set(handles.tabellavalori,'Visible','off');
    end 
    
else
     length(num_ric_uni) > 1
     display(num_ric_uni);
     set(handles.admissions,'Visible','on');
        
end

guidata(hObject, handles);

% set(handles.nome,'String', curs.Data{1}) : inserisco e setto

    
% --- Executes during object creation, after setting all properties.
function CF_CreateFcn(hObject, eventdata, handles)
% hObject    handle to CF (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: popupmenu controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end


% --- Executes during object creation, after setting all properties.
function uipanel3_CreateFcn(hObject, eventdata, handles)
% hObject    handle to uipanel3 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called


% --- Executes during object creation, after setting all properties.
function dailyaverage_CreateFcn(hObject, eventdata, handles)
% hObject    handle to dailyaverage (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called


% --- Executes during object creation, after setting all properties.
function medicalrecords_CreateFcn(hObject, eventdata, handles)
% hObject    handle to medicalrecords (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called


% --- Executes when entered data in editable cell(s) in tabellavalori.
function tabellavalori_CellEditCallback(hObject, eventdata, handles)

% hObject    handle to tabellavalori (see GCBO)
% eventdata  structure with the following fields (see MATLAB.UI.CONTROL.TABLE)
%	Indices: row and column indices of the cell(s) edited
%	PreviousData: previous data for the cell(s) edited
%	EditData: string(s) entered by the user
%	NewData: EditData or its converted form set on the Data property. Empty if Data was not changed
%	Error: error string when failed to convert EditData to appropriate value for Data
% handles    structure with handles and user data (see GUIDATA)
% --- Executes during object creation, after setting all properties.

function tabellavalori_CreateFcn(hObject, eventdata, handles)
% hObject    handle to tabellavalori (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% tabellavalori.Position = [350 350 tabellavalori.Extent(3) tabellavalori.Extent(4)];
guidata(hObject, handles);


% --- Executes on selection change in admissions.
function admissions_Callback(hObject, eventdata, handles)
% hObject    handle to admissions (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: contents = cellstr(get(hObject,'String')) returns admissions contents as cell array
%       contents{get(hObject,'Value')} returns selected item from admissions
            % il paziente selezionato ha pi? di un ricovero

% selezione ricovero
set(handles.dailyaverage,'Visible','on');
set(handles.CheckOutliers, 'Visible', 'on');
indexdata = get(handles.admissions,'Value');
set(handles.tabellavalori, 'visible', 'on');
data = get(handles.admissions, 'String');
sel_data = data{indexdata};
sqlqery= strcat('SELECT DataRicovero, OraRicovero, DataAcquisizione, OraAcquisizione, LivTroponina, LivSodio, LivPotassio, LivCKMB, DataEvento, OraEvento FROM Misure WHERE CF  = "', handles.sel_pat, '" AND DataRicovero = "', sel_data, '"');
curs = exec(handles.conn, sqlqery);
curs = fetch(curs);


acqu = {};


if length(curs.Data) == 1
    
    compare_str = strcmp(curs.Data, 'No Data');

    if compare_str == 1
        % Nessuna misura per il paziente selezionato
        set(handles.tabellavalori,'Visible','off');
        set(handles.warning,'Visible','on');
        set(handles.dailyaverage,'Visible','off');
        set(handles.analisi_pushbutton,'Visible','off');
    else
        set(handles.warning,'Visible','off');       
        set(handles.tabellavalori,'Visible','on');
        set(handles.tabellavalori,'data',curs.Data(:, 3:8));
        set(handles.analisi_pushbutton,'Visible','on');
        %TemAcq = tempi(dataacquisizione, oraacquisizione, dataevento, oraevento)
    end

           
else
    set(handles.warning,'Visible','off');         
    set(handles.tabellavalori,'Visible','on');
    set(handles.tabellavalori,'data',curs.Data(:, 3:8));
    set(handles.analisi_pushbutton,'Visible','on');
   

end 



dataacquisizione = curs.Data(:, 3); 
oraacquisizione = curs.Data(:, 4);
dataevento = curs.Data(1, 9);
oraevento = curs.Data(1, 10);
assignin('base', 'Data', curs.Data)

troponina= cellfun(@str2num,curs.Data(:,5))';
ckmb=cellfun(@str2num,curs.Data(:,8))';
sodio = cellfun(@str2num,curs.Data(:,6))';
potassio = cellfun(@str2num,curs.Data(:,7))';


TemAcq = tempi(dataacquisizione, oraacquisizione, dataevento, oraevento);

global selectPat
selectPat.dataricovero= curs.Data{1};
selectPat.oraricovero= curs.Data(1,2);
selectPat.dataevento= curs.Data(1,9);
selectPat.oraevento = curs.Data(1,10);
selectPat.troponina= troponina;
selectPat.ckmb= ckmb;
selectPat.tempi = TemAcq;


ax= handles.media_axes;
subplot(2,1,1);
x = TemAcq;
y1 = troponina;
y2  = ckmb;
[kAx,kLine1,kLine2]= plotyy(x, y1, x, y2);
set( kLine1, 'LineStyle', 'none', 'Marker','o','MarkerSize',10)
set( kLine2, 'LineStyle', 'none','Marker','*','MarkerSize',10)
ylabel(kAx(1),'cTnT [ng/ml]', 'Interpreter', 'latex', 'FontSize', 15);
ylabel(kAx(2),'CK-MB [ng/ml]', 'Interpreter', 'latex', 'FontSize', 15);
title('cTnT and CK-MB', 'Interpreter', 'latex', 'FontSize', 15)
legend({'cTnT','CK-MB'}, 'Interpreter', 'latex', 'FontSize', 15)
set(kAx,'TickLabelInterpreter','latex')
grid on
set(kAx,'FontSize',15)

subplot(2,1,2); 
y3= sodio;
y4= potassio;
plotyy(x,y3,x,y4)
[hAx,hLine1,hLine2] = plotyy(x, y3, x, y4);
xlabel('Time [h]', 'Interpreter', 'latex', 'FontSize', 15);
ylabel(hAx(1),'Na [ng/ml]', 'Interpreter', 'latex', 'FontSize', 15);
ylabel(hAx(2),'K [ng/ml]', 'Interpreter', 'latex', 'FontSize', 15);
title('Na and Ks', 'Interpreter', 'latex', 'FontSize', 15)
legend({'Na','K'}, 'Interpreter', 'latex', 'FontSize', 15)
set( hLine1, 'LineStyle', 'none', 'Marker','o','MarkerSize',10)
set( hLine2, 'LineStyle', 'none','Marker','*','MarkerSize',10)
set(hAx,'TickLabelInterpreter','latex', 'FontSize', 15)
grid on
set(hAx,'FontSize',15)

guidata(hObject, handles);

% --- Executes during object creation, after setting all properties.
function admissions_CreateFcn(hObject, eventdata, handles)
% hObject    handle to admissions (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: popupmenu controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end


% --- Executes on button press in home_pushbutton.
function home_pushbutton_Callback(hObject, eventdata, handles)
% hObject    handle to home_pushbutton (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

run('Home.m');


function TemAcq = tempi(dataacquisizione, oraacquisizione, dataevento, oraevento)


    unionacquisizione = strcat(dataacquisizione,{' '},oraacquisizione);
    unionevento = strcat(dataevento, {' '},oraevento);
    
    t1 = datetime(unionevento);
    t2= datetime(unionacquisizione);
    
    dt = datenum(t2 - t1);
    TemAcq = dt*24;


   
    


% --- Executes on button press in analisi_pushbutton.
function analisi_pushbutton_Callback(hObject, eventdata, handles)
% hObject    handle to analisi_pushbutton (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
run('Analysis.m');


% --- Executes on button press in CheckOutliers.
function CheckOutliers_Callback(hObject, eventdata, handles)
% hObject    handle to CheckOutliers (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
run('OutliersDetection.m');
