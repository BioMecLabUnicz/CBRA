function txt = myupdatefcn(empt,event_obj)
    % Customizes text of data tips

    pos = get(event_obj,'Position');
    txt = {['cTnT Value: ',num2str(pos(2))],...
           ['Time: ',num2str(pos(1))]};
end