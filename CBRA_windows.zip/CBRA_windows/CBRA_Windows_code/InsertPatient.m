function varargout = InsertPatient(varargin)
% INSERTPATIENT MATLAB code for InsertPatient.fig
%      INSERTPATIENT, by itself, creates a new INSERTPATIENT or raises the existing
%      singleton*.
%
%      H = INSERTPATIENT returns the handle to a new INSERTPATIENT or the handle to
%      the existing singleton*.
%
%      INSERTPATIENT('CALLBACK',hObject,eventData,handles,...) calls the local
%      function named CALLBACK in INSERTPATIENT.M with the given input arguments.
%
%      INSERTPATIENT('Property','Value',...) creates a new INSERTPATIENT or raises the
%      existing singleton*.  Starting from the left, property value pairs are
%      applied to the GUI before InsertPatient_OpeningFcn gets called.  An
%      unrecognized property name or invalid value makes property application
%      stop.  All inputs are passed to InsertPatient_OpeningFcn via varargin.
%
%      *See GUI Options on GUIDE's Tools menu.  Choose "GUI allows only one
%      instance to run (singleton)".
%
% See also: GUIDE, GUIDATA, GUIHANDLES

% Edit the above text to modify the response to help InsertPatient

% Last Modified by GUIDE v2.5 07-Dec-2019 17:59:30

% Begin initialization code - DO NOT EDIT
gui_Singleton = 1;
gui_State = struct('gui_Name',       mfilename, ...
                   'gui_Singleton',  gui_Singleton, ...
                   'gui_OpeningFcn', @InsertPatient_OpeningFcn, ...
                   'gui_OutputFcn',  @InsertPatient_OutputFcn, ...
                   'gui_LayoutFcn',  [] , ...
                   'gui_Callback',   []);
if nargin && ischar(varargin{1})
    gui_State.gui_Callback = str2func(varargin{1});
end

if nargout
    [varargout{1:nargout}] = gui_mainfcn(gui_State, varargin{:});
else
    gui_mainfcn(gui_State, varargin{:});
end
% End initialization code - DO NOT EDIT


% --- Executes just before InsertPatient is made visible.
function InsertPatient_OpeningFcn(hObject, eventdata, handles, varargin)
% This function has no output args, see OutputFcn.
% hObject    handle to figure
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
% varargin   command line arguments to InsertPatient (see VARARGIN)
% axes(handles.axes1)
% matlabImage = imread('Sfondo.jpg');
% image(matlabImage)
% axis off
% axis image
% axes(handles.axes2)
% matlabImage = imread('logo_umg_biomechatronics_lab.tif');
% image(matlabImage)
% axis off
% axis image
% axes(handles.axes3)
% matlabImage = imread('UMG.jpg');
% image(matlabImage)
% axis off
% axis image
% Choose default command line output for InsertPatient
handles.output = hObject;
set(handles.output, 'WindowStyle', 'docked')

% Update handles structure
guidata(hObject, handles);
set(handles.admissiondata,'Visible','off');
% Nome DataBase
dbname = 'Biomarcatore';

% Username and Password per accedere al DB
username = 'root';
password = 'root';

% Specifichiamo la tipologia di driver utilizzato
driver = 'com.mysql.jdbc.Driver';

% Specifichiamo l'inidrizzo
dburl = 'jdbc:mysql://localhost:3306/Biomarcatore'; %/useSSL=false&? 
% useSSL=true and verifyServerCertificate=false Perch? su php ssl variables
% risultano DISABLED


% Modifichiamo il classpath 
%currentFolder = pwd;
%path_driver = strcat(currentFolder, '/mysql-connector-java-5.0.8/mysql-connector-java-5.0.8-bin.jar');
%javaclasspath(path_driver);

load ('nomecomuni.mat');
set(handles.luogodinascita_popupmenu,'String', name);

% Effettuiamo la connessione
handles.conn = database(dbname, username, password, driver, dburl);
set(handles.admissiondata,'Visible','off');
set(handles.warning,'Visible','off');
set(handles.nomewarn,'Visible','off');

set(handles.cf_pushbutton,'String','SSN');
set(handles.nome_edit,'String', '');
set(handles.cognome_edit, 'String', '');
set(handles.datadinascita_pushbutton, 'String', '');
set(handles.residenza_edit, 'String', '');
set(handles.datadinascita_pushbutton, 'String', 'Select Date');
set(handles.gender_popupmenu,'String',{'M', 'F'});
set(handles.dis_popupmenu,'String',{'YES', 'NO'});
set(handles.fam_popupmenu,'String',{'YES', 'NO'});
set(handles.diab_popupmenu,'String',{'YES', 'NO'});
set(handles.ob_popupmenu,'String',{'YES', 'NO'});
set(handles.smoke_popupmenu,'String',{'YES', 'NO'});

 
handles.nome = '';
handles.cognome= '';
handles.message= '';
handles.datadinascita='';
handles.luogodinascita='';
handles.gender='';
handles.cf='';
handles.residenza='';
handles.dis='';
handles.fam='';
handles.diab='';
handles.ob='';
handles.smoke='';

handles.dataricovero='';
handles.oraevento='';
handles.dataevento='';
handles.oraricovero='';
handles.primocontattomedico='';

%inizializzare tutti questi sopra

set(handles.dataevento_pushbutton,'String','Select Date');
set(handles.oraevento_edit,'String','');
set(handles.dataricovero_pushbutton,'String','Select Date');
set(handles.oraricovero_edit,'String','');
set(handles.primocontattomedico_pushbutton,'String','Select Date');


guidata(hObject, handles);
% UIWAIT makes InsertPatient wait for user response (see UIRESUME)
% uiwait(handles.figure1);


% --- Outputs from this function are returned to the command line.
function varargout = InsertPatient_OutputFcn(hObject, eventdata, handles) 
% varargout  cell array for returning output args (see VARARGOUT);
% hObject    handle to figure
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Get default command line output from handles structure
varargout{1} = handles.output;



function cf_pushbutton_Callback(hObject, eventdata, handles)
% hObject    handle to cf_pushbutton (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

ssn = ComputeSSN(handles.cognome, handles.nome, handles.d, handles.m ,handles.y , handles.gender, handles.indexcomune);
display(ssn)

set(handles.cf_pushbutton,'String',ssn);
indexpat  = get(handles.cf_pushbutton,'Value');
pat  = get(handles.cf_pushbutton,'String');
handles.pat = pat;
display(pat);


guidata(hObject, handles);
% Hints: get(hObject,'String') returns contents of cf_pushbutton as text
%        str2double(get(hObject,'String')) returns contents of cf_pushbutton as a double


% --- Executes during object creation, after setting all properties.
function cf_pushbutton_CreateFcn(hObject, eventdata, handles)
% hObject    handle to cf_pushbutton (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end



function nome_edit_Callback(hObject, eventdata, handles)
% hObject    handle to nome_edit (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of nome_edit as text
%        str2double(get(hObject,'String')) returns contents of nome_edit as a double

handles.nome = get(handles.nome_edit, 'String');
display(handles.nome)
guidata(hObject, handles);

% --- Executes during object creation, after setting all properties.
function nome_edit_CreateFcn(hObject, eventdata, handles)
% hObject    handle to nome_edit (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end



function cognome_edit_Callback(hObject, eventdata, handles)
% hObject    handle to cognome_edit (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of cognome_edit as text
%        str2double(get(hObject,'String')) returns contents of cognome_edit as a double

handles.cognome = get(handles.cognome_edit, 'String');

guidata(hObject, handles);

% --- Executes during object creation, after setting all properties.
function cognome_edit_CreateFcn(hObject, eventdata, handles)
% hObject    handle to cognome_edit (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end

function luogodinascita_popupmenu_Callback(hObject, eventdata, handles)
% hObject    handle to luogodinascita_popupmenu (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of luogodinascita_popupmenu as text
%        str2double(get(hObject,'String')) returns contents of luogodinascita_popupmenu as a double

indexcomune = get(handles.luogodinascita_popupmenu,'Value');
display(indexcomune)
comune = get(handles.luogodinascita_popupmenu, 'String'); %in pat metto tutti i pz
sel_comune = comune{indexcomune}; %paz selezionato in sel

handles.luogodinascita = sel_comune;
handles.indexcomune = indexcomune;


guidata(hObject, handles);

% --- Executes during object creation, after setting all properties.
function luogodinascita_popupmenu_CreateFcn(hObject, eventdata, handles)
% hObject    handle to luogodinascita_popupmenu (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end





function residenza_edit_Callback(hObject, eventdata, handles)
% hObject    handle to residenza_edit (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of residenza_edit as text
%        str2double(get(hObject,'String')) returns contents of residenza_edit as a double
handles.residenza = get(handles.residenza_edit, 'String');
display(handles.residenza)
guidata(hObject, handles);

% --- Executes during object creation, after setting all properties.
function residenza_edit_CreateFcn(hObject, eventdata, handles)
% hObject    handle to residenza_edit (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end



% --- Executes on button press in admission_pushbutton.
function admission_pushbutton_Callback(hObject, eventdata, handles)
% hObject    handle to admission_pushbutton (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
set(handles.admissiondata,'Visible','off');

tablename = 'CartellaClinica';

%  2) Specifichiamo il nome delle colonne della tabella
colnames = {'CF','Nome', 'Cognome', 'DataDiNascita', 'LuogoDiNascita', 'Sesso', 'Residenza', 'Dislipidemia', 'Familiarita', 'Diabete','Obesita','Fumo'};

%  3) Specifichiamo la tupla da inserire
try 
    insertdata_array = {handles.pat, handles.nome, handles.cognome, handles.datadinascita, handles.luogodinascita, handles.sel_gender, handles.residenza, handles.sel_dis, handles.sel_fam, handles.sel_diab, handles.sel_ob, handles.sel_smoke};

if length(find(insertdata_array == 0))~=0
        set(handles.warning,'Visible','on');
        set(handles.nomewarn,'Visible','on');
        set(handles.nomewarn,'String','Please insert data!');
else
    insertdata = cell2table(insertdata_array, 'VariableNames', colnames);



    empty = cellfun('length', insertdata_array);

    empty_c = find(empty == 0);

    if length(empty_c) == 0

        try
            fastinsert(handles.conn,tablename,colnames,insertdata)
            set(handles.warning, 'Visible', 'off');
            set(handles.nomewarn, 'Visible', 'off');
            set(handles.admission_pushbutton,'BackgroundColor','green');
            set(handles.admissiondata,'Visible','on');

        catch
            set(handles.warning,'Visible','on');
            set(handles.nomewarn,'Visible','on');
            set(handles.nomewarn,'String','This patient has already been inserted');
        end


    else
        set(handles.admission_pushbutton,'BackgroundColor','red'); 
        messaggio = strjust('Warning:');

        for i = 1 : length(empty_c)

            mes = controllocampivuoti(empty_c(i),0);
            messaggio = strjust(char(messaggio,mes),'center');

        end

        set(handles.nomewarn, 'String', messaggio);
        set(handles.warning, 'Visible', 'on');
        set(handles.nomewarn, 'Visible', 'on');

    end
end
catch
        set(handles.warning,'Visible','on');
        set(handles.nomewarn,'Visible','on');
        set(handles.nomewarn,'String','Please insert data!');
end
guidata(hObject, handles);


% --- Executes during object creation, after setting all properties.
function edit13_CreateFcn(hObject, eventdata, handles)
% hObject    handle to edit13 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called



function dataevento_pushbutton_Callback(hObject, eventdata, handles)
% hObject    handle to dataevento_pushbutton (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of dataevento_pushbutton as text
%        str2double(get(hObject,'String')) returns contents of dataevento_pushbutton as a double
% handles.dataevento = get(handles.dataevento_pushbutton, 'String');
% guidata(hObject, handles);
uicalendar('DestinationUI', handles.dataevento_pushbutton);
waitfor(handles.dataevento_pushbutton,'String'); 
handles.dataevento  = get(handles.dataevento_pushbutton,'String');
data2 = datetime(handles.dataevento);
if isempty(data2) == 1
    set(handles.dataevento_pushbutton, 'String', 'Wrn: please select Year - Month -- Day')
else
    handles.dataevento  = get(handles.dataevento_pushbutton,'String');
end

guidata(hObject, handles)

% --- Executes during object creation, after setting all properties.
function dataevento_pushbutton_CreateFcn(hObject, eventdata, handles)
% hObject    handle to dataevento_pushbutton (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end



function oraevento_edit_Callback(hObject, eventdata, handles)
% hObject    handle to oraevento_edit (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of oraevento_edit as text
%        str2double(get(hObject,'String')) returns contents of oraevento_edit as a double
handles.oraevento = get(handles.oraevento_edit, 'String');
guidata(hObject, handles);


% --- Executes during object creation, after setting all properties.
function oraevento_edit_CreateFcn(hObject, eventdata, handles)
% hObject    handle to oraevento_edit (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end



function dataricovero_pushbutton_Callback(hObject, eventdata, handles)
% hObject    handle to dataricovero_pushbutton (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of dataricovero_pushbutton as text
%        str2double(get(hObject,'String')) returns contents of dataricovero_pushbutton as a double
% handles.dataricovero = get(handles.dataricovero_pushbutton, 'String');
% guidata(hObject, handles);
uicalendar('DestinationUI', handles.dataricovero_pushbutton);
waitfor(handles.dataricovero_pushbutton,'String'); 
handles.dataricovero  = get(handles.dataricovero_pushbutton,'String');
data1 = datetime(handles.dataricovero);
if isempty(data1) == 1
    set(handles.dataricovero_pushbutton, 'String', 'Wrn: please select Year - Month -- Day')
else
    handles.dataricovero  = get(handles.dataricovero_pushbutton,'String');
end

guidata(hObject, handles)

% --- Executes during object creation, after setting all properties.
function dataricovero_pushbutton_CreateFcn(hObject, eventdata, handles)
% hObject    handle to dataricovero_pushbutton (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end





% --- Executes during object creation, after setting all properties.
function ospedalizzazione_edit_CreateFcn(hObject, eventdata, handles)
% hObject    handle to ospedalizzazione_edit (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end



function oraricovero_edit_Callback(hObject, eventdata, handles)
% hObject    handle to oraricovero_edit (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of oraricovero_edit as text
%        str2double(get(hObject,'String')) returns contents of oraricovero_edit as a double
handles.oraricovero = get(handles.oraricovero_edit, 'String');
guidata(hObject, handles);

% --- Executes during object creation, after setting all properties.
function oraricovero_edit_CreateFcn(hObject, eventdata, handles)
% hObject    handle to oraricovero_edit (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end


% --- Executes during object creation, after setting all properties.
function edit19_CreateFcn(hObject, eventdata, handles)
% hObject    handle to edit19 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns calle




function edit26_Callback(hObject, eventdata, handles)
% hObject    handle to edit26 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of edit26 as text
%        str2double(get(hObject,'String')) returns contents of edit26 as a double


% --- Executes during object creation, after setting all properties.
function edit26_CreateFcn(hObject, eventdata, handles)
% hObject    handle to edit26 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end



% --- Executes on button press in home_pushbutton.
function home_pushbutton_Callback(hObject, eventdata, handles)
% hObject    handle to home_pushbutton (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

run('Home.m');


% --- Executes on button press in insert_pushbutton.
function insert_pushbutton_Callback(hObject, eventdata, handles)
% hObject    handle to insert_pushbutton (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

tablename='Ricovero';
colnames={'DataEvento','OraEvento','DataRicovero','OraRicovero','PrimoContattoMedico','CF'};


insertdata_array={handles.dataevento, handles.oraevento, handles.dataricovero, handles.oraricovero, handles.primocontattomedico, handles.pat};
insertdata = cell2table(insertdata_array, 'VariableNames', colnames);

empty = cellfun('length', insertdata_array);

empty_c = find(empty == 0);

if length(empty_c) == 0
   fastinsert(handles.conn,tablename,colnames,insertdata)
   set(handles.warning, 'Visible', 'off');
   set(handles.nomewarn, 'Visible', 'off');
   set(handles.insert_pushbutton,'BackgroundColor','green');
else
     
    messaggio = strjust('Warning:');
    
    for i = 1 : length(empty_c)
    
        mes = controllocampivuoti(empty_c(i),1);
        messaggio = strjust(char(messaggio,mes),'center');
        
    end
    set(handles.insert_pushbutton,'BackgroundColor','red');
    set(handles.nomewarn, 'String', messaggio);
    set(handles.warning, 'Visible', 'on');
    set(handles.nomewarn, 'Visible', 'on');

end

guidata(hObject, handles);


function primocontattomedico_pushbutton_Callback(hObject, eventdata, handles)
% hObject    handle to primocontattomedico_pushbutton (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of primocontattomedico_pushbutton as text
%        str2double(get(hObject,'String')) returns contents of primocontattomedico_pushbutton as a double

uicalendar('DestinationUI', handles.primocontattomedico_pushbutton);
waitfor(handles.primocontattomedico_pushbutton,'String'); 
handles.primocontattonedico  = get(handles.primocontattomedico_pushbutton,'String');
data3 = datetime(handles.primocontattomedico);
if isempty(data3) == 1
    set(handles.primocontattomedico_pushbutton, 'String', 'Wrn: please select Year - Month -- Day')
else
    handles.primocontattomedico  = get(handles.primocontattomedico_pushbutton,'String');
end

guidata(hObject, handles);



% --- Executes during object creation, after setting all properties.
function datadinascita_pushbutton_CreateFcn(hObject, eventdata, handles)
% hObject    handle to datadinascita_pushbutton (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end



function datadinascita_pushbutton_Callback(hObject, eventdata, handles)
% hObject    handle to datadinascita_pushbutton (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of datadinascita_pushbutton as text
%        str2double(get(hObject,'String')) returns contents of datadinascita_pushbutton as a double

uicalendar('DestinationUI', handles.datadinascita_pushbutton);

waitfor(handles.datadinascita_pushbutton,'String'); 
handles.datadinascita  = get(handles.datadinascita_pushbutton,'String');
tradu= datestr(handles.datadinascita)
data = datetime(tradu,'Inputformat','d-MMMM-yyyy','Locale','en_US');
display(data)


d = num2str(day(data));
m = char(month(data,'Name'));
y = num2str(year(data));

handles.d = d;
handles.m = m;
handles.y = y;
display(d)
display(m)
display(y) 

if isempty(data) == 1
    set(handles.datadinascita_pushbutton, 'String', 'Wrn: please select Year - Month -- Day')
else
    handles.datadinascita  = get(handles.datadinascita_pushbutton,'String');
end
display(handles.datadinascita);
guidata(hObject, handles);


% --- Executes on button press in ok_pushbutton.
function ok_pushbutton_Callback(hObject, eventdata, handles)
% hObject    handle to ok_pushbutton (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
set(handles.warning,'Visible','off');
set(handles.admission_pushbutton,'BackgroundColor','white');
set(handles.insert_pushbutton,'BackgroundColor','white');


function message = controllocampivuoti(index, b)


    switch index
    case  1
        if b == 0 
            message = 'Please Calculate CF';
        else
            message = 'Please select Event Date'; 
        end
    case  2
        if b == 0
            message = 'Please insert Name';
        else 
            message = 'Please insert Event Time';
        end
    case  3
        if b== 0
            message = 'Please insert Surname';
        else 
            message= 'Please select Admission Date';
        end
    case 4
        if b== 0 
            message= 'Please select a Date';
        else 
            message = 'Please insert Admission Time';
        end
    case 5
        if b==0
            message = 'Please select a Place';
        else
            message = 'Please insert First Medical Contact';
        end
         
    case 6
        message = 'Please select a Gender';
    case 7
        message = 'Please insert an Address';
    case 8
        message = 'Please select Dyslipidemia';
    case 9
        message = 'Please select Familiarity';
    case 10
        message = 'Please select Diabete';
    case 11
        message = 'Please select Obesity';
    case 12
        message = 'Please select Smoke';
        
            
            
            

    end



% --- Executes on button press in refresh_pushbutton.
function refresh_pushbutton_Callback(hObject, eventdata, handles)
% hObject    handle to refresh_pushbutton (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
set(handles.admission_pushbutton,'BackgroundColor','white');
set(handles.insert_pushbutton,'BackgroundColor','white');
set(handles.nome_edit,'String','');
set(handles.cognome_edit,'String','');
set(handles.datadinascita_pushbutton,'String','Select Date');
set(handles.cognome_edit,'String','');
load ('nomecomuni.mat');
set(handles.luogodinascita_popupmenu,'String', name)
set(handles.residenza_edit,'String','');
set(handles.cf_pushbutton,'String','SSN');
set(handles.gender_popupmenu,'String',{'M', 'F'});
set(handles.dis_popupmenu,'String',{'YES', 'NO'});
set(handles.fam_popupmenu,'String',{'YES', 'NO'});
set(handles.diab_popupmenu,'String',{'YES', 'NO'});
set(handles.ob_popupmenu,'String',{'YES', 'NO'});
set(handles.smoke_popupmenu,'String',{'YES', 'NO'});

set(handles.dataricovero_pushbutton,'String','Select Date');
set(handles.oraricovero_edit,'String','');
set(handles.dataevento_pushbutton,'String','Select Date');
set(handles.oraevento_edit,'String','');
set(handles.primocontattomedico_pushbutton,'String','');


handles.nome = '';
handles.cognome= '';
handles.message= '';
handles.datadinascita='';
handles.luogodinascita='';
handles.gender='';
handles.cf='';
handles.residenza='';
handles.dis='';
handles.fam='';
handles.diab='';
handles.ob='';
handles.smoke='';

handles.dataricovero='';
handles.oraevento='';
handles.dataevento='';
handles.oraricovero='';

handles.primocontattomedico='';

guidata(hObject, handles);


% --- Executes on selection change in gender_popupmenu.
function gender_popupmenu_Callback(hObject, eventdata, handles)
% hObject    handle to gender_popupmenu (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
% handles.gender  = get(handles.gender_popupmenu,'String');
indexgender = get(handles.gender_popupmenu,'Value');
gender = get(handles.gender_popupmenu, 'String'); %in pat metto tutti i pz
sel_gender = gender{indexgender}; %paz selezionato in sel
handles.sel_gender = sel_gender;
display(handles.sel_gender);
guidata(hObject, handles)
% Hints: contents = cellstr(get(hObject,'String')) returns gender_popupmenu contents as cell array
%        contents{get(hObject,'Value')} returns selected item from gender_popupmenu


% --- Executes during object creation, after setting all properties.
function gender_popupmenu_CreateFcn(hObject, eventdata, handles)
% hObject    handle to gender_popupmenu (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: popupmenu controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end


% --- Executes on selection change in dis_popupmenu.
function dis_popupmenu_Callback(hObject, eventdata, handles)
% hObject    handle to dis_popupmenu (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
% handles.gender  = get(handles.gender_popupmenu,'String');
indexdis = get(handles.dis_popupmenu,'Value');
dis = get(handles.dis_popupmenu, 'String'); %in pat metto tutti i pz
sel_dis = dis{indexdis}; %paz selezionato in sel
handles.sel_dis = sel_dis;
display(handles.sel_dis);
guidata(hObject, handles)
% Hints: contents = cellstr(get(hObject,'String')) returns dis_popupmenu contents as cell array
%        contents{get(hObject,'Value')} returns selected item from dis_popupmenu


% --- Executes during object creation, after setting all properties.
function dis_popupmenu_CreateFcn(hObject, eventdata, handles)
% hObject    handle to dis_popupmenu (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: popupmenu controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end


% --- Executes on selection change in fam_popupmenu.
function fam_popupmenu_Callback(hObject, eventdata, handles)
% hObject    handle to fam_popupmenu (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
% handles.gender  = get(handles.gender_popupmenu,'String');
indexfam = get(handles.fam_popupmenu,'Value');
fam = get(handles.fam_popupmenu, 'String'); %in pat metto tutti i pz
sel_fam = fam{indexfam}; %paz selezionato in sel
handles.sel_fam = sel_fam;
display(handles.sel_fam);
guidata(hObject, handles)
% Hints: contents = cellstr(get(hObject,'String')) returns fam_popupmenu contents as cell array
%        contents{get(hObject,'Value')} returns selected item from fam_popupmenu


% --- Executes during object creation, after setting all properties.
function fam_popupmenu_CreateFcn(hObject, eventdata, handles)
% hObject    handle to fam_popupmenu (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: popupmenu controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end


% --- Executes on selection change in diab_popupmenu.
function diab_popupmenu_Callback(hObject, eventdata, handles)
% hObject    handle to diab_popupmenu (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
% handles.gender  = get(handles.gender_popupmenu,'String');
indexdiab = get(handles.diab_popupmenu,'Value');
diab = get(handles.diab_popupmenu, 'String'); %in pat metto tutti i pz
sel_diab = diab{indexdiab}; %paz selezionato in sel
handles.sel_diab = sel_diab;
display(handles.sel_diab);
guidata(hObject, handles)
% Hints: contents = cellstr(get(hObject,'String')) returns diab_popupmenu contents as cell array
%        contents{get(hObject,'Value')} returns selected item from diab_popupmenu


% --- Executes during object creation, after setting all properties.
function diab_popupmenu_CreateFcn(hObject, eventdata, handles)
% hObject    handle to diab_popupmenu (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: popupmenu controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end


% --- Executes on selection change in ob_popupmenu.
function ob_popupmenu_Callback(hObject, eventdata, handles)
% hObject    handle to ob_popupmenu (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
% handles.gender  = get(handles.gender_popupmenu,'String');
indexob = get(handles.ob_popupmenu,'Value');
ob = get(handles.ob_popupmenu, 'String'); %in pat metto tutti i pz
sel_ob = ob{indexob}; %paz selezionato in sel
handles.sel_ob = sel_ob;
display(handles.sel_ob);
guidata(hObject, handles)
% Hints: contents = cellstr(get(hObject,'String')) returns ob_popupmenu contents as cell array
%        contents{get(hObject,'Value')} returns selected item from ob_popupmenu


% --- Executes during object creation, after setting all properties.
function ob_popupmenu_CreateFcn(hObject, eventdata, handles)
% hObject    handle to ob_popupmenu (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: popupmenu controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end


% --- Executes on selection change in smoke_popupmenu.
function smoke_popupmenu_Callback(hObject, eventdata, handles)
% hObject    handle to smoke_popupmenu (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
% handles.gender  = get(handles.gender_popupmenu,'String');
indexsmoke = get(handles.smoke_popupmenu,'Value');
smoke = get(handles.smoke_popupmenu, 'String'); %in pat metto tutti i pz
sel_smoke = smoke{indexsmoke}; 
handles.sel_smoke = sel_smoke;
display(handles.sel_smoke);
guidata(hObject, handles)
% Hints: contents = cellstr(get(hObject,'String')) returns smoke_popupmenu contents as cell array
%        contents{get(hObject,'Value')} returns selected item from smoke_popupmenu


% --- Executes during object creation, after setting all properties.
function smoke_popupmenu_CreateFcn(hObject, eventdata, handles)
% hObject    handle to smoke_popupmenu (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: popupmenu controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end
