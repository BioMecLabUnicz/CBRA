function [index] = FindOutliers(data)

% Creiamo due grandi gruppi nei dati identificando i valori di massimo
% sulla curva sperimentale

data_dif = diff(data);
idx_mins = [];

for idx_min = 1:length(data_dif)-1
    if data_dif(idx_min)*data_dif(idx_min+1)<0
        if data_dif(idx_min+1)<0
            idx_mins = [idx_mins, idx_min+1];
        end
    end
end

index = [];

if length(idx_mins) ~= 0
    
    if length(idx_mins) >1
        n = [idx_mins(1) idx_mins(end)];
    else
        n = idx_mins(1);
    end
    gruppo1 = data(1:n(end)-1);
    lb1 = mean(gruppo1) - std(gruppo1);
    ub1 = mean(gruppo1) + 2*std(gruppo1);
    index = [index find(gruppo1 < lb1)];
    index = [index find(gruppo1 > ub1)];
    gruppo2 = data(n(end):end);
    lb2 = mean(gruppo2) - 1/2*std(gruppo2);
    ub2 = mean(gruppo2) + 2*std(gruppo2);
    index = [index n(end)-1+find(gruppo2 < lb2)];
    index = [index n(end)-1+find(gruppo2 > ub2)];    
else
    index = [];
            
end
