function FinfOutliers(data, time)

% Creiamo due grandi gruppi nei dati identificando i valori di massimo
% sulla curva sperimentale

data_dif = diff(data);
idx_mins = [];
first_m = [];
for idx_min = 1:length(data_dif)-1
    if data_dif(idx_min)*data_dif(idx_min+1)<0
        if data_dif(idx_min+1)<0
            idx_mins = [idx_mins, idx_min+1];
        else
            first_m = [first_m idx_min+1];
        end
    end
end

index = [];

figure
plot(time, data, 'bo', 'MarkerSize', 15)
hold on

if length(idx_mins) ~= 0
    
    if length(idx_mins) >1
        n = [idx_mins(1) idx_mins(end)];
    else
        n = idx_mins(1);
    end
    gruppo1 = data(1:first_m(1));
    if length(gruppo1)>0
        lb1 = mean(gruppo1) - std(gruppo1);
        ub1 = mean(gruppo1) + 2*std(gruppo1);
        index = [index find(gruppo1 < lb1)];
        index = [index find(gruppo1 > ub1)];
        lb1
    else
        lb1 = NaN
        ub1 = NaN;
    end
    
    gruppo2 = data(first_m(1)+1:end);
    if length(gruppo2)>0
        lb2 = mean(gruppo2) - std(gruppo2);
        ub2 = mean(gruppo2) + 2*std(gruppo2);
    else
        lb2 = NaN;
        ub2 = NaN;
    end
    index = [index first_m(1)+find(gruppo2 < lb2)];
    index = [index first_m(1)+find(gruppo2 > ub2)];    
else
    index = [];        
end
disp(index)
[v_max, t_max, index_v] = min_max(data, time);
plot([0 time(1:first_m(1))], lb1*ones(1, length(time(1:first_m(1)))+1), 'r--', 'MarkerSize', 15)
plot([0 time(1:first_m(1))], ub1*ones(1, length(time(1:first_m(1)))+1), 'r--', 'MarkerSize', 15)
plot([0 time(1:first_m(1))], mean(gruppo1)*ones(1, length(time(1:first_m(1)))+1), 'g--', 'MarkerSize', 15)
plot(time(first_m(1):end), lb2*ones(1, length(time(first_m(1):end))), 'r--', 'MarkerSize', 15)
plot(time(first_m(1):end), ub2*ones(1, length(time(first_m(1):end))), 'r--', 'MarkerSize', 15)
plot(time(first_m(1):end), mean(gruppo2)*ones(1, length(time(first_m(1):end))), 'g--', 'MarkerSize', 15)     
plot(t_max, v_max, 'rd', 'MarkerSize', 15)
plot(time(first_m(1)).*ones(1, length(data)), linspace(0, max(data)+1, length(data)), 'm--', 'MarkerSize', 15)
plot(time(index), data(index), 'r*', 'MarkerSize', 15)
grid on
xlabel('Time [h]', 'Interpreter', 'latex', 'FontSize', 15)
ylabel('cTnT [ng/ml]', 'Interpreter', 'latex', 'FontSize', 15)
title('cTnT', 'Interpreter', 'latex', 'FontSize', 15)
set(gca,'FontSize',15)
set(gca,'TickLabelInterpreter','latex')
legend({'Exp. Measures', 'Max peaks', 'First minimum', 'Lb first group', 'Ub first group',...
    'Mean peak group', 'Lb second group', 'Ub second group', 'Mean second group', 'Outlier'}, 'Interpreter', 'latex', 'FontSize', 15);
hold off


