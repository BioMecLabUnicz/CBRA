function varargout = Analysis(varargin)
% ANALYSIS MATLAB code for Analysis.fig
%      ANALYSIS, by itself, creates a new ANALYSIS or raises the existing
%      singleton*.
%
%      H = ANALYSIS returns the handle to a new ANALYSIS or the handle to
%      the existing singleton*.
%
%      ANALYSIS('CALLBACK',hObject,eventData,handles,...) calls the local
%      function named CALLBACK in ANALYSIS.M with the given input arguments.
%
%      ANALYSIS('Property','Value',...) creates a new ANALYSIS or raises the
%      existing singleton*.  Starting from the left, property value pairs are
%      applied to the GUI before Analysis_OpeningFcn gets called.  An
%      unrecognized property name or invalid value makes property application
%      stop.  All inputs are passed to Analysis_OpeningFcn via varargin.
%
%      *See GUI Options on GUIDE's Tools menu.  Choose "GUI allows only one
%      instance to run (singleton)".
%
% See also: GUIDE, GUIDATA, GUIHANDLES

% Edit the above text to modify the response to help Analysis

% Last Modified by GUIDE v2.5 24-Sep-2020 10:55:15

% Begin initialization code - DO NOT EDIT
gui_Singleton = 1;
gui_State = struct('gui_Name',       mfilename, ...
                   'gui_Singleton',  gui_Singleton, ...
                   'gui_OpeningFcn', @Analysis_OpeningFcn, ...
                   'gui_OutputFcn',  @Analysis_OutputFcn, ...
                   'gui_LayoutFcn',  [] , ...
                   'gui_Callback',   []);
if nargin && ischar(varargin{1})
    gui_State.gui_Callback = str2func(varargin{1});
end

if nargout
    [varargout{1:nargout}] = gui_mainfcn(gui_State, varargin{:});
else
    gui_mainfcn(gui_State, varargin{:});
end
% End initialization code - DO NOT EDIT


% --- Executes just before Analysis is made visible.
function Analysis_OpeningFcn(hObject, eventdata, handles, varargin)
% This function has no output args, see OutputFcn.
% hObject    handle to figure
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
% varargin   command line arguments to Analysis (see VARARGIN)

% Choose default command line output for Analysis
handles.output = hObject;

set(handles.output, 'WindowStyle', 'docked')
dbname = 'Biomarcatore';

% Username and Password per accedere al DB
username = 'root';
password = 'root';

% Specifichiamo la tipologia di driver utilizzato
driver = 'com.mysql.jdbc.Driver';

% Specifichiamo l'inidrizzo
dburl = 'jdbc:mysql://localhost:3306/Biomarcatore'; %/useSSL=false&? 
% useSSL=true and verifyServerCertificate=false Perch? su php ssl variables
% risultano DISABLED

% Modifichiamo il classpath 
%currentFolder = pwd;
%path_driver = strcat(currentFolder, '/mysql-connector-java-5.0.8/mysql-connector-java-5.0.8-bin.jar');
%javaclasspath(path_driver);

% Effettuiamo la connessione (.handles aggiunto dopo)
handles.conn = database(dbname, username, password, driver, dburl);
% Update handles structure
set(handles.MessageText,'Visible','off');
set(handles.ResultPanel,'Visible','off');
set(handles.parameters_panel,'Visible','on');
set(handles.advanced_panel,'Visible','off');

set(handles.ctext,'Visible','off');
set(handles.dtext,'Visible','off');
set(handles.kc0text,'Visible','off');
set(handles.ttext,'Visible','off');

set(handles.cresulttext,'Visible','off');
set(handles.dresulttext,'Visible','off');
set(handles.kc0resulttext,'Visible','off');
set(handles.tresulttext,'Visible','off');

set(handles.cRText,'Visible','off');
set(handles.dRText,'Visible','off');
set(handles.Kc0RText,'Visible','off');
set(handles.tRText,'Visible','off');

set(handles.cLowerBound,'Visible','off');
set(handles.dLowerBound,'Visible','off');
set(handles.Kc0LowerBound,'Visible','off');
set(handles.tLowerBound,'Visible','off');

set(handles.cUpperBound,'Visible','off');
set(handles.dUpperBound,'Visible','off');
set(handles.Kc0UpperBound,'Visible','off');
set(handles.tUpperBound,'Visible','off');

set(handles.clb,'Visible','off');
set(handles.dlb,'Visible','off');
set(handles.Kc0lb,'Visible','off');
set(handles.tlb,'Visible','off');

set(handles.cub,'Visible','off');
set(handles.dub,'Visible','off');
set(handles.Kc0ub,'Visible','off');
set(handles.tub,'Visible','off');

set(handles.cErrorText,'Visible','off');
set(handles.dErrorText,'Visible','off');
set(handles.kc0ErrorText,'Visible','off');
set(handles.tErrorText,'Visible','off');

set(handles.cInitValue,'Visible','off');
set(handles.dInitValue,'Visible','off');
set(handles.Kc0InitValue,'Visible','off');
set(handles.tInitValue,'Visible','off');

%set(handles.analisi_popupmenu,'String',{'cTnT', 'cTnT and CK-MB','Infarction Time'});
set(handles.analisi_popupmenu,'String',{'cTnT'});

global selectPat
set(handles.cf_text,'String',selectPat.CF);
set(handles.nome_text,'String', selectPat.nome);
set(handles.cognome_text,'String', selectPat.cognome);
set(handles.dataricovero_text,'String',selectPat.dataricovero);
set(handles.dataevento_text,'String',selectPat.dataevento);
set(handles.oraevento_text,'String',selectPat.oraevento);
set(handles.oraricovero_text,'String',selectPat.oraricovero);

assignin('base', 'V', selectPat.tempi)

set(handles.parameters_panel, 'Visible', 'off');

%% 3. Default Slider value

% Lower and Upper Bound: parameter a
set(handles.aLowerBound, 'value', 0.001);
set(handles.aLowerBound, 'Max', 4.5);
set(handles.aLowerBound, 'Min', 0.001);
set(handles.alb, 'String', 0.001);
handles.aLB = 0.001;

set(handles.aUpperBound, 'value', 5);
set(handles.aUpperBound, 'Max', 5);
set(handles.aUpperBound, 'Min', 0.007);
set(handles.aub, 'String', 5);
handles.aUB = 5;

set(handles.aInitValue, 'String', 0.005);
handles.aIV = 0.005;

% Lower and Upper Bound: parameter b
set(handles.bLowerBound, 'value', 0.001);
set(handles.bLowerBound, 'Max', 4.5 );
set(handles.bLowerBound, 'Min', 0.001);
set(handles.blb, 'String', 0.001);
handles.bLB = 0.001;

set(handles.bUpperBound, 'value', 5);
set(handles.bUpperBound, 'Max', 5);
set(handles.bUpperBound, 'Min', 0.007);
set(handles.bub, 'String', 5);
handles.bUB = 5;

set(handles.bInitValue, 'String', 0.005);
handles.bIV = 0.005;

% Lower and Upper Bound: parameter Td
set(handles.TdLowerBound, 'value', 20);
set(handles.TdLowerBound, 'Max', 280);
set(handles.TdLowerBound, 'Min', 20);
set(handles.Tdlb, 'String', 20);
handles.TdLB = 20;

set(handles.TdUpperBound, 'value', 300);
set(handles.TdUpperBound, 'Max', 300);
set(handles.TdUpperBound, 'Min', 22);
set(handles.Tdub, 'String', 300);
handles.TdUB = 300;

set(handles.TdInitValue, 'String', 30);
handles.TdIV = 30;

% Lower and Upper Bound: parameter Cs0
set(handles.Cs0LowerBound, 'value', 0.001);
set(handles.Cs0LowerBound, 'Max', 180);
set(handles.Cs0LowerBound, 'Min', 0.001);
set(handles.Cs0lb, 'String',0.001);
handles.Cs0LB = 0.001;

set(handles.Cs0UpperBound, 'value', 200);
set(handles.Cs0UpperBound, 'Max', 200);
set(handles.Cs0UpperBound, 'Min', 0.005);
set(handles.Cs0ub, 'String', 200);
handles.Cs0UB = 200;

set(handles.Cs0InitValue, 'String', 0.1);
handles.Cs0IV = 0.1;

% Lower and Upper Bound: parameter Cs0
set(handles.Cc0LowerBound, 'value', 0.1);
set(handles.Cc0LowerBound, 'Max', 380);
set(handles.Cc0LowerBound, 'Min', 0.1);
set(handles.Cc0lb, 'String',0.1);
handles.Cc0LB = 0.1;

set(handles.Cc0UpperBound, 'value', 400);
set(handles.Cc0UpperBound, 'Max', 400);
set(handles.Cc0UpperBound, 'Min', 0.5);
set(handles.Cc0ub, 'String', 400);
handles.Cc0UB = 400;

set(handles.Cc0InitValue, 'String', 1);
handles.Cc0IV = 1;


% Lower and Upper Bound: parameter c
set(handles.cLowerBound, 'value', 0.001);
set(handles.cLowerBound, 'Max', 4.5);
set(handles.cLowerBound, 'Min', 0.001);
set(handles.clb, 'String', 0.001);
handles.cLB = 0.001;

set(handles.cUpperBound, 'value', 5);
set(handles.cUpperBound, 'Max', 5);
set(handles.cUpperBound, 'Min', 0.007);
set(handles.cub, 'String', 5);
handles.cUB = 5;

set(handles.cInitValue, 'String', 0.005);
handles.cIV = 0.005;

% Lower and Upper Bound: parameter d
set(handles.dLowerBound, 'value', 30);%0.001);
set(handles.dLowerBound, 'Max', 290);
set(handles.dLowerBound, 'Min', 30);
set(handles.dlb, 'String', 30);
handles.dLB = 30;

set(handles.dUpperBound, 'value', 300);
set(handles.dUpperBound, 'Max', 300);
set(handles.dUpperBound, 'Min', 35);
set(handles.dub, 'String', 300);
handles.dUB = 300;

set(handles.dInitValue, 'String', 35);
handles.dIV = 35;

% Lower and Upper Bound: parameter Kc0
set(handles.Kc0LowerBound, 'value', 200)%0.1);
set(handles.Kc0LowerBound, 'Max', 1800);
set(handles.Kc0LowerBound, 'Min', 200);
set(handles.Kc0lb, 'String',200);
handles.Kc0LB = 300;

set(handles.Kc0UpperBound, 'value', 2000);
set(handles.Kc0UpperBound, 'Max', 2000);
set(handles.Kc0UpperBound, 'Min', 2.5);
set(handles.Kc0ub, 'String', 2000);
handles.Kc0UB = 2000;

set(handles.Kc0InitValue, 'String', 1000);
handles.Kc0IV = 1000;

% Lower and Upper Bound: parameter Td
set(handles.tLowerBound, 'value', 20);
set(handles.tLowerBound, 'Max', 280);
set(handles.tLowerBound, 'Min', 20);
set(handles.tlb, 'String', 20);
handles.tLB = 20;

set(handles.tUpperBound, 'value', 300);
set(handles.tUpperBound, 'Max', 300);
set(handles.tUpperBound, 'Min', 22);
set(handles.tub, 'String', 300);
handles.tUB = 300;

set(handles.tInitValue, 'String', 30);
handles.tIV = 30;



%% Vector for Lower and Upper Bound

LowerBound = zeros(1,9);
UpperBound = zeros(1,9); 

handles.LowerBound = LowerBound;
handles.UpperBound = UpperBound;

constant_vector = zeros(1,9);
handles.constant_vector  = constant_vector;

handles.AnalysisCurrentPat = {};

%% Initial Value vector

InitialValue = zeros(1,9);
handles.InitialValue = InitialValue;

handles.ErrorV = [0 0 0 0 0 0 0 0 0];
handles.ErrorV2 = 0;

handles.NumberEsecutions = 0;

% Update handles structure
guidata(hObject, handles);

%Plot
axes(handles.axes1)
plot(selectPat.tempi, selectPat.troponina, '*','MarkerSize', 10, 'MarkerEdgeColor','r')
xlabel('Time [h]', 'Interpreter', 'latex', 'FontSize', 15)
ylabel('cTnT [ng/ml]', 'Interpreter', 'latex', 'FontSize', 15)
legend({'cTnT'}, 'Interpreter', 'latex', 'FontSize', 15)
title('cTnT', 'Interpreter', 'latex', 'FontSize', 15)
set(handles.axes1,'FontSize',15)
set(handles.axes1,'TickLabelInterpreter','latex')
grid on


%% Vector for Parameters

%handles.parameters = zeros(1,9);
set(handles.CostantAV, 'Visible', 'off');
set(handles.CostantBV, 'Visible', 'off');
set(handles.CostantTdV, 'Visible', 'off');
set(handles.CostantCV, 'Visible', 'off');
set(handles.CostantDV, 'Visible', 'off');
set(handles.CostantCs0V, 'Visible', 'off');
set(handles.CostantCc0V, 'Visible', 'off');
set(handles.CostantKc0V, 'Visible', 'off');
set(handles.CostantTV, 'Visible', 'off');

handles.constant_vector = zeros(1,9);
handles.numberpoints = 4;

%% Choice Algorithm
GlobalAlgorithm = {'MultiStart', 'Particle Swarm'};
set(handles.AlgorithmPM, 'String', GlobalAlgorithm);
handles.GlobalAlgorithm = 'MultiStart';

%% 1.Multistart: Choice local optimization algorithm
%set(handles.MultistartPanel, 'Visible', 'on');
LocalAlgorithmPPM = {'fmincon', 'lscqurvefit'};
set(handles.LocalAlgorithmPPM, 'String', LocalAlgorithmPPM);
handles.localAlgorithm = 'fmincon';


%% 2. Default number of initial point

set(handles.NumberLocalPoint, 'String', 40);

handles.NLP = 40;


guidata(hObject, handles);


% UIWAIT makes Analysis wait for user response (see UIRESUME)
% uiwait(handles.Analysis);

 
% --- Outputs from this function are returned to the command line.
function varargout = Analysis_OutputFcn(hObject, eventdata, handles) 
% varargout  cell array for returning output args (see VARARGOUT);
% hObject    handle to figure
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Get default command line output from handles structure
varargout{1} = handles.output;


% --- Executes on button press in ckmb_pushbutton.
function ckmb_pushbutton_Callback(hObject, eventdata, handles)
% hObject    handle to ckmb_pushbutton (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% --- Executes on selection change in AlgorithmPM.
function AlgorithmPM_Callback(hObject, eventdata, handles)
% hObject    handle to AlgorithmPM (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
%% Store the Choise Global Algorithm

indexGPM = get(handles.AlgorithmPM, 'Value');
globalAlgorithmStructure = get(handles.AlgorithmPM, 'String');
globalAlgorithm = globalAlgorithmStructure{indexGPM};

if (isequal(globalAlgorithm, 'Particle Swarm') == 1)
    set(handles.MultistartPanel, 'Visible', 'off');
   
else
    set(handles.MultistartPanel, 'Visible', 'on');
    
end

display(globalAlgorithm)


handles.GlobalAlgorithm = globalAlgorithm;

% Hints: contents = cellstr(get(hObject,'String')) returns AlgorithmPM contents as cell array
%        contents{get(hObject,'Value')} returns selected item from AlgorithmPM

guidata(hObject, handles);
% Hints: contents = cellstr(get(hObject,'String')) returns AlgorithmPM contents as cell array
%        contents{get(hObject,'Value')} returns selected item from AlgorithmPM


% --- Executes during object creation, after setting all properties.
function AlgorithmPM_CreateFcn(hObject, eventdata, handles)
% hObject    handle to AlgorithmPM (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: popupmenu controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end


% --- Executes on button press in RunButton.
function RunButton_Callback(hObject, eventdata, handles)

global selectPat

numberExecution = handles.NumberEsecutions +1;
display('***************************************')
display('Number execution')
display(['Number execution' num2str(numberExecution)]);
display('***************************************')

errorV = handles.ErrorV;

if (length(find(errorV == 1)) ~= 0)
    set(handles.MessageText, 'String', 'Error: Initial value Wrong','ForegroundColor', 'red');
    set(handles.MessageText, 'Visible', 'on');

elseif (handles.ErrorV2 == 1)
    set(handles.MessageText, 'String', 'Error: Number of Point Wrong','ForegroundColor', 'red');
    set(handles.MessageText, 'Visible', 'on');

else

handles.stopsimulation = 0;

%% Lower Bound
handles.LowerBound(1) = handles.aLB;
handles.LowerBound(2) = handles.bLB;
handles.LowerBound(5) = handles.TdLB;
handles.LowerBound(6) = handles.Cs0LB;
handles.LowerBound(7) = handles.Cc0LB;

%% Upper Bound
handles.UpperBound(1) = handles.aUB;
handles.UpperBound(2) = handles.bUB;
handles.UpperBound(5) = handles.TdUB;
handles.UpperBound(6) = handles.Cs0UB;
handles.UpperBound(7) = handles.Cc0UB;

%% Initial Values
handles.parameters(1) = handles.aIV;
handles.parameters(2) = handles.bIV;
handles.parameters(5) = handles.TdIV;
handles.parameters(6) = handles.Cs0IV;
handles.parameters(7) = handles.Cc0IV;

if handles.indexmodel == 2
    handles.parameters(3) = handles.cIV;
    handles.parameters(4) = handles.dIV;
    handles.parameters(8) = handles.Kc0IV; 
    handles.UpperBound(3) = handles.cUB;
    handles.UpperBound(4) = handles.dUB;
    handles.UpperBound(8) = handles.Kc0UB;
    handles.LowerBound(3) = handles.cLB;
    handles.LowerBound(4) = handles.dLB;
    handles.LowerBound(8) = handles.Kc0LB;
    
elseif handles.indexmodel == 3
    handles.parameters(9) = handles.tIV;
    handles.UpperBound(9) = handles.tUB;
    handles.LowerBound(9) = handles.tLB;
    
end
%% Run fit

set(handles.MessageText, 'String', 'WAIT.... PLEASE WAIT!', 'ForegroundColor', [1 0 0.4]);
set(handles.MessageText, 'Visible', 'on');

pause(1)

tic
[T, X, params] = troponin_model(selectPat.troponina, selectPat.tempi', @Obj, handles.parameters, handles.constant_vector, handles.GlobalAlgorithm, handles.localAlgorithm, handles.NLP, handles.LowerBound, handles.UpperBound);

timeVal = toc;
assignin('base','T',T)
assignin('base','X',X)

params = 10.^(params);

message = strcat({'Execution Time: '}, {num2str(timeVal/60)}, {' min.'});
set(handles.MessageText, 'String', message, 'ForegroundColor', 'Blue')
set(handles.MessageText, 'Visible', 'on');

set(handles.ResultPanel, 'Visible', 'on');


%% Find the two predicted peak

[v_max, t_max] = min_max(X(:, 3), T);

%% Plot Results
if handles.indexmodel == 1
    cla(handles.axes1)
    axes(handles.axes1)
    plot(selectPat.tempi, selectPat.troponina, '*','MarkerSize', 10)
    hold on 
    plot(T, X(:,3), 'Color', [1 0 0.4],'LineWidth',2)
    plot(t_max, v_max, 'b*','MarkerSize', 10) 
    xlabel('Time [h]', 'Interpreter', 'latex', 'FontSize', 15)
    ylabel('cTnT [ng/ml]', 'Interpreter', 'latex', 'FontSize', 15)
    legend({'cTnT', 'cTnT - model', 'Est. peaks'}, 'Interpreter', 'latex', 'FontSize', 15)
    title('cTnT', 'Interpreter', 'latex', 'FontSize', 15)
    set(handles.axes1,'FontSize',15)
    set(handles.axes1,'TickLabelInterpreter','latex')
    grid on
    hold off
elseif handles.indexmodel == 2
    cla(handles.axes1)
    axes(handles.axes1)
    [hAx,hLine1,hLine2] = plotyy(selectPat.tempi ,selectPat.troponina ,selectPat.tempi ,selectPat.ckmb);
    %set(hAx,'NextPlot','add')  
    hold(hAx(1), 'on')
    plot(hAx(1), T, X(:, 3), 'Color', [0.2 0.5 0.7],'LineWidth',2)
    hold(hAx(2), 'on')
    plot(hAx(2), T, X(:, 5), 'Color', [1 0 0.4],'LineWidth',2)
    xlabel('Time [h]', 'Interpreter', 'latex', 'FontSize', 15);
    ylabel(hAx(1),' cTnT [ng/ml]', 'Interpreter', 'latex', 'FontSize', 15);
    ylabel(hAx(2),'CK-MB [ng/ml]', 'Interpreter', 'latex', 'FontSize', 15);
    title('cTnT and CK-MBs', 'Interpreter', 'latex', 'FontSize', 15)
    legend({'cTnT', 'cTnT - model', 'CK-MB','CK-MB - model'}, 'Interpreter', 'latex', 'FontSize', 15)
    set( hLine1, 'LineStyle', 'none', 'Marker','o','MarkerSize',10)
    set( hLine2, 'LineStyle', 'none','Marker','*','MarkerSize',10)
    set(hAx,'FontSize',15)
    set(hAx,'TickLabelInterpreter','latex')
    grid on
    hold off
elseif handles.indexmodel == 3
    cla(handles.axes1)
    axes(handles.axes1)
    plot(selectPat.tempi, selectPat.troponina, '*','MarkerSize', 10)
    hold on 
    plot(T, X(:,3), 'Color', [1 0 0.4],'LineWidth',2)
    plot(t_max, v_max, 'b*','MarkerSize', 10) 
    xlabel('Time [h]', 'Interpreter', 'latex', 'FontSize', 15)
    ylabel('cTnT [ng/ml]', 'Interpreter', 'latex', 'FontSize', 15)
    legend({'cTnT', 'cTnT - model', 'Est. peaks'}, 'Interpreter', 'latex', 'FontSize', 15)
    title('cTnT', 'Interpreter', 'latex', 'FontSize', 15)
    set(handles.axes1,'FontSize',15)
    set(handles.axes1,'TickLabelInterpreter','latex')
    grid on
    hold off
end
handles.AnalysisCurrentPat{numberExecution}.maxPeakValues = v_max;
handles.AnalysisCurrentPat{numberExecution}.maxPeakTime = t_max;
handles.AnalysisCurrentPat{numberExecution}.T =T;
handles.AnalysisCurrentPat{numberExecution}.X = X;
handles.AnalysisCurrentPat{numberExecution}.FPV = v_max(1);
handles.AnalysisCurrentPat{numberExecution}.FPT = t_max(1);
handles.AnalysisCurrentPat{numberExecution}.SPV = v_max(2);
handles.AnalysisCurrentPat{numberExecution}.SPT = t_max(2);

handles.AnalysisCurrentPat{numberExecution}.parameters = updateResults(params, handles.constant_vector, handles.LowerBound, handles);

set(handles.FPV, 'String', num2str(v_max(1)));
set(handles.FPT, 'String', num2str(t_max(1)));
set(handles.SPV, 'String', num2str(v_max(2)));
set(handles.SPT, 'String', num2str(t_max(2)));


%% Parameters Predicted Values


vector = {};
for i = 1 : numberExecution
    vector{i} = ['Execution' num2str(i)];
end

set(handles.ExecutionRun, 'String', vector);


time = selectPat.tempi';

%% Fitting Quality
if handles.indexmodel == 1 | handles.indexmodel == 2
    
    X_predicted = interp1(T,X(:,3), time);
else 
    X_predicted = interp1(T+params(end),X(:,3), time);
end    

ANR = ANRCom(selectPat.troponina, X_predicted);
set(handles.ANRtext,'String',ANR)

handles.AnalysisCurrentPat{numberExecution}.ANR = ANR;

handles.NumberEsecutions = numberExecution;
end

guidata(hObject, handles);





% --- Executes on button press in DefaultButton.
function DefaultButton_Callback(hObject, eventdata, handles)
% hObject    handle to DefaultButton (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
%% 2. Default number of initial point

set(handles.NumberLocalPoint, 'String', 40);
handles.NLP = 40;


%% 3. Default Slider value
% Lower and Upper Bound: parameter a
set(handles.aLowerBound, 'value', 0.001);
set(handles.aLowerBound, 'Max', 4.5);
set(handles.aLowerBound, 'Min', 0.001);
set(handles.alb, 'String', 0.001);
handles.aLB = 0.001;

set(handles.aUpperBound, 'value', 5);
set(handles.aUpperBound, 'Max', 5);
set(handles.aUpperBound, 'Min', 0.007);
set(handles.aub, 'String', 5);
handles.aUB = 5;

set(handles.aInitValue, 'String', 0.005);
handles.aIV = 0.005;

% Lower and Upper Bound: parameter b
set(handles.bLowerBound, 'value', 0.001);
set(handles.bLowerBound, 'Max', 4.5 );
set(handles.bLowerBound, 'Min', 0.001);
set(handles.blb, 'String', 0.001);
handles.bLB = 0.001;

set(handles.bUpperBound, 'value', 5);
set(handles.bUpperBound, 'Max', 5);
set(handles.bUpperBound, 'Min', 0.007);
set(handles.bub, 'String', 5);
handles.bUB = 5;

set(handles.bInitValue, 'String', 0.005);
handles.bIV = 0.005;

% Lower and Upper Bound: parameter Td
set(handles.TdLowerBound, 'value', 20);
set(handles.TdLowerBound, 'Max', 280);
set(handles.TdLowerBound, 'Min', 20);
set(handles.Tdlb, 'String', 20);
handles.TdLB = 20;

set(handles.TdUpperBound, 'value', 300);
set(handles.TdUpperBound, 'Max', 300);
set(handles.TdUpperBound, 'Min', 22);
set(handles.Tdub, 'String', 300);
handles.TdUB = 300;

set(handles.TdInitValue, 'String', 30);
handles.TdIV = 30;

% Lower and Upper Bound: parameter Cs0
set(handles.Cs0LowerBound, 'value', 0.001);
set(handles.Cs0LowerBound, 'Max', 180);
set(handles.Cs0LowerBound, 'Min', 0.001);
set(handles.Cs0lb, 'String',0.001);
handles.Cs0LB = 0.001;

set(handles.Cs0UpperBound, 'value', 200);
set(handles.Cs0UpperBound, 'Max', 200);
set(handles.Cs0UpperBound, 'Min', 0.005);
set(handles.Cs0ub, 'String', 200);
handles.Cs0UB = 200;

set(handles.Cs0InitValue, 'String', 0.1);
handles.Cs0IV = 0.1;

% Lower and Upper Bound: parameter Cs0
set(handles.Cc0LowerBound, 'value', 0.1);
set(handles.Cc0LowerBound, 'Max', 380);
set(handles.Cc0LowerBound, 'Min', 0.1);
set(handles.Cc0lb, 'String',0.1);
handles.Cc0LB = 0.1;

set(handles.Cc0UpperBound, 'value', 400);
set(handles.Cc0UpperBound, 'Max', 400);
set(handles.Cc0UpperBound, 'Min', 0.5);
set(handles.Cc0ub, 'String', 400);
handles.Cc0UB = 400;

set(handles.Cc0InitValue, 'String', 1);
handles.Cc0IV = 1;
handles.LowerBound = [handles.aLB handles.bLB 0 0 handles.TdLB handles.Cs0LB handles.Cc0LB 0 0];
handles.UpperBound = [handles.aUB handles.bUB 0 0 handles.TdUB handles.Cs0UB handles.Cc0UB 0 0];
handles.InitialValue = [handles.aIV handles.bIV 0 0 handles.TdIV handles.Cs0IV handles.Cc0IV 0 0];

set(handles.EstimateARB, 'Value', 1)
set(handles.ConstantARB, 'Value', 0)
set(handles.CostantAV, 'Visible', 'off')
set(handles.EstimateBRB, 'Value', 1)
set(handles.ConstantBRB, 'Value', 0)
set(handles.CostantBV, 'Visible', 'off')
set(handles.EstimateTdRB, 'Value', 1)
set(handles.ConstantTdRB, 'Value', 0)
set(handles.CostantTdV, 'Visible', 'off')
set(handles.EstimateCs0RB, 'Value', 1)
set(handles.ConstantCs0RB, 'Value', 0)
set(handles.CostantCs0V, 'Visible', 'off')
set(handles.EstimateCc0RB, 'Value', 1)
set(handles.ConstantCc0RB, 'Value', 0)
set(handles.CostantCc0V, 'Visible', 'off')

if handles.indexmodel == 2
    % Lower and Upper Bound: parameter c
    set(handles.cLowerBound, 'value', 0.001);
    set(handles.cLowerBound, 'Max', 4.5);
    set(handles.cLowerBound, 'Min', 0.001);
    set(handles.clb, 'String', 0.001);
    handles.cLB = 0.001;

    set(handles.cUpperBound, 'value', 5);
    set(handles.cUpperBound, 'Max', 5);
    set(handles.cUpperBound, 'Min', 0.007);
    set(handles.cub, 'String', 5);
    handles.cUB = 5;

    set(handles.cInitValue, 'String', 0.005);
    handles.cIV = 0.005;

    % Lower and Upper Bound: parameter d
    set(handles.dLowerBound, 'value', 0.001);
    set(handles.dLowerBound, 'Max', 4.5);
    set(handles.dLowerBound, 'Min', 0.001);
    set(handles.dlb, 'String', 0.001);
    handles.dLB = 0.001;

    set(handles.dUpperBound, 'value', 5);
    set(handles.dUpperBound, 'Max', 5);
    set(handles.dUpperBound, 'Min', 0.007);
    set(handles.dub, 'String', 5);
    handles.dUB = 5;

    set(handles.dInitValue, 'String', 0.005);
    handles.dIV = 0.005;

    % Lower and Upper Bound: parameter Kc0
    set(handles.Kc0LowerBound, 'value', 0.1);
    set(handles.Kc0LowerBound, 'Max', 380);
    set(handles.Kc0LowerBound, 'Min', 0.1);
    set(handles.Kc0lb, 'String',0.1);
    handles.Kc0LB = 0.1;

    set(handles.Kc0UpperBound, 'value', 400);
    set(handles.Kc0UpperBound, 'Max', 400);
    set(handles.Kc0UpperBound, 'Min', 0.5);
    set(handles.Kc0ub, 'String', 400);
    handles.Kc0UB = 400;

    set(handles.Kc0InitValue, 'String', 1);
    handles.Kc0IV = 1;

    set(handles.EstimateCRB, 'Value', 1)
    set(handles.ConstantCRB, 'Value', 0)
    set(handles.CostantCV, 'Visible', 'off')
    set(handles.EstimateDRB, 'Value', 1)
    set(handles.ConstantDRB, 'Value', 0)
    set(handles.CostantDV, 'Visible', 'off')
    set(handles.EstimateKc0RB, 'Value', 1)
    set(handles.ConstantKc0RB, 'Value', 0)
    set(handles.CostantKc0V, 'Visible', 'off')
    
elseif handles.indexmodel == 3
% Lower and Upper Bound: parameter Td
    set(handles.tLowerBound, 'value', 20);
    set(handles.tLowerBound, 'Max', 280);
    set(handles.tLowerBound, 'Min', 20);
    set(handles.tlb, 'String', 20);
    handles.tLB = 20;

    set(handles.tUpperBound, 'value', 300);
    set(handles.tUpperBound, 'Max', 300);
    set(handles.tUpperBound, 'Min', 22);
    set(handles.tub, 'String', 300);
    handles.tUB = 300;

    set(handles.tInitValue, 'String', 30);
    handles.tIV = 30;

    
    set(handles.EstimateTB, 'Value', 1)
    set(handles.ConstantTB, 'Value', 0)
    set(handles.CostantTV, 'Visible', 'off')
end

set(handles.aErrorText, 'visible', 'off');
set(handles.bErrorText, 'visible', 'off');
set(handles.cErrorText, 'visible', 'off');
set(handles.dErrorText, 'visible', 'off');
set(handles.TdErrorText, 'visible', 'off');
set(handles.Cs0ErrorText, 'visible', 'off');
set(handles.Cc0ErrorText, 'visible', 'off');
set(handles.kc0ErrorText, 'visible', 'off');
set(handles.tErrorText, 'visible', 'off');
set(handles.MessageText, 'visible', 'off');

%% Vector for Lower and Upper Bound
handles.constant_vector  = zeros(1,9);
%% Initial Value vector
handles.ErrorV = [0 0 0 0 0 0 0 0 0];
handles.ErrorV2 = 0;
guidata(hObject, handles);


% --- Executes on selection change in LocalAlgorithmPPM.
function LocalAlgorithmPPM_Callback(hObject, eventdata, handles)
% hObject    handle to LocalAlgorithmPPM (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
%% Store the choise algorithm

indexLPM = get(handles.LocalAlgorithmPPM, 'Value');
localAlgorithmStructure = get(handles.LocalAlgorithmPPM, 'String');
localAlgorithm = localAlgorithmStructure{indexLPM};

display(localAlgorithm);

handles.localAlgorithm = localAlgorithm;

% Hints: contents = cellstr(get(hObject,'String')) returns LocalAlgorithmPPM contents as cell array
%        contents{get(hObject,'Value')} returns selected item from LocalAlgorithmPPM
guidata(hObject, handles);

% Hints: contents = cellstr(get(hObject,'String')) returns LocalAlgorithmPPM contents as cell array
%        contents{get(hObject,'Value')} returns selected item from LocalAlgorithmPPM


% --- Executes during object creation, after setting all properties.
function LocalAlgorithmPPM_CreateFcn(hObject, eventdata, handles)
% hObject    handle to LocalAlgorithmPPM (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: popupmenu controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end

function CostantAV_Callback(hObject, eventdata, handles)
% hObject    handle to CostantAV (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
value = str2num(get(handles.CostantAV, 'String'));
handles.constant_vector(1) = value;

% Hints: get(hObject,'String') returns contents of CostantAV as text
%        str2double(get(hObject,'String')) returns contents of CostantAV as a double

guidata(hObject, handles);
% Hints: get(hObject,'String') returns contents of CostantAV as text
%        str2double(get(hObject,'String')) returns contents of CostantAV as a double


% --- Executes during object creation, after setting all properties.
function CostantAV_CreateFcn(hObject, eventdata, handles)
% hObject    handle to CostantAV (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end



function CostantBV_Callback(hObject, eventdata, handles)
% hObject    handle to CostantBV (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
value = str2num(get(handles.CostantBV, 'String'));
handles.constant_vector(2) = value;

% Hints: get(hObject,'String') returns contents of CostantAV as text
%        str2double(get(hObject,'String')) returns contents of CostantAV as a double

guidata(hObject, handles);
% Hints: get(hObject,'String') returns contents of CostantBV as text
%        str2double(get(hObject,'String')) returns contents of CostantBV as a double


% --- Executes during object creation, after setting all properties.
function CostantBV_CreateFcn(hObject, eventdata, handles)
% hObject    handle to CostantBV (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end



function CostantCs0V_Callback(hObject, eventdata, handles)
% hObject    handle to CostantCs0V (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
value = str2num(get(handles.CostantCs0V, 'String'));
handles.constant_vector(6) = value;

% Hints: get(hObject,'String') returns contents of CostantAV as text
%        str2double(get(hObject,'String')) returns contents of CostantAV as a double

guidata(hObject, handles);

% Hints: get(hObject,'String') returns contents of CostantCs0V as text
%        str2double(get(hObject,'String')) returns contents of CostantCs0V as a double


% --- Executes during object creation, after setting all properties.
function CostantCs0V_CreateFcn(hObject, eventdata, handles)
% hObject    handle to CostantCs0V (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end



function CostantCc0V_Callback(hObject, eventdata, handles)
% hObject    handle to CostantCc0V (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
value = str2num(get(handles.CostantCc0V, 'String'));
handles.constant_vector(7) = value;

% Hints: get(hObject,'String') returns contents of CostantAV as text
%        str2double(get(hObject,'String')) returns contents of CostantAV as a double

guidata(hObject, handles);

% Hints: get(hObject,'String') returns contents of CostantCc0V as text
%        str2double(get(hObject,'String')) returns contents of CostantCc0V as a double


% --- Executes during object creation, after setting all properties.
function CostantCc0V_CreateFcn(hObject, eventdata, handles)
% hObject    handle to CostantCc0V (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end



function CostantTdV_Callback(hObject, eventdata, handles)
% hObject    handle to CostantTdV (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
value = str2num(get(handles.CostantTdV, 'String'));
handles.constant_vector(5) = value;
% Hints: get(hObject,'String') returns contents of CostantAV as text
%        str2double(get(hObject,'String')) returns contents of CostantAV as a double

guidata(hObject, handles);
% Hints: get(hObject,'String') returns contents of CostantTdV as text
%        str2double(get(hObject,'String')) returns contents of CostantTdV as a double


% --- Executes during object creation, after setting all properties.
function CostantTdV_CreateFcn(hObject, eventdata, handles)
% hObject    handle to CostantTdV (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end


% --- Executes on selection change in ExecutionRun.
function ExecutionRun_Callback(hObject, eventdata, handles)
global selectPat

indexExecution = get(handles.ExecutionRun, 'Value');
set(handles.aRText, 'String', num2str(handles.AnalysisCurrentPat{indexExecution}.parameters(1)));
set(handles.bRText, 'String', num2str(handles.AnalysisCurrentPat{indexExecution}.parameters(2)));
set(handles.TdRText, 'String', num2str(handles.AnalysisCurrentPat{indexExecution}.parameters(5)));
set(handles.Cs0RText, 'String', num2str(handles.AnalysisCurrentPat{indexExecution}.parameters(6)));
set(handles.Cc0RText, 'String', num2str(handles.AnalysisCurrentPat{indexExecution}.parameters(7)));

if handles.indexmodel == 1 | handles.indexmodel == 3
    cla(handles.axes1)
    axes(handles.axes1)
    plot(selectPat.tempi, selectPat.troponina, '*','MarkerSize', 10)
    hold on 
    plot(handles.AnalysisCurrentPat{indexExecution}.T, handles.AnalysisCurrentPat{indexExecution}.X(:,3), 'Color', [1 0 0.4],'LineWidth',2)
    xlabel('Time [h]', 'Interpreter', 'latex', 'FontSize', 15)
    ylabel('cTnT [ng/ml]', 'Interpreter', 'latex', 'FontSize', 15)
    legend({'cTnT', 'cTnT - model'}, 'Interpreter', 'latex', 'FontSize', 15)
    title('cTnT', 'Interpreter', 'latex', 'FontSize', 15)
    set(handles.axes1,'FontSize',15)
    set(handles.axes1,'TickLabelInterpreter','latex')
    grid on
    hold off

elseif handles.indexmodel == 2
    cla(handles.axes1)
    axes(handles.axes1)
    [hAx,hLine1,hLine2] = plotyy(selectPat.tempi ,selectPat.troponina ,selectPat.tempi ,selectPat.ckmb);
    set(hAx,'NextPlot','add')    
    plot(hAx(1), handles.AnalysisCurrentPat{indexExecution}.T, handles.AnalysisCurrentPat{indexExecution}.X(:, 3), 'Color', [0.2 0.5 0.7],'LineWidth',2)
    plot(hAx(2), handles.AnalysisCurrentPat{indexExecution}.T, handles.AnalysisCurrentPat{indexExecution}.X(:, 5), 'Color', [1 0 0.4],'LineWidth',2)
    xlabel('Time [h]', 'Interpreter', 'latex', 'FontSize', 15);
    ylabel(hAx(1),' cTnT [ng/ml]', 'Interpreter', 'latex', 'FontSize', 15);
    ylabel(hAx(2),'CK-MB [ng/ml]', 'Interpreter', 'latex', 'FontSize', 15);
    title('cTnT and CK-MBs', 'Interpreter', 'latex', 'FontSize', 15)
    legend({'cTnT', 'cTnT - model', 'CK-MB','CK-MB - model'}, 'Interpreter', 'latex', 'FontSize', 15)
    set( hLine1, 'LineStyle', 'none', 'Marker','o','MarkerSize',10)
    set( hLine2, 'LineStyle', 'none','Marker','*','MarkerSize',10)
    set(hAx,'FontSize',15)
    set(hAx,'TickLabelInterpreter','latex')
    grid on
    hold off
    set(handles.Kc0RText, 'String', num2str(handles.AnalysisCurrentPat{indexExecution}.parameters(8)));
    set(handles.cRText, 'String', num2str(handles.AnalysisCurrentPat{indexExecution}.parameters(3)));
    set(handles.dRText, 'String', num2str(handles.AnalysisCurrentPat{indexExecution}.parameters(4)));
    handles.axes1 = hAx;
elseif handles.indexmodel == 3
    set(handles.tText, 'String', num2str(handles.AnalysisCurrentPat{indexExecution}.parameters(9)));
end 
    handles.indiceesecuzione = indexExecution;
    set(handles.FPV, 'String', num2str(handles.AnalysisCurrentPat{indexExecution}.FPV));
    set(handles.FPT, 'String', num2str(handles.AnalysisCurrentPat{indexExecution}.FPT));
    set(handles.SPV, 'String', num2str(handles.AnalysisCurrentPat{indexExecution}.SPV));
    set(handles.SPT, 'String', num2str(handles.AnalysisCurrentPat{indexExecution}.SPT));
    set(handles.ANRtext, 'String', num2str(handles.AnalysisCurrentPat{indexExecution}.ANR));
guidata(hObject, handles);

% Hints: contents = cellstr(get(hObject,'String')) returns ExecutionRun contents as cell array
%        contents{get(hObject,'Value')} returns selected item from ExecutionRun


% --- Executes during object creation, after setting all properties.
function ExecutionRun_CreateFcn(hObject, eventdata, handles)
% hObject    handle to ExecutionRun (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: popupmenu controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end


% --- Executes on button press in SaveDataButton.
function SaveDataButton_Callback(hObject, eventdata, handles)
%% Salvataggio dati nel Database
%  1) Specifichiamo il nome della tabella
tablename = 'DatiSimulazione';
global selectPat
%  2) Specifichiamo il nome delle colonne della tabella
colnames = {'CF', 'DataEvento', 'OraEvento','DataRicovero','OraRicovero', 'DataAnalisi', 'OraAnalisi', 'a' , 'b', 'c','d', 'Td','Cs0', 'Cc0','Kc0','t', 'FPV','FPT','SPT','SPV'};
d = split(cellstr(datetime('now')));
dataanalisi = d{1};
oraanalisi = d{2};

indexExecution = handles.indiceesecuzione;

if isempty(indexExecution) == 0
%  3) Specifichiamo la tupla da inserire
if handles.indexmodel == 1
    insertdata_array = {selectPat.CF ,selectPat.dataevento , selectPat.oraevento, selectPat.dataricovero ,selectPat.oraricovero, dataanalisi, oraanalisi , num2str(handles.AnalysisCurrentPat{indexExecution}.parameters(1)) , num2str(handles.AnalysisCurrentPat{indexExecution}.parameters(2)), '0', '0', num2str(handles.AnalysisCurrentPat{indexExecution}.parameters(5)), num2str(handles.AnalysisCurrentPat{indexExecution}.parameters(6)), num2str(handles.AnalysisCurrentPat{indexExecution}.parameters(7)), '0','0', num2str(handles.AnalysisCurrentPat{indexExecution}.FPV), num2str(handles.AnalysisCurrentPat{indexExecution}.FPT), num2str(handles.AnalysisCurrentPat{indexExecution}.SPV),num2str(handles.AnalysisCurrentPat{indexExecution}.SPT)};
elseif handles.indexmodel == 2
    insertdata_array = {selectPat.CF ,selectPat.dataevento , selectPat.oraevento, selectPat.dataricovero ,selectPat.oraricovero, dataanalisi, oraanalisi , num2str(handles.AnalysisCurrentPat{indexExecution}.parameters(1)) , num2str(handles.AnalysisCurrentPat{indexExecution}.parameters(2)), num2str(handles.AnalysisCurrentPat{indexExecution}.parameters(3)), num2str(handles.AnalysisCurrentPat{indexExecution}.parameters(4)), num2str(handles.AnalysisCurrentPat{indexExecution}.parameters(5)), num2str(handles.AnalysisCurrentPat{indexExecution}.parameters(6)), num2str(handles.AnalysisCurrentPat{indexExecution}.parameters(7)), num2str(handles.AnalysisCurrentPat{indexExecution}.parameters(8)),'0', num2str(handles.AnalysisCurrentPat{indexExecution}.FPV), num2str(handles.AnalysisCurrentPat{indexExecution}.FPT), num2str(handles.AnalysisCurrentPat{indexExecution}.SPV),num2str(handles.AnalysisCurrentPat{indexExecution}.SPT)};
else
    insertdata_array = {selectPat.CF ,selectPat.dataevento , selectPat.oraevento, selectPat.dataricovero ,selectPat.oraricovero, dataanalisi, oraanalisi , num2str(handles.AnalysisCurrentPat{indexExecution}.parameters(1)) , num2str(handles.AnalysisCurrentPat{indexExecution}.parameters(2)), '0', '0', num2str(handles.AnalysisCurrentPat{indexExecution}.parameters(5)), num2str(handles.AnalysisCurrentPat{indexExecution}.parameters(6)), num2str(handles.AnalysisCurrentPat{indexExecution}.parameters(7)), '0',num2str(handles.AnalysisCurrentPat{indexExecution}.parameters(9)), num2str(handles.AnalysisCurrentPat{indexExecution}.FPV), num2str(handles.AnalysisCurrentPat{indexExecution}.FPT), num2str(handles.AnalysisCurrentPat{indexExecution}.SPV),num2str(handles.AnalysisCurrentPat{indexExecution}.SPT)};
end
else
    set(handles.MessageText,'String','Please select the analysis to save');
end
insertdata = cell2table(insertdata_array, 'VariableNames', colnames);
fastinsert(handles.conn,tablename,colnames,insertdata);
guidata(hObject, handles);
% hObject    handle to SaveDataButton (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% --- Executes on slider movement.
function aLowerBound_Callback(hObject, eventdata, handles)
% hObject    handle to aLowerBound (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'Value') returns position of slider
%        get(hObject,'Min') and get(hObject,'Max') to determine range of slider
%% Visualization of slider value

alb = get(handles.aLowerBound, 'Value');
set(handles.alb, 'String', num2str(alb));

%% Save current value
handles.aLB = alb;

set(handles.aUpperBound, 'Min', (handles.aLB + handles.aLB/100));
set(handles.aUpperBound, 'value', (handles.aLB + handles.aLB/100));
set(handles.aInitValue, 'String', handles.aLB);
% Hints: get(hObject,'Value') returns position of slider
%        get(hObject,'Min') and get(hObject,'Max') to determine range of slider
guidata(hObject, handles);

% --- Executes during object creation, after setting all properties.
function aLowerBound_CreateFcn(hObject, eventdata, handles)
% hObject    handle to aLowerBound (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: slider controls usually have a light gray background.
if isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor',[.9 .9 .9]);
end


% --- Executes on slider movement.
function Cs0LowerBound_Callback(hObject, eventdata, handles)
% hObject    handle to Cs0LowerBound (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'Value') returns position of slider
%        get(hObject,'Min') and get(hObject,'Max') to determine range of slider
%% Visualization of slider value

Cs0lb = get(handles.Cs0LowerBound, 'Value');
set(handles.Cs0lb, 'String', num2str(Cs0lb));

%% Save current value
handles.Cs0LB = Cs0lb;
set(handles.Cs0UpperBound, 'Min', (handles.Cs0LB + handles.Cs0LB/100));
set(handles.Cs0UpperBound, 'value', (handles.Cs0LB + handles.Cs0LB/100));
set(handles.Cs0InitValue, 'String', handles.Cs0LB);
% Hints: get(hObject,'Value') returns position of slider
%        get(hObject,'Min') and get(hObject,'Max') to determine range of slider
guidata(hObject, handles);

% --- Executes during object creation, after setting all properties.
function Cs0LowerBound_CreateFcn(hObject, eventdata, handles)
% hObject    handle to Cs0LowerBound (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: slider controls usually have a light gray background.
if isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor',[.9 .9 .9]);
end


% --- Executes on slider movement.
function bLowerBound_Callback(hObject, eventdata, handles)
% hObject    handle to bLowerBound (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'Value') returns position of slider
%        get(hObject,'Min') and get(hObject,'Max') to determine range of slider
blb = get(handles.bLowerBound, 'Value');
set(handles.blb, 'String', num2str(blb));

%% Save current value
handles.bLB = blb;
set(handles.bUpperBound, 'Min', (handles.bLB + handles.bLB/100));
set(handles.bUpperBound, 'value', (handles.bLB + handles.bLB/100));
set(handles.bInitValue, 'String', handles.bLB);
% Hints: get(hObject,'Value') returns position of slider
%        get(hObject,'Min') and get(hObject,'Max') to determine range of slider
guidata(hObject, handles);


% --- Executes during object creation, after setting all properties.
function bLowerBound_CreateFcn(hObject, eventdata, handles)
% hObject    handle to bLowerBound (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: slider controls usually have a light gray background.
if isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor',[.9 .9 .9]);
end


% --- Executes on slider movement.
function Cc0LowerBound_Callback(hObject, eventdata, handles)
% hObject    handle to Cc0LowerBound (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'Value') returns position of slider
%        get(hObject,'Min') and get(hObject,'Max') to determine range of slider
Cc0lb = get(handles.Cc0LowerBound, 'Value');
set(handles.Cc0lb, 'String', num2str(Cc0lb))

%% Save current value
handles.Cc0LB = Cc0lb;
set(handles.Cc0UpperBound, 'Min', (handles.Cc0LB + handles.Cc0LB/100));
set(handles.Cc0UpperBound, 'value', (handles.Cc0LB + handles.Cc0LB/100));
set(handles.Cc0InitValue, 'String', handles.Cc0LB);
% Hints: get(hObject,'Value') returns position of slider
%        get(hObject,'Min') and get(hObject,'Max') to determine range of slider
guidata(hObject, handles);

% --- Executes during object creation, after setting all properties.
function Cc0LowerBound_CreateFcn(hObject, eventdata, handles)
% hObject    handle to Cc0LowerBound (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: slider controls usually have a light gray background.
if isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor',[.9 .9 .9]);
end


% --- Executes on slider movement.
function TdLowerBound_Callback(hObject, eventdata, handles)
% hObject    handle to TdLowerBound (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'Value') returns position of slider
%        get(hObject,'Min') and get(hObject,'Max') to determine range of slider
%% Visualization of slider value

Tdlb = get(handles.TdLowerBound, 'Value');
set(handles.Tdlb, 'String', num2str(Tdlb))

%% Save current value
handles.TdLB = Tdlb;
set(handles.TdUpperBound, 'Min', (handles.TdLB + handles.TdLB/100));
set(handles.TdUpperBound, 'value', (handles.TdLB + handles.TdLB/100));
set(handles.TdInitValue, 'String', handles.TdLB);
% Hints: get(hObject,'Value') returns position of slider
%        get(hObject,'Min') and get(hObject,'Max') to determine range of slider
guidata(hObject, handles);

% --- Executes during object creation, after setting all properties.
function TdLowerBound_CreateFcn(hObject, eventdata, handles)
% hObject    handle to TdLowerBound (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: slider controls usually have a light gray background.
if isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor',[.9 .9 .9]);
end


% --- Executes on slider movement.
function aUpperBound_Callback(hObject, eventdata, handles)
% hObject    handle to aUpperBound (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'Value') returns position of slider
%        get(hObject,'Min') and get(hObject,'Max') to determine range of slider
%% Visualization of slider value

aub = get(handles.aUpperBound, 'value');
set(handles.aub, 'String', num2str(aub))

%% Save current value
handles.aUB = aub;

% Hints: get(hObject,'Value') returns position of slider
%        get(hObject,'Min') and get(hObject,'Max') to determine range of slider
guidata(hObject, handles);

% --- Executes during object creation, after setting all properties.
function aUpperBound_CreateFcn(hObject, eventdata, handles)
% hObject    handle to aUpperBound (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: slider controls usually have a light gray background.
if isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor',[.9 .9 .9]);
end


% --- Executes on slider movement.
function Cs0UpperBound_Callback(hObject, eventdata, handles)
% hObject    handle to Cs0UpperBound (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'Value') returns position of slider
%        get(hObject,'Min') and get(hObject,'Max') to determine range of slider
%% Visualization of slider value

Cs0ub = get(handles.Cs0UpperBound, 'Value');
set(handles.Cs0ub, 'String', num2str(Cs0ub))

%% Save current value
handles.Cs0UB = Cs0ub;

% Hints: get(hObject,'Value') returns position of slider
%        get(hObject,'Min') and get(hObject,'Max') to determine range of slider
guidata(hObject, handles);


% --- Executes during object creation, after setting all properties.
function Cs0UpperBound_CreateFcn(hObject, eventdata, handles)
% hObject    handle to Cs0UpperBound (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: slider controls usually have a light gray background.
if isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor',[.9 .9 .9]);
end


% --- Executes on slider movement.
function bUpperBound_Callback(hObject, eventdata, handles)
% hObject    handle to bUpperBound (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
%% Visualization of slider value

bub = get(handles.bUpperBound, 'Value');
set(handles.bub, 'String', num2str(bub))

%% Save current value
handles.bUB = bub;

% Hints: get(hObject,'Value') returns position of slider
%        get(hObject,'Min') and get(hObject,'Max') to determine range of slider
guidata(hObject, handles);
% Hints: get(hObject,'Value') returns position of slider
%        get(hObject,'Min') and get(hObject,'Max') to determine range of slider


% --- Executes during object creation, after setting all properties.
function bUpperBound_CreateFcn(hObject, eventdata, handles)
% hObject    handle to bUpperBound (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: slider controls usually have a light gray background.
if isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor',[.9 .9 .9]);
end


% --- Executes on slider movement.
function Cc0UpperBound_Callback(hObject, eventdata, handles)
% hObject    handle to Cc0UpperBound (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'Value') returns position of slider
%        get(hObject,'Min') and get(hObject,'Max') to determine range of slider
%% Visualization of slider value

Cc0ub = get(handles.Cc0UpperBound, 'Value');
set(handles.Cc0ub, 'String', num2str(Cc0ub))

%% Save current value
handles.Cc0UB = Cc0ub;



% Hints: get(hObject,'Value') returns position of slider
%        get(hObject,'Min') and get(hObject,'Max') to determine range of slider
guidata(hObject, handles);

% --- Executes during object creation, after setting all properties.
function Cc0UpperBound_CreateFcn(hObject, eventdata, handles)
% hObject    handle to Cc0UpperBound (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: slider controls usually have a light gray background.
if isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor',[.9 .9 .9]);
end


% --- Executes on slider movement.
function TdUpperBound_Callback(hObject, eventdata, handles)
% hObject    handle to TdUpperBound (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'Value') returns position of slider
%        get(hObject,'Min') and get(hObject,'Max') to determine range of slider
Tdub = get(handles.TdUpperBound, 'Value');
set(handles.Tdub, 'String', num2str(Tdub))

%% Save current value
handles.TdUB = Tdub;


% Hints: get(hObject,'Value') returns position of slider
%        get(hObject,'Min') and get(hObject,'Max') to determine range of slider
guidata(hObject, handles);

% --- Executes during object creation, after setting all properties.
function TdUpperBound_CreateFcn(hObject, eventdata, handles)
% hObject    handle to TdUpperBound (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: slider controls usually have a light gray background.
if isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor',[.9 .9 .9]);
end



function aInitValue_Callback(hObject, eventdata, handles)
% hObject    handle to aInitValue (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
aIV = str2num(get(handles.aInitValue, 'String'));

errorV = 0;
%% Check on value
if ((aIV < handles.aLB))
    set(handles.aErrorText, 'String', ' value < lb', 'ForegroundColor', 'red')
    errorV = 1;
elseif ((aIV > handles.aUB))
    set(handles.aErrorText, 'String', ' value > ub', 'ForegroundColor', 'red')
    errorV = 1;
    
else
    set(handles.aErrorText, 'String', '')
    errorV = 0;
    handles.aIV = aIV;
end
handles.ErrorV(1) = errorV;
% Hints: get(hObject,'String') returns contents of aInitValue as text
%        str2double(get(hObject,'String')) returns contents of aInitValue as a double
guidata(hObject, handles);
% Hints: get(hObject,'String') returns contents of aInitValue as text
%        str2double(get(hObject,'String')) returns contents of aInitValue as a double


% --- Executes during object creation, after setting all properties.
function aInitValue_CreateFcn(hObject, eventdata, handles)
% hObject    handle to aInitValue (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end



function bInitValue_Callback(hObject, eventdata, handles)
% hObject    handle to bInitValue (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
bIV = str2num(get(handles.bInitValue, 'String'));
errorV = 0;
%% Check on value
if ((bIV < handles.bLB))
    set(handles.bErrorText, 'String', ' value < lb', 'ForegroundColor', 'red')
    errorV = 1;
elseif ((bIV > handles.bUB))
    set(handles.bErrorText, 'String', ' value > ub', 'ForegroundColor', 'red')
    errorV = 1;
    
else
    set(handles.bErrorText, 'String', '')
    errorV = 0;
    handles.bIV = bIV;
end
handles.ErrorV(2) = errorV;
% Hints: get(hObject,'String') returns contents of bInitValue as text
%        str2double(get(hObject,'String')) returns contents of bInitValue as a double
guidata(hObject, handles);
% Hints: get(hObject,'String') returns contents of bInitValue as text
%        str2double(get(hObject,'String')) returns contents of bInitValue as a double


% --- Executes during object creation, after setting all properties.
function bInitValue_CreateFcn(hObject, eventdata, handles)
% hObject    handle to bInitValue (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end



function Cs0InitValue_Callback(hObject, eventdata, handles)
% hObject    handle to Cs0InitValue (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
Cs0IV = str2num(get(handles.Cs0InitValue, 'String'));
errorV = 0;

%% Check on value
if ((Cs0IV < handles.Cs0LB))
    set(handles.Cs0ErrorText, 'String', ' value < lb', 'ForegroundColor', 'red')
    errorV = 1;
elseif ((Cs0IV > handles.Cs0UB))
    set(handles.Cs0ErrorText, 'String', ' value > ub', 'ForegroundColor', 'red')
    errorV = 1;
    
else
    set(handles.Cs0ErrorText, 'String', '')
    errorV = 0;
    handles.Cs0IV = Cs0IV;
end
handles.ErrorV(4) = errorV;

% Hints: get(hObject,'String') returns contents of Cs0InitValue as text
%        str2double(get(hObject,'String')) returns contents of Cs0InitValue as a double
guidata(hObject, handles);
% Hints: get(hObject,'String') returns contents of Cs0InitValue as text
%        str2double(get(hObject,'String')) returns contents of Cs0InitValue as a double


% --- Executes during object creation, after setting all properties.
function Cs0InitValue_CreateFcn(hObject, eventdata, handles)
% hObject    handle to Cs0InitValue (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end



function Cc0InitValue_Callback(hObject, eventdata, handles)
% hObject    handle to Cc0InitValue (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
Cc0IV = str2num(get(handles.Cc0InitValue, 'String'));
errorV = 0;
%% Check on value
if ((Cc0IV < handles.Cc0LB))
    set(handles.Cc0ErrorText, 'String', ' value < lb', 'ForegroundColor', 'red')
    errorV = 1;
elseif ((Cc0IV > handles.Cc0UB))
    set(handles.Cc0ErrorText, 'String', ' value > ub', 'ForegroundColor', 'red')
    errorV = 1;
    
else
    set(handles.Cc0ErrorText, 'String', '')
    errorV = 0;
    handles.Cc0IV = Cc0IV;
end

handles.ErrorV(5) = errorV;

% Hints: get(hObject,'String') returns contents of Cc0InitValue as text
%        str2double(get(hObject,'String')) returns contents of Cc0InitValue as a double
guidata(hObject, handles);
% Hints: get(hObject,'String') returns contents of Cc0InitValue as text
%        str2double(get(hObject,'String')) returns contents of Cc0InitValue as a double


% --- Executes during object creation, after setting all properties.
function Cc0InitValue_CreateFcn(hObject, eventdata, handles)
% hObject    handle to Cc0InitValue (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end



function TdInitValue_Callback(hObject, eventdata, handles)
% hObject    handle to TdInitValue (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
TdIV = str2num(get(handles.TdInitValue, 'String'));
errorV = 0;
%% Check on value
if ((TdIV < handles.TdLB))
    set(handles.TdErrorText, 'String', ' value < lb', 'ForegroundColor', 'red')
    errorV = 1;
elseif ((TdIV > handles.TdUB))
    set(handles.TdErrorText, 'String', ' value > ub', 'ForegroundColor', 'red')
    errorV = 1;
    
else
    set(handles.TdErrorText, 'String', '')
    errorV = 0;
    handles.TdIV = TdIV;
end

handles.ErrorV(3) = errorV;

% Hints: get(hObject,'String') returns contents of TdInitValue as text
%        str2double(get(hObject,'String')) returns contents of TdInitValue as a double
guidata(hObject, handles);
% Hints: get(hObject,'String') returns contents of TdInitValue as text
%        str2double(get(hObject,'String')) returns contents of TdInitValue as a double


% --- Executes during object creation, after setting all properties.
function TdInitValue_CreateFcn(hObject, eventdata, handles)
% hObject    handle to TdInitValue (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end


% --- Executes on button press in pushbutton10.
function pushbutton10_Callback(hObject, eventdata, handles)
% hObject    handle to pushbutton10 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)


% --- Executes on selection change in analisi_popupmenu.
function analisi_popupmenu_Callback(hObject, eventdata, handles)
indexmodel = get(handles.analisi_popupmenu,'Value');
cla(handles.axes1)
model = get(handles.analisi_popupmenu, 'String'); %in pat metto tutti i pz
sel_model = model{indexmodel}; %paz selezionato in sel
handles.sel_model = sel_model;

global selectPat
if indexmodel == 1
    
    set(handles.parameters_panel,'Visible','on');
    cla(handles.axes1)
    axes(handles.axes1)
    plot(selectPat.tempi, selectPat.troponina, '*','MarkerSize', 10, 'MarkerEdgeColor','r')
    xlabel('Time  [h]', 'Interpreter', 'latex', 'FontSize', 15)
    ylabel('cTnT [ng/ml]', 'Interpreter', 'latex', 'FontSize', 15)
    legend({'cTnT'}, 'Interpreter', 'latex', 'FontSize', 15)
    title('cTnT', 'Interpreter', 'latex', 'FontSize', 15)
    set(handles.axes1,'FontSize',15)
    set(handles.axes1,'TickLabelInterpreter','latex')
    grid on

    
    handles.parameters = [handles.aIV handles.bIV 0 0 handles.TdIV handles.Cs0IV handles.Cc0IV 0 0];
    handles.LowerBound  = [handles.aLB handles.bLB 0 0 handles.TdLB handles.Cs0LB handles.Cc0LB 0 0];
    handles.UpperBound = [handles.aUB handles.bUB 0 0 handles.TdUB handles.Cs0UB handles.Cc0UB 0 0];
    
    set(handles.ctext,'Visible','off');
    set(handles.dtext,'Visible','off');
    set(handles.kc0text,'Visible','off');
    set(handles.ttext,'Visible','off');

    set(handles.cresulttext,'Visible','off');
    set(handles.dresulttext,'Visible','off');
    set(handles.kc0resulttext,'Visible','off');
    set(handles.tresulttext,'Visible','off');

    set(handles.cRText,'Visible','off');
    set(handles.dRText,'Visible','off');
    set(handles.Kc0RText,'Visible','off');
    set(handles.tRText,'Visible','off');
    
    set(handles.cLowerBound,'Visible','off');
    set(handles.dLowerBound,'Visible','off');
    set(handles.Kc0LowerBound,'Visible','off');
    set(handles.tLowerBound,'Visible','off');

    set(handles.cUpperBound,'Visible','off');
    set(handles.dUpperBound,'Visible','off');
    set(handles.Kc0UpperBound,'Visible','off');
    set(handles.tUpperBound,'Visible','off');

    set(handles.clb,'Visible','off');
    set(handles.dlb,'Visible','off');
    set(handles.Kc0lb,'Visible','off');
    set(handles.tlb,'Visible','off');

    set(handles.cub,'Visible','off');
    set(handles.dub,'Visible','off');
    set(handles.Kc0ub,'Visible','off');
    set(handles.tub,'Visible','off');

    set(handles.cErrorText,'Visible','off');
    set(handles.dErrorText,'Visible','off');
    set(handles.kc0ErrorText,'Visible','off');
    set(handles.tErrorText,'Visible','off');

    set(handles.cInitValue,'Visible','off');
    set(handles.dInitValue,'Visible','off');
    set(handles.Kc0InitValue,'Visible','off');
    set(handles.tInitValue,'Visible','off');
    
    set(handles.CostantCV,'Visible','off');
    set(handles.CostantDV,'Visible','off');
    set(handles.CostantKc0V,'Visible','off');
    set(handles.CostantTV,'Visible','off');
    
    set(handles.ConstantCRB,'Visible','off');
    set(handles.ConstantDRB,'Visible','off');
    set(handles.ConstantKc0RB,'Visible','off');
    set(handles.ConstantTRB,'Visible','off');
    
    set(handles.EstimateCRB,'Visible','off');
    set(handles.EstimateDRB,'Visible','off');
    set(handles.EstimateKc0RB,'Visible','off');
    set(handles.EstimateTRB,'Visible','off');
    
    set(handles.cresulttext,'Visible','off');
    set(handles.dresulttext,'Visible','off');
    set(handles.kc0resulttext,'Visible','off');
    set(handles.tresulttext,'Visible','off');
    
    set(handles.cRText,'Visible','off');
    set(handles.dRText,'Visible','off');
    set(handles.Kc0RText,'Visible','off');
    set(handles.tRText,'Visible','off');
    
    set(handles.ctext,'Visible','off');
    set(handles.dtext,'Visible','off');
    set(handles.Kc0text,'Visible','off');
    set(handles.ttext,'Visible','off');
    

elseif indexmodel == 2
    cla(handles.axes1)
    axes(handles.axes1)
    [hAx,hLine1,hLine2] = plotyy(selectPat.tempi ,selectPat.troponina ,selectPat.tempi ,selectPat.ckmb);
    xlabel('Time [h]', 'Interpreter', 'latex', 'FontSize', 15);
    ylabel(hAx(1),' cTnT [ng/ml]', 'Interpreter', 'latex', 'FontSize', 15);
    ylabel(hAx(2),'CK-MB [ng/ml]', 'Interpreter', 'latex', 'FontSize', 15);
    title('cTnT and CK-MB', 'Interpreter', 'latex', 'FontSize', 15)
    legend({'cTnT','CK-MB'}, 'Interpreter', 'latex', 'FontSize', 15)
    set( hLine1, 'LineStyle', 'none', 'Marker','o','MarkerSize',10)
    set( hLine2, 'LineStyle', 'none','Marker','*','MarkerSize',10)
    set(hAx,'FontSize',15)
    set(hAx,'TickLabelInterpreter','latex')
    grid on
    
    set(handles.parameters_panel,'Visible','on');
    set(handles.ctext,'Visible','on');
    set(handles.dtext,'Visible','on');
    set(handles.kc0text,'Visible','on');
    set(handles.ttext,'Visible','off');

    set(handles.cresulttext,'Visible','on');
    set(handles.dresulttext,'Visible','on');
    set(handles.kc0resulttext,'Visible','on');
    set(handles.tresulttext,'Visible','off');

    set(handles.cRText,'Visible','on');
    set(handles.dRText,'Visible','on');
    set(handles.Kc0RText,'Visible','on');
    set(handles.tRText,'Visible','off');

    set(handles.cLowerBound,'Visible','on');
    set(handles.dLowerBound,'Visible','on');
    set(handles.Kc0LowerBound,'Visible','on');
    set(handles.tLowerBound,'Visible','off');

    set(handles.cUpperBound,'Visible','on');
    set(handles.dUpperBound,'Visible','on');
    set(handles.Kc0UpperBound,'Visible','on');
    set(handles.tUpperBound,'Visible','off');

    set(handles.clb,'Visible','on');
    set(handles.dlb,'Visible','on');
    set(handles.Kc0lb,'Visible','on');
    set(handles.tlb,'Visible','off');

    set(handles.cub,'Visible','on');
    set(handles.dub,'Visible','on');
    set(handles.Kc0ub,'Visible','on');
    set(handles.tub,'Visible','off');

    set(handles.cErrorText,'Visible','on');
    set(handles.dErrorText,'Visible','on');
    set(handles.kc0ErrorText,'Visible','on');
    set(handles.tErrorText,'Visible','off');

    set(handles.cInitValue,'Visible','on');
    set(handles.dInitValue,'Visible','on');
    set(handles.Kc0InitValue,'Visible','on');
    set(handles.tInitValue,'Visible','off');
    
    set(handles.CostantCV,'Visible','on');
    set(handles.CostantDV,'Visible','on');
    set(handles.CostantKc0V,'Visible','on');
    set(handles.CostantTV,'Visible','off');
    
    set(handles.ConstantCRB,'Visible','on');
    set(handles.ConstantDRB,'Visible','on');
    set(handles.ConstantKc0RB,'Visible','on');
    set(handles.ConstantTRB,'Visible','off');
    
    set(handles.EstimateCRB,'Visible','on');
    set(handles.EstimateDRB,'Visible','on');
    set(handles.EstimateKc0RB,'Visible','on');
    set(handles.EstimateTRB,'Visible','off');
    
    set(handles.cresulttext,'Visible','on');
    set(handles.dresulttext,'Visible','on');
    set(handles.kc0resulttext,'Visible','on');
    set(handles.tresulttext,'Visible','off');
    
    set(handles.cRText,'Visible','on');
    set(handles.dRText,'Visible','on');
    set(handles.Kc0RText,'Visible','on');
    set(handles.tRText,'Visible','off');
    
    set(handles.ctext,'Visible','on');
    set(handles.dtext,'Visible','on');
    set(handles.Kc0text,'Visible','on');
    set(handles.ttext,'Visible','off');
    
    
    handles.parameters = [handles.aIV handles.bIV handles.cIV handles.dIV handles.TdIV handles.Cs0IV handles.Cc0IV handles.Kc0IV 0];
    handles.LowerBound  = [handles.aLB handles.bLB handles.cLB handles.dLB handles.TdLB handles.Cs0LB handles.Cc0LB handles.Kc0LB 0];
    handles.UpperBound = [handles.aUB handles.bUB handles.cUB handles.dUB handles.TdUB handles.Cs0UB handles.Cc0UB handles.Kc0UB 0];
    
else
    cla(handles.axes1)
    axes(handles.axes1)
    plot(selectPat.tempi, selectPat.troponina, '*','MarkerSize', 10, 'MarkerEdgeColor','r')
    xlabel('Time [h]', 'Interpreter', 'latex', 'FontSize', 15)
    ylabel('cTnT [ng/ml]', 'Interpreter', 'latex', 'FontSize', 15)
    legend({'cTnT'}, 'Interpreter', 'latex', 'FontSize', 15)
    set(handles.axes1,'FontSize',15)
    set(handles.axes1,'TickLabelInterpreter','latex')
    title('cTnT', 'Interpreter', 'latex', 'FontSize', 15)
    grid on
    set(handles.parameters_panel,'Visible','on');
    
    set(handles.ctext,'Visible','off');
    set(handles.dtext,'Visible','off');
    set(handles.kc0text,'Visible','off');
    set(handles.ttext,'Visible','on');

    set(handles.cresulttext,'Visible','off');
    set(handles.dresulttext,'Visible','off');
    set(handles.kc0resulttext,'Visible','off');
    set(handles.tresulttext,'Visible','on');

    set(handles.cRText,'Visible','off');
    set(handles.dRText,'Visible','off');
    set(handles.Kc0RText,'Visible','off');
    set(handles.tRText,'Visible','on');
    
    set(handles.cLowerBound,'Visible','off');
    set(handles.dLowerBound,'Visible','off');
    set(handles.Kc0LowerBound,'Visible','off');
    set(handles.tLowerBound,'Visible','on');

    set(handles.cUpperBound,'Visible','off');
    set(handles.dUpperBound,'Visible','off');
    set(handles.Kc0UpperBound,'Visible','off');
    set(handles.tUpperBound,'Visible','on');

    set(handles.clb,'Visible','off');
    set(handles.dlb,'Visible','off');
    set(handles.Kc0lb,'Visible','off');
    set(handles.tlb,'Visible','on');

    set(handles.cub,'Visible','off');
    set(handles.dub,'Visible','off');
    set(handles.Kc0ub,'Visible','off');
    set(handles.tub,'Visible','on');

    set(handles.cErrorText,'Visible','off');
    set(handles.dErrorText,'Visible','off');
    set(handles.kc0ErrorText,'Visible','off');
    set(handles.tErrorText,'Visible','on');

    set(handles.cInitValue,'Visible','off');
    set(handles.dInitValue,'Visible','off');
    set(handles.Kc0InitValue,'Visible','off');
    set(handles.tInitValue,'Visible','on');
    
    set(handles.CostantCV,'Visible','off');
    set(handles.CostantDV,'Visible','off');
    set(handles.CostantKc0V,'Visible','off');
    set(handles.CostantTV,'Visible','on');
    
    set(handles.ConstantCRB,'Visible','off');
    set(handles.ConstantDRB,'Visible','off');
    set(handles.ConstantKc0RB,'Visible','off');
    set(handles.ConstantTRB,'Visible','on');
    
    set(handles.EstimateCRB,'Visible','off');
    set(handles.EstimateDRB,'Visible','off');
    set(handles.EstimateKc0RB,'Visible','off');
    set(handles.EstimateTRB,'Visible','on');
    
    set(handles.cresulttext,'Visible','off');
    set(handles.dresulttext,'Visible','off');
    set(handles.kc0resulttext,'Visible','off');
    set(handles.tresulttext,'Visible','on');
    
    set(handles.cRText,'Visible','off');
    set(handles.dRText,'Visible','off');
    set(handles.Kc0RText,'Visible','off');
    set(handles.tRText,'Visible','on');
    
    set(handles.ctext,'Visible','off');
    set(handles.dtext,'Visible','off');
    set(handles.Kc0text,'Visible','off');
    set(handles.ttext,'Visible','on');
    
    
    handles.parameters = [handles.aIV handles.bIV 0 0 handles.TdIV handles.Cs0IV handles.Cc0IV 0 handles.tIV];
    handles.LowerBound = [handles.aLB handles.bLB 0 0 handles.TdLB handles.Cs0LB handles.Cc0LB 0 handles.tLB];
    handles.UpperBound = [handles.aUB handles.bUB 0 0 handles.TdUB handles.Cs0UB handles.Cc0UB 0 handles.tUB];
end

handles.indexmodel = indexmodel;
    
guidata(hObject, handles);

% hObject    handle to analisi_popupmenu (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: contents = cellstr(get(hObject,'String')) returns analisi_popupmenu contents as cell array
%        contents{get(hObject,'Value')} returns selected item from analisi_popupmenu


% --- Executes during object creation, after setting all properties.
function analisi_popupmenu_CreateFcn(hObject, eventdata, handles)
% hObject    handle to analisi_popupmenu (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: popupmenu controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end


% --- Executes during object creation, after setting all properties.
function alb_CreateFcn(hObject, eventdata, handles)
% hObject    handle to alb (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called


% --- Executes on button press in home_pushbutton.
function home_pushbutton_Callback(hObject, eventdata, handles)
% hObject    handle to home_pushbutton (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
close(Analysis)
run('Home.m')




% --- Executes on slider movement.
function cLowerBound_Callback(hObject, eventdata, handles)
% hObject    handle to cLowerBound (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
%% Visualization of slider value

clb = get(handles.cLowerBound, 'Value');
set(handles.clb, 'String', num2str(clb))

%% Save current value
handles.cLB = clb;

set(handles.cUpperBound, 'Min', (handles.cLB + handles.cLB/100));
set(handles.cUpperBound, 'value', (handles.cLB + handles.cLB/100));
set(handles.cInitValue, 'String', handles.cLB);
% Hints: get(hObject,'Value') returns position of slider
%        get(hObject,'Min') and get(hObject,'Max') to determine range of slider
guidata(hObject, handles);
% Hints: get(hObject,'Value') returns position of slider
%        get(hObject,'Min') and get(hObject,'Max') to determine range of slider


% --- Executes during object creation, after setting all properties.
function cLowerBound_CreateFcn(hObject, eventdata, handles)
% hObject    handle to cLowerBound (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: slider controls usually have a light gray background.
if isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor',[.9 .9 .9]);
end


% --- Executes on slider movement.
function dLowerBound_Callback(hObject, eventdata, handles)
% hObject    handle to dLowerBound (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
%% Visualization of slider value

dlb = get(handles.dLowerBound, 'Value');
set(handles.dlb, 'String', num2str(dlb))

%% Save current value
handles.dLB = dlb;

set(handles.dUpperBound, 'Min', (handles.dLB + handles.dLB/100));
set(handles.dUpperBound, 'value', (handles.dLB + handles.dLB/100));
set(handles.dInitValue, 'String', handles.dLB);
% Hints: get(hObject,'Value') returns position of slider
%        get(hObject,'Min') and get(hObject,'Max') to determine range of slider
guidata(hObject, handles);

% Hints: get(hObject,'Value') returns position of slider
%        get(hObject,'Min') and get(hObject,'Max') to determine range of slider


% --- Executes during object creation, after setting all properties.
function dLowerBound_CreateFcn(hObject, eventdata, handles)
% hObject    handle to dLowerBound (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: slider controls usually have a light gray background.
if isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor',[.9 .9 .9]);
end


% --- Executes on slider movement.
function Kc0LowerBound_Callback(hObject, eventdata, handles)
% hObject    handle to Kc0LowerBound (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
Kc0lb = get(handles.Kc0LowerBound, 'Value');
set(handles.Kc0lb, 'String', num2str(Kc0lb))

%% Save current value
handles.Kc0LB = Kc0lb;
set(handles.Kc0UpperBound, 'Min', (handles.Kc0LB + handles.Kc0LB/100));
set(handles.Kc0UpperBound, 'value', (handles.Kc0LB + handles.Kc0LB/100));
set(handles.Kc0InitValue, 'String', handles.Kc0LB);
% Hints: get(hObject,'Value') returns position of slider
%        get(hObject,'Min') and get(hObject,'Max') to determine range of slider
guidata(hObject, handles);
% Hints: get(hObject,'Value') returns position of slider
%        get(hObject,'Min') and get(hObject,'Max') to determine range of slider


% --- Executes during object creation, after setting all properties.
function Kc0LowerBound_CreateFcn(hObject, eventdata, handles)
% hObject    handle to Kc0LowerBound (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: slider controls usually have a light gray background.
if isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor',[.9 .9 .9]);
end


% --- Executes on slider movement.
function tLowerBound_Callback(hObject, eventdata, handles)
% hObject    handle to tLowerBound (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
%% Visualization of slider value

tlb = get(handles.tLowerBound, 'Value');
set(handles.tlb, 'String', num2str(tlb))

%% Save current value
handles.tLB = tlb;
set(handles.tUpperBound, 'Min', (handles.tLB + handles.tLB/100));
set(handles.tUpperBound, 'value', (handles.tLB + handles.tLB/100));
set(handles.tInitValue, 'String', handles.tLB);
% Hints: get(hObject,'Value') returns position of slider
%        get(hObject,'Min') and get(hObject,'Max') to determine range of slider
guidata(hObject, handles);
% Hints: get(hObject,'Value') returns position of slider
%        get(hObject,'Min') and get(hObject,'Max') to determine range of slider


% --- Executes during object creation, after setting all properties.
function tLowerBound_CreateFcn(hObject, eventdata, handles)
% hObject    handle to tLowerBound (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: slider controls usually have a light gray background.
if isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor',[.9 .9 .9]);
end


% --- Executes on slider movement.
function cUpperBound_Callback(hObject, eventdata, handles)
% hObject    handle to cUpperBound (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
%% Visualization of slider value

cub = get(handles.cUpperBound, 'Value');
set(handles.cub, 'String', num2str(cub))

%% Save current value
handles.cUB = cub;

% Hints: get(hObject,'Value') returns position of slider
%        get(hObject,'Min') and get(hObject,'Max') to determine range of slider
guidata(hObject, handles);
% Hints: get(hObject,'Value') returns position of slider
%        get(hObject,'Min') and get(hObject,'Max') to determine range of slider


% --- Executes during object creation, after setting all properties.
function cUpperBound_CreateFcn(hObject, eventdata, handles)
% hObject    handle to cUpperBound (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: slider controls usually have a light gray background.
if isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor',[.9 .9 .9]);
end


% --- Executes on slider movement.
function dUpperBound_Callback(hObject, eventdata, handles)
% hObject    handle to dUpperBound (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
%% Visualization of slider value

dub = get(handles.dUpperBound, 'value');
set(handles.dub, 'String', num2str(dub))

%% Save current value
handles.dUB = dub;

% Hints: get(hObject,'Value') returns position of slider
%        get(hObject,'Min') and get(hObject,'Max') to determine range of slider
guidata(hObject, handles);
% Hints: get(hObject,'Value') returns position of slider
%        get(hObject,'Min') and get(hObject,'Max') to determine range of slider


% --- Executes during object creation, after setting all properties.
function dUpperBound_CreateFcn(hObject, eventdata, handles)
% hObject    handle to dUpperBound (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: slider controls usually have a light gray background.
if isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor',[.9 .9 .9]);
end


% --- Executes on slider movement.
function Kc0UpperBound_Callback(hObject, eventdata, handles)
% hObject    handle to Kc0UpperBound (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
%% Visualization of slider value

Kc0ub = get(handles.Kc0UpperBound, 'Value');
set(handles.Kc0ub, 'String', num2str(Kc0ub))

%% Save current value
handles.Kc0UB = Kc0ub;



% Hints: get(hObject,'Value') returns position of slider
%        get(hObject,'Min') and get(hObject,'Max') to determine range of slider
guidata(hObject, handles);
% Hints: get(hObject,'Value') returns position of slider
%        get(hObject,'Min') and get(hObject,'Max') to determine range of slider


% --- Executes during object creation, after setting all properties.
function Kc0UpperBound_CreateFcn(hObject, eventdata, handles)
% hObject    handle to Kc0UpperBound (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: slider controls usually have a light gray background.
if isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor',[.9 .9 .9]);
end


% --- Executes on slider movement.
function tUpperBound_Callback(hObject, eventdata, handles)
% hObject    handle to tUpperBound (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
tub = get(handles.tUpperBound, 'Value');
set(handles.tub, 'String', num2str(tub))

%% Save current value
handles.tUB = tub;


% Hints: get(hObject,'Value') returns position of slider
%        get(hObject,'Min') and get(hObject,'Max') to determine range of slider
guidata(hObject, handles);
% Hints: get(hObject,'Value') returns position of slider
%        get(hObject,'Min') and get(hObject,'Max') to determine range of slider


% --- Executes during object creation, after setting all properties.
function tUpperBound_CreateFcn(hObject, eventdata, handles)
% hObject    handle to tUpperBound (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: slider controls usually have a light gray background.
if isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor',[.9 .9 .9]);
end



function cInitValue_Callback(hObject, eventdata, handles)
% hObject    handle to cInitValue (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
cIV = str2num(get(handles.cInitValue, 'String'));
errorV = 0;
%% Check on value
if ((cIV < handles.cLB))
    set(handles.cErrorText, 'String', ' value < lb', 'ForegroundColor', 'red')
    errorV = 1;
elseif ((cIV > handles.cUB))
    set(handles.cErrorText, 'String', ' value > ub', 'ForegroundColor', 'red')
    errorV = 1;
    
else
    set(handles.cErrorText, 'String', '')
    errorV = 0;
    handles.cIV = cIV;
end
handles.ErrorV(6) = errorV;
guidata(hObject, handles)
% Hints: get(hObject,'String') returns contents of cInitValue as text
%        str2double(get(hObject,'String')) returns contents of cInitValue as a double


% --- Executes during object creation, after setting all properties.
function cInitValue_CreateFcn(hObject, eventdata, handles)
% hObject    handle to cInitValue (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end



function dInitValue_Callback(hObject, eventdata, handles)
% hObject    handle to dInitValue (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
dIV = str2num(get(handles.dInitValue, 'String'));
errorV = 0;
%% Check on value
if ((dIV < handles.dLB))
    set(handles.dErrorText, 'String', ' value < lb', 'ForegroundColor', 'red')
    errorV = 1;
elseif ((dIV > handles.dUB))
    set(handles.dErrorText, 'String', ' value > ub', 'ForegroundColor', 'red')
    errorV = 1;
    
else
    set(handles.dErrorText, 'String', '')
    errorV = 0;
    handles.dIV = dIV;
end
handles.ErrorV(7) = errorV;
guidata(hObject, handles)
% Hints: get(hObject,'String') returns contents of dInitValue as text
%        str2double(get(hObject,'String')) returns contents of dInitValue as a double


% --- Executes during object creation, after setting all properties.
function dInitValue_CreateFcn(hObject, eventdata, handles)
% hObject    handle to dInitValue (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end



function Kc0InitValue_Callback(hObject, eventdata, handles)
% hObject    handle to Kc0InitValue (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
Kc0IV = str2num(get(handles.Kc0InitValue, 'String'));
errorV = 0;
%% Check on value
if ((Kc0IV < handles.Kc0LB))
    set(handles.Kc0ErrorText, 'String', ' value < lb', 'ForegroundColor', 'red')
    errorV = 1;
elseif ((Kc0IV > handles.Kc0UB))
    set(handles.Kc0ErrorText, 'String', ' value > ub', 'ForegroundColor', 'red')
    errorV = 1;
    
else
    set(handles.cErrorText, 'String', '')
    errorV = 0;
    handles.Kc0IV = Kc0IV;
end
handles.ErrorV(8) = errorV;
guidata(hObject, handles)
% Hints: get(hObject,'String') returns contents of Kc0InitValue as text
%        str2double(get(hObject,'String')) returns contents of Kc0InitValue as a double


% --- Executes during object creation, after setting all properties.
function Kc0InitValue_CreateFcn(hObject, eventdata, handles)
% hObject    handle to Kc0InitValue (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end



function tInitValue_Callback(hObject, eventdata, handles)
% hObject    handle to tInitValue (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
tIV = str2num(get(handles.tInitValue, 'String'));
errorV = 0;
%% Check on value
if ((tIV < handles.tLB))
    set(handles.tErrorText, 'String', ' value < lb', 'ForegroundColor', 'red')
    errorV = 1;
elseif ((tIV > handles.tUB))
    set(handles.tErrorText, 'String', ' value > ub', 'ForegroundColor', 'red')
    errorV = 1;
    
else
    set(handles.tErrorText, 'String', '')
    errorV = 0;
    handles.tIV = tIV;
end
handles.ErrorV(9) = errorV;
guidata(hObject, handles)
% Hints: get(hObject,'String') returns contents of tInitValue as text
%        str2double(get(hObject,'String')) returns contents of tInitValue as a double


% --- Executes during object creation, after setting all properties.
function tInitValue_CreateFcn(hObject, eventdata, handles)
% hObject    handle to tInitValue (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end



function NumberLocalPoint_Callback(hObject, eventdata, handles)
% hObject    handle to NumberLocalPoint (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

value = str2num(get(handles.NumberLocalPoint, 'String'));

%% Check on number
errorV2 = 0;
if(value <= 0)
    
    set(handles.NumberLocalPoint, 'String', '')
    set(handles.MessageText, 'String', 'Please insert a positive value > 1', 'ForegroundColor', [1 0 0.4])
    set(handles.MessageText, 'Visible', 'on');

    errorV2 = 1;
    
elseif (value == 1)
    
    set(handles.NumberLocalPoint, 'String', '')
    set(handles.MessageText, 'String', 'Please insert a positive value > 1', 'ForegroundColor', [1 0 0.4])
    set(handles.MessageText, 'Visible', 'on');

    errorV2 = 1;
else
    handles.NLP = value;
    set(handles.MessageText, 'String', '')
    set(handles.MessageText, 'Visible', 'on');
    errorV2 = 0;
end

handles.ErrorV2 = errorV2;
handles.NLP = value;



% Hints: get(hObject,'String') returns contents of NumberLocalPoint as text
%        str2double(get(hObject,'String')) returns contents of NumberLocalPoint as a double
guidata(hObject, handles);

% Hints: get(hObject,'String') returns contents of NumberLocalPoint as text
%        str2double(get(hObject,'String')) returns contents of NumberLocalPoint as a double


% --- Executes on button press in EstimateARB.
function EstimateARB_Callback(hObject, eventdata, handles)
% hObject    handle to EstimateARB (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
value = get(handles.EstimateARB, 'Value');

if value == 1
    handles.constant_vector(1) = 0;
    set(handles.CostantAV, 'Visible', 'off');
    set(handles.ConstantARB, 'Value', 0);
end

guidata(hObject, handles);  
% Hint: get(hObject,'Value') returns toggle state of EstimateARB


% --- Executes on button press in EstimateBRB.
function EstimateBRB_Callback(hObject, eventdata, handles)
% hObject    handle to EstimateBRB (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
value = get(handles.EstimateBRB, 'Value');

if value == 1
    handles.constant_vector(2) = 0;
    set(handles.CostantBV, 'Visible', 'off');
    set(handles.ConstantBRB, 'Value', 0);
end

guidata(hObject, handles);  
% Hint: get(hObject,'Value') returns toggle state of EstimateBRB


% --- Executes on button press in EstimateCs0RB.
function EstimateCs0RB_Callback(hObject, eventdata, handles)
% hObject    handle to EstimateCs0RB (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
value = get(handles.EstimateCs0RB, 'Value');

if value == 1
    handles.constant_vector(6) = 0;
    set(handles.CostantCs0V, 'Visible', 'off');
    set(handles.ConstantCs0RB, 'Value', 0);
end

guidata(hObject, handles);
% Hint: get(hObject,'Value') returns toggle state of EstimateCs0RB


% --- Executes on button press in EstimateCc0RB.
function EstimateCc0RB_Callback(hObject, eventdata, handles)
% hObject    handle to EstimateCc0RB (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
value = get(handles.EstimateCc0RB, 'Value');
%costant_vector = handles.costant_vector;

if value == 1
    handles.constant_vector(7) = 0;
    set(handles.CostantCc0V, 'Visible', 'off');
    set(handles.ConstantCc0RB, 'Value', 0);
end

guidata(hObject, handles);  
% Hint: get(hObject,'Value') returns toggle state of EstimateCc0RB


% --- Executes on button press in EstimateTdRB.
function EstimateTdRB_Callback(hObject, eventdata, handles)
% hObject    handle to EstimateTdRB (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
value = get(handles.EstimateTdRB, 'Value');


if value == 1
    handles.constant_vector(5) = 0;
    set(handles.CostantTdV, 'Visible', 'off');
    set(handles.ConstantTdRB, 'Value', 0);
end

guidata(hObject, handles);  
% Hint: get(hObject,'Value') returns toggle state of EstimateTdRB


% --- Executes on button press in ConstantARB.
function ConstantARB_Callback(hObject, eventdata, handles)
% hObject    handle to ConstantARB (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
value = get(handles.ConstantARB, 'Value');

if value == 1
    set(handles.CostantAV, 'Visible', 'on');
    set(handles.EstimateARB, 'Value', 0);
    set(handles.CostantAV, 'String', 0.05);
    handles.constant_vector(1) = str2num(get(handles.CostantAV, 'String'));
end

guidata(hObject, handles);
% Hint: get(hObject,'Value') returns toggle state of ConstantARB


% --- Executes on button press in ConstantBRB.
function ConstantBRB_Callback(hObject, eventdata, handles)
% hObject    handle to ConstantBRB (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
value = get(handles.ConstantBRB, 'Value');

if value == 1
    set(handles.CostantBV, 'Visible', 'on');
    set(handles.EstimateBRB, 'Value', 0);
    set(handles.CostantBV, 'String', 0.05);
    handles.constant_vector(2) = str2num(get(handles.CostantBV, 'String'));
end

guidata(hObject, handles);
% Hint: get(hObject,'Value') returns toggle state of ConstantBRB


% --- Executes on button press in ConstantCs0RB.
function ConstantCs0RB_Callback(hObject, eventdata, handles)
% hObject    handle to ConstantCs0RB (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
value = get(handles.ConstantCs0RB, 'Value');

if value == 1
    set(handles.CostantCs0V, 'Visible', 'on');
    set(handles.EstimateCs0RB, 'Value', 0);
    set(handles.CostantCs0V, 'String', 14);
    handles.constant_vector(6) = str2num(get(handles.CostantCs0V, 'String'));
end

guidata(hObject, handles);
% Hint: get(hObject,'Value') returns toggle state of ConstantCs0RB


% --- Executes on button press in ConstantCc0RB.
function ConstantCc0RB_Callback(hObject, eventdata, handles)
% hObject    handle to ConstantCc0RB (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
value = get(handles.ConstantCc0RB, 'Value');

if value == 1
    set(handles.CostantCc0V, 'Visible', 'on');
    set(handles.EstimateCc0RB, 'Value', 0);
    set(handles.CostantCc0V, 'String', 26);
    handles.constant_vector(7) = str2num(get(handles.CostantCc0V, 'String'));
end

guidata(hObject, handles);
% Hint: get(hObject,'Value') returns toggle state of ConstantCc0RB


% --- Executes on button press in ConstantTdRB.
function ConstantTdRB_Callback(hObject, eventdata, handles)
% hObject    handle to ConstantTdRB (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
value = get(handles.ConstantTdRB, 'Value');

if value == 1
    set(handles.CostantTdV, 'Visible', 'on');
    set(handles.EstimateTdRB, 'Value', 0); 
    set(handles.CostantTdV, 'String', 187);
    handles.constant_vector(5) = str2num(get(handles.CostantTdV, 'String'));
    %% 
end

guidata(hObject, handles);
% Hint: get(hObject,'Value') returns toggle state of ConstantTdRB


% --- Executes on button press in AdvancedButton.
function AdvancedButton_Callback(hObject, eventdata, handles)
set(handles.advanced_panel,'Visible','on');

set(handles.CostantAV, 'Visible', 'off');
set(handles.CostantBV, 'Visible', 'off');
set(handles.CostantTdV, 'Visible', 'off');
set(handles.CostantCs0V, 'Visible', 'off');
set(handles.CostantCc0V, 'Visible', 'off');

set(handles.CostantCV,'Visible','off');
set(handles.CostantDV,'Visible','off');
set(handles.CostantKc0V,'Visible','off');
set(handles.CostantTV,'Visible','off');

guidata(hObject, handles);
% hObject    handle to AdvancedButton (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)



%% Function to identify the two peak on release curve

function [v_max, t_max] = min_max(Cp_ctnt, t)

diffCp_ctnt = diff(Cp_ctnt);
idx_mins = [];

for idx_min = 1:length(diffCp_ctnt)-1
    if diffCp_ctnt(idx_min)*diffCp_ctnt(idx_min+1)<0
        idx_mins = [idx_mins, idx_min+1];
    end
end

t_max = [];
v_max = [];

[v_max(1), id] = max(Cp_ctnt);
t_max(1) = t(id);


t_max(2) = t(idx_mins(end));
v_max(2) = Cp_ctnt(idx_mins(end));



function CostantCV_Callback(hObject, eventdata, handles)
% hObject    handle to CostantCV (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
value = str2num(get(handles.CostantCV, 'String'));
handles.constant_vector(3) = value;

% Hints: get(hObject,'String') returns contents of CostantAV as text
%        str2double(get(hObject,'String')) returns contents of CostantAV as a double

guidata(hObject, handles);
% Hints: get(hObject,'String') returns contents of CostantCV as text
%        str2double(get(hObject,'String')) returns contents of CostantCV as a double


% --- Executes during object creation, after setting all properties.
function CostantCV_CreateFcn(hObject, eventdata, handles)
% hObject    handle to CostantCV (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end



function CostantDV_Callback(hObject, eventdata, handles)
% hObject    handle to CostantDV (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
value = str2num(get(handles.CostantDV, 'String'));
handles.constant_vector(4) = value;

% Hints: get(hObject,'String') returns contents of CostantAV as text
%        str2double(get(hObject,'String')) returns contents of CostantAV as a double

guidata(hObject, handles);
% Hints: get(hObject,'String') returns contents of CostantDV as text
%        str2double(get(hObject,'String')) returns contents of CostantDV as a double


% --- Executes during object creation, after setting all properties.
function CostantDV_CreateFcn(hObject, eventdata, handles)
% hObject    handle to CostantDV (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end



function CostantKc0V_Callback(hObject, eventdata, handles)
% hObject    handle to CostantKc0V (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
value = str2num(get(handles.CostantKc0V, 'String'));
handles.constant_vector(8) = value;

% Hints: get(hObject,'String') returns contents of CostantAV as text
%        str2double(get(hObject,'String')) returns contents of CostantAV as a double

guidata(hObject, handles);
% Hints: get(hObject,'String') returns contents of CostantKc0V as text
%        str2double(get(hObject,'String')) returns contents of CostantKc0V as a double


% --- Executes during object creation, after setting all properties.
function CostantKc0V_CreateFcn(hObject, eventdata, handles)
% hObject    handle to CostantKc0V (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end



function CostantTV_Callback(hObject, eventdata, handles)
% hObject    handle to CostantTV (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
value = str2num(get(handles.CostantTV, 'String'));
handles.constant_vector(9) = value;

% Hints: get(hObject,'String') returns contents of CostantAV as text
%        str2double(get(hObject,'String')) returns contents of CostantAV as a double

guidata(hObject, handles);
% Hints: get(hObject,'String') returns contents of CostantTV as text
%        str2double(get(hObject,'String')) returns contents of CostantTV as a double


% --- Executes during object creation, after setting all properties.
function CostantTV_CreateFcn(hObject, eventdata, handles)
% hObject    handle to CostantTV (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end


% --- Executes on button press in EstimateCRB.
function EstimateCRB_Callback(hObject, eventdata, handles)
% hObject    handle to EstimateCRB (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
value = get(handles.EstimateCRB, 'Value');
%costant_vector = handles.costant_vector;

if value == 1
    handles.constant_vector(3) = 0;
    set(handles.CostantCV, 'Visible', 'off');
    set(handles.ConstantCRB, 'Value', 0);
    set(handles.CostantCV, 'String', 0.05);

end

guidata(hObject, handles); 
% Hint: get(hObject,'Value') returns toggle state of EstimateCRB


% --- Executes on button press in EstimateDRB.
function EstimateDRB_Callback(hObject, eventdata, handles)
% hObject    handle to EstimateDRB (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
value = get(handles.EstimateDRB, 'Value');
%costant_vector = handles.costant_vector;

if value == 1
    handles.constant_vector(4) = 0;
    set(handles.CostantDV, 'Visible', 'off');
    set(handles.ConstantDRB, 'Value', 0.05);
end

guidata(hObject, handles); 
% Hint: get(hObject,'Value') returns toggle state of EstimateDRB


% --- Executes on button press in EstimateTRB.
function EstimateTRB_Callback(hObject, eventdata, handles)
% hObject    handle to EstimateTRB (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
value = get(handles.EstimateTRB, 'Value');
%costant_vector = handles.costant_vector;

if value == 1
    handles.constant_vector(9) = 0;
    set(handles.CostantTV, 'Visible', 'off');
    set(handles.ConstantTRB, 'Value', 0.05);
end

guidata(hObject, handles); 
% Hint: get(hObject,'Value') returns toggle state of EstimateTRB


% --- Executes on button press in EstimateKc0RB.
function EstimateKc0RB_Callback(hObject, eventdata, handles)
% hObject    handle to EstimateKc0RB (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
value = get(handles.EstimateKc0RB, 'Value');
%costant_vector = handles.costant_vector;

if value == 1
    handles.constant_vector(8) = 0;
    set(handles.CostantKc0V, 'Visible', 'off');
    set(handles.ConstantKc0RB, 'Value', 0);
end

guidata(hObject, handles); 
% Hint: get(hObject,'Value') returns toggle state of EstimateKc0RB


% --- Executes on button press in ConstantCRB.
function ConstantCRB_Callback(hObject, eventdata, handles)
% hObject    handle to ConstantCRB (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
value = get(handles.ConstantCRB, 'Value');

if value == 1
    set(handles.CostantCV, 'Visible', 'on');
    set(handles.EstimateCRB, 'Value', 0);
    set(handles.CostantCV, 'String', num2str(0.05));
    handles.constant_vector(3) = 0.05;
end

guidata(hObject, handles);
% Hint: get(hObject,'Value') returns toggle state of ConstantCRB


% --- Executes on button press in ConstantDRB.
function ConstantDRB_Callback(hObject, eventdata, handles)
% hObject    handle to ConstantDRB (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
value = get(handles.ConstantDRB, 'Value');

if value == 1
    set(handles.CostantDV, 'Visible', 'on');
    set(handles.EstimateDRB, 'Value', 0);
    set(handles.CostantDV, 'String', num2str(0.05));
    handles.constant_vector(4) = 0.05;
end

guidata(hObject, handles);


% --- Executes on button press in ConstantTRB.
function ConstantTRB_Callback(hObject, eventdata, handles)
% hObject    handle to ConstantTRB (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
value = get(handles.ConstantTRB, 'Value');

if value == 1
    set(handles.CostanTV, 'Visible', 'on');
    set(handles.EstimateTRB, 'Value', 0);
    set(handles.CostantTV, 'String', num2str(0));
    handles.constant_vector(9) = 0;
end

guidata(hObject, handles);



% --- Executes on button press in ConstantKc0RB.
function ConstantKc0RB_Callback(hObject, eventdata, handles)
% hObject    handle to ConstantKc0RB (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
value = get(handles.ConstantKc0RB, 'Value');

if value == 1
    set(handles.CostantKc0V, 'Visible', 'on');
    set(handles.EstimateKc0RB, 'Value', 0);
    set(handles.CostantKc0V, 'String', num2str(200));
    handles.constant_vector(8) = 200;
end

guidata(hObject, handles);


% --- Executes on button press in Stop.
% function Stop_Callback(hObject, eventdata, handles)
% % hObject    handle to Stop (see GCBO)
% % eventdata  reserved - to be defined in a future version of MATLAB
% % handles    structure with handles and user data (see GUIDATA)
% %     while true
% %       drawnow()
% %       stop_state = get(handles.Stop, 'Value');
% %       if stop_state
% %         break;
% %       end
% %       ...
% %     end
%     set(handles.MessageText, 'String', 'Current Simulation Stopped','ForegroundColor', 'red');
%     set(handles.MessageText,'Visible','on');
