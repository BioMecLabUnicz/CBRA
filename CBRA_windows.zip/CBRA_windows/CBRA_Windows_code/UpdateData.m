function varargout = UpdateData(varargin)
% UPDATEDATA MATLAB code for UpdateData.fig
%      UPDATEDATA, by itself, creates a new UPDATEDATA or raises the existing
%      singleton*.
%
%      H = UPDATEDATA returns the handle to a new UPDATEDATA or the handle to
%      the existing singleton*.
%
%      UPDATEDATA('CALLBACK',hObject,eventData,handles,...) calls the local
%      function named CALLBACK in UPDATEDATA.M with the given input arguments.
%
%      UPDATEDATA('Property','Value',...) creates a new UPDATEDATA or raises the
%      existing singleton*.  Starting from the left, property value pairs are
%      applied to the GUI before UpdateData_OpeningFcn gets called.  An
%      unrecognized property name or invalid value makes property application
%      stop.  All inputs are passed to UpdateData_OpeningFcn via varargin.
%
%      *See GUI Options on GUIDE's Tools menu.  Choose "GUI allows only one
%      instance to run (singleton)".
%
% See also: GUIDE, GUIDATA, GUIHANDLES

% Edit the above text to modify the response to help UpdateData

% Last Modified by GUIDE v2.5 28-Sep-2020 18:00:32

% Begin initialization code - DO NOT EDIT
gui_Singleton = 1;
gui_State = struct('gui_Name',       mfilename, ...
                   'gui_Singleton',  gui_Singleton, ...
                   'gui_OpeningFcn', @UpdateData_OpeningFcn, ...
                   'gui_OutputFcn',  @UpdateData_OutputFcn, ...
                   'gui_LayoutFcn',  [] , ...
                   'gui_Callback',   []);
if nargin && ischar(varargin{1})
    gui_State.gui_Callback = str2func(varargin{1});
end

if nargout
    [varargout{1:nargout}] = gui_mainfcn(gui_State, varargin{:});
else
    gui_mainfcn(gui_State, varargin{:});
end
% End initialization code - DO NOT EDIT


% --- Executes just before UpdateData is made visible.
function UpdateData_OpeningFcn(hObject, eventdata, handles, varargin)
% This function has no output args, see OutputFcn.
% hObject    handle to figure
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
% varargin   command line arguments to UpdateData (see VARARGIN)

% Choose default command line output for UpdateData
handles.output = hObject;
set(handles.output, 'WindowStyle', 'docked')

% Update handles structure
guidata(hObject, handles);
set(handles.acquisizioni,'Visible','off');
set(handles.intervento,'Visible','off');
set(handles.ricovero_popupmenu,'Visible','off');
set(handles.timibutton, 'visible', 'off');

% Nome DataBase
dbname = 'Biomarcatore';

% Username and Password per accedere al DB
username = 'root';
password = 'root';

% Specifichiamo la tipologia di driver utilizzato
driver = 'com.mysql.jdbc.Driver';

% Specifichiamo l'inidrizzo
dburl = 'jdbc:mysql://localhost:3306/Biomarcatore'; %/useSSL=false&? 
% useSSL=true and verifyServerCertificate=false Perch? su php ssl variables
% risultano DISABLED


% Modifichiamo il classpath 
%currentFolder = pwd;
%path_driver = strcat(currentFolder, '/mysql-connector-java-5.0.8/mysql-connector-java-5.0.8-bin.jar');
%javaclasspath(path_driver);

% Effettuiamo la connessione
handles.conn = database(dbname, username, password, driver, dburl);

sqlqery = 'SELECT CF FROM CartellaClinica';

% Eseguiamo la query con il comando exec
curs = exec(handles.conn, sqlqery);

% Importiamo i dati in matlab attraverso il comando fetch e visualizziamo i
% dati selezionati
curs = fetch(curs);

set(handles.paziente_popupmenu,'String', curs.Data);
set(handles.azioni,'Visible','off');
set(handles.warning,'Visible','off');
set(handles.warn,'Visible','off');
set(handles.ricovero_panel,'Visible','off');
set(handles.modifpanel, 'Visible', 'off');
%set(handles.azioni,'Visibile','off');

set(handles.dataacquisizione_pushbutton,'String','SELECT DATE');
set(handles.dataricovero_pushbutton,'String','SELECT DATE');
set(handles.oraacquisizione_edit,'String','');
set(handles.troponina_edit,'String','');
set(handles.na_edit,'String','');
set(handles.potassio_edit,'String','');
set(handles.ckmb_edit,'String','');

set(handles.dataintervento_pushbutton,'String','SELECT DATE');
set(handles.oraintervento_edit,'String','');
set(handles.tipointervento_edit,'String','');
set(handles.farmaco_edit,'String','');
set(handles.vasoculprit_edit,'String','');

handles.dataacquisizione = '';
handles.oraacquisizione = '';
handles.troponina = '';
handles.na = '';
handles.potassio = '';
handles.ckmb = '';


handles.dataricovero='';
handles.oraricovero='';
handles.oraevento='';
handles.dataevento='';
handles.primocontattomedico='';

handles.dataintervento = '';
handles.oraintervento = '';
handles.tipointervento = '';
handles.farmaco = '';
handles.vasoculprit = '';


guidata(hObject, handles);
% UIWAIT makes UpdateData wait for user response (see UIRESUME)
% uiwait(handles.figure1);


% --- Outputs from this function are returned to the command line.
function varargout = UpdateData_OutputFcn(hObject, eventdata, handles) 
% varargout  cell array for returning output args (see VARARGOUT);
% hObject    handle to figure
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Get default command line output from handles structure
varargout{1} = handles.output;



function dataacquisizione_pushbutton_Callback(hObject, eventdata, handles)
% hObject    handle to dataacquisizione_pushbutton (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of dataacquisizione_pushbutton as text
%        str2double(get(hObject,'String')) returns contents of dataacquisizione_pushbutton as a double
uicalendar('DestinationUI', handles.dataacquisizione_pushbutton);
waitfor(handles.dataacquisizione_pushbutton,'String'); 
handles.dataacquisizione = get(handles.dataacquisizione_pushbutton,'String');
data = datetime(handles.dataacquisizione);
if isempty(data) == 1
    set(handles.dataacquisizione_pushbutton, 'String', 'Wrn: please select Year - Month -- Day')
else
    handles.dataacquisizione  = get(handles.dataacquisizione_pushbutton,'String');
end

guidata(hObject, handles);

% --- Executes during object creation, after setting all properties.
function dataacquisizione_pushbutton_CreateFcn(hObject, eventdata, handles)
% hObject    handle to dataacquisizione_pushbutton (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end



function oraacquisizione_edit_Callback(hObject, eventdata, handles)
% hObject    handle to oraacquisizione_edit (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of oraacquisizione_edit as text
%        str2double(get(hObject,'String')) returns contents of oraacquisizione_edit as a double
handles.oraacquisizione = get(handles.oraacquisizione_edit, 'String');
guidata(hObject, handles);

% --- Executes during object creation, after setting all properties.
function oraacquisizione_edit_CreateFcn(hObject, eventdata, handles)
% hObject    handle to oraacquisizione_edit (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end



function troponina_edit_Callback(hObject, eventdata, handles)
% hObject    handle to troponina_edit (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of troponina_edit as text
%        str2double(get(hObject,'String')) returns contents of troponina_edit as a double
handles.troponina = get(handles.troponina_edit, 'String');
guidata(hObject, handles);

% --- Executes during object creation, after setting all properties.
function troponina_edit_CreateFcn(hObject, eventdata, handles)
% hObject    handle to troponina_edit (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end



function potassio_edit_Callback(hObject, eventdata, handles)
% hObject    handle to potassio_edit (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of potassio_edit as text
%        str2double(get(hObject,'String')) returns contents of potassio_edit as a double
handles.potassio = get(handles.potassio_edit, 'String');
guidata(hObject, handles);

% --- Executes during object creation, after setting all properties.
function potassio_edit_CreateFcn(hObject, eventdata, handles)
% hObject    handle to potassio_edit (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end



function na_edit_Callback(hObject, eventdata, handles)
% hObject    handle to na_edit (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of na_edit as text
%        str2double(get(hObject,'String')) returns contents of na_edit as a double
handles.na = get(handles.na_edit, 'String');
guidata(hObject, handles);

% --- Executes during object creation, after setting all properties.
function na_edit_CreateFcn(hObject, eventdata, handles)
% hObject    handle to na_edit (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end



function ckmb_edit_Callback(hObject, eventdata, handles)
% hObject    handle to ckmb_edit (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of ckmb_edit as text
%        str2double(get(hObject,'String')) returns contents of ckmb_edit as a double
handles.ckmb = get(handles.ckmb_edit, 'String');
guidata(hObject, handles);

% --- Executes during object creation, after setting all properties.
function ckmb_edit_CreateFcn(hObject, eventdata, handles)
% hObject    handle to ckmb_edit (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end



function edit13_Callback(hObject, eventdata, handles)
% hObject    handle to edit13 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of edit13 as text
%        str2double(get(hObject,'String')) returns contents of edit13 as a double


% --- Executes during object creation, after setting all properties.
function edit13_CreateFcn(hObject, eventdata, handles)
% hObject    handle to edit13 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end



function edit14_Callback(hObject, eventdata, handles)
% hObject    handle to edit14 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of edit14 as text
%        str2double(get(hObject,'String')) returns contents of edit14 as a double


% --- Executes during object creation, after setting all properties.
function edit14_CreateFcn(hObject, eventdata, handles)
% hObject    handle to edit14 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end



function edit15_Callback(hObject, eventdata, handles)
% hObject    handle to edit15 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of edit15 as text
%        str2double(get(hObject,'String')) returns contents of edit15 as a double


% --- Executes during object creation, after setting all properties.
function edit15_CreateFcn(hObject, eventdata, handles)
% hObject    handle to edit15 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end



function edit16_Callback(hObject, eventdata, handles)
% hObject    handle to edit16 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of edit16 as text
%        str2double(get(hObject,'String')) returns contents of edit16 as a double


% --- Executes during object creation, after setting all properties.
function edit16_CreateFcn(hObject, eventdata, handles)
% hObject    handle to edit16 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end



function edit17_Callback(hObject, eventdata, handles)
% hObject    handle to edit17 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of edit17 as text
%        str2double(get(hObject,'String')) returns contents of edit17 as a double


% --- Executes during object creation, after setting all properties.
function edit17_CreateFcn(hObject, eventdata, handles)
% hObject    handle to edit17 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end


% --- Executes on button press in home_pushbutton.
function home_pushbutton_Callback(hObject, eventdata, handles)
% hObject    handle to home_pushbutton (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

run('Home.m');


% --- Executes on selection change in paziente_popupmenu.
function paziente_popupmenu_Callback(hObject, eventdata, handles)
% hObject    handle to paziente_popupmenu (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: contents = cellstr(get(hObject,'String')) returns paziente_popupmenu contents as cell array
%        contents{get(hObject,'Value')} returns selected item from paziente_popupmenu
set(handles.ricovero_popupmenu,'Visible','on');

indexpat = get(handles.paziente_popupmenu,'Value');
pat = get(handles.paziente_popupmenu, 'String'); %in pat metto tutti i pz
global sel_pat;
sel_pat = pat{indexpat}; %paz selezionato in sel
handles.pat = sel_pat;

% verifica timi
sqlquery = strcat('SELECT timiscore, message FROM Timi WHERE CF = "', pat{indexpat}, '"');
curs = exec(handles.conn, sqlquery);
curs = fetch(curs);

if strcmp(char(string(curs.Data(:,1))), 'No Data')
    set(handles.timibutton, 'visible', 'on');
    set(handles.messimi, 'visible', 'off');
else
    set(handles.messimi, 'String', char(string(curs.Data(2))));
    set(handles.messimi, 'visible', 'on');
    set(handles.timibutton, 'visible', 'off');
end

sqlqery= strcat('SELECT DataRicovero, OraRicovero, DataEvento, OraEvento FROM Ricovero WHERE CF  = "', handles.pat, '"');
curs = exec(handles.conn, sqlqery);
curs = fetch(curs);
handles.patData = curs.Data;


if strcmp(char(string(curs.Data(:,1))), 'No Data')
    set(handles.ricovero_popupmenu, 'String', 'No hospitalization');
    set(handles.ricovero_popupmenu,'Visible','on');
    handles.ricoveroS = {};
else
    set(handles.ricovero_popupmenu,'String', curs.Data(:,1));
    set(handles.ricovero_popupmenu,'Visible','on');
    handles.ricoveroS = curs.Data(:,1);
end   


set(handles.azioni, 'Visible', 'on');

guidata(hObject, handles);

% --- Executes during object creation, after setting all properties.
function paziente_popupmenu_CreateFcn(hObject, eventdata, handles)
% hObject    handle to paziente_popupmenu (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: popupmenu controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end


% --- Executes on selection change in ricovero_popupmenu.
function ricovero_popupmenu_Callback(hObject, eventdata, handles)
% hObject    handle to ricovero_popupmenu (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: contents = cellstr(get(hObject,'String')) returns ricovero_popupmenu contents as cell array
%        contents{get(hObject,'Value')} returns selected item from ricovero_popupmenu

if isempty(handles.ricoveroS)
        handles.dataricovero = {};
        set(handles.warning,'Visible','on');
        set(handles.warn,'Visible','on');
        set(handles.warn,'String','No hospitalization for this patient - Please insert a new hospitalization');
else
    
    indexdata = get(handles.ricovero_popupmenu,'Value');
    data = get(handles.ricovero_popupmenu, 'String'); %in pat metto tutti i pz
    sel_data = data{indexdata}; %paz selezionato in sel
    handles.data = sel_data;
    index_sel =  find(strcmp(handles.patData(:,1), sel_data) == 1);

    handles.dataricovero = handles.patData(index_sel, 1);
    handles.oraricovero = handles.patData(index_sel, 2);
    handles.dataevento = handles.patData(index_sel, 3);
    handles.oraevento = handles.patData(index_sel, 4);

end
guidata(hObject, handles);
% 

% --- Executes during object creation, after setting all properties.
function ricovero_popupmenu_CreateFcn(hObject, eventdata, handles)
% hObject    handle to ricovero_popupmenu (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: popupmenu controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end



% --- Executes on button press in surgery_pushbutton.
function surgery_pushbutton_Callback(hObject, eventdata, handles)
% hObject    handle to surgery_pushbutton (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
set(handles.intervento,'Visible','on');
set(handles.acquisizioni,'Visible','off');
set(handles.ricovero_panel,'Visible','off');
set(handles.modifpanel,'Visible','off');
guidata(hObject, handles);

% --- Executes on button press in acquisizioni_pushbutton.
function acquisizioni_pushbutton_Callback(hObject, eventdata, handles)
% hObject    handle to acquisizioni_pushbutton (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
set(handles.ricovero_panel,'Visible','off');
set(handles.acquisizioni,'Visible','on');
set(handles.intervento,'Visible','off');
set(handles.modifpanel,'Visible','off');
guidata(hObject, handles);


% --- Executes on button press in acquisitioninsert_pushbutton.
function acquisitioninsert_pushbutton_Callback(hObject, eventdata, handles)
% hObject    handle to acquisitioninsert_pushbutton (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
tablename = 'Misure';
colnames= {'DataAcquisizione','OraAcquisizione','LivTroponina','LivSodio','LivPotassio','LivCKMB','CF','DataRicovero','OraRicovero','DataEvento','OraEvento'};
insertdata_array={handles.dataacquisizione, handles.oraacquisizione, handles.troponina, handles.na, handles.potassio, handles.ckmb, handles.pat, handles.dataricovero, handles.oraricovero, handles.dataevento, handles.oraevento};
insertdata = cell2table(insertdata_array, 'VariableNames', colnames);

empty = cellfun('length', insertdata_array);

empty_c = find(empty(1:8) == 0);
display(empty_c)

if length(empty_c) == 0
   
    try
        fastinsert(handles.conn,tablename,colnames,insertdata)
        set(handles.warning, 'Visible', 'off');
        set(handles.warn, 'Visible', 'off');
        set(handles.acquisitioninsert_pushbutton,'BackgroundColor','green');
        
    catch
        set(handles.warning,'Visible','on');
        set(handles.warn,'Visible','on');
        set(handles.warn,'String','This acquisition has already been inserted');
    end

else
    set(handles.acquisitioninsert_pushbutton,'BackgroundColor','red'); 
    messaggio = strjust('Warning:');
    
    for i = 1 : length(empty_c)
    
        mes = controllocampivuoti(empty_c(i),0);
        messaggio = strjust(char(messaggio,mes),'center');
        display(messaggio)
    end
    
    set(handles.warn, 'String', messaggio);
    set(handles.warning, 'Visible', 'on');
    set(handles.warn, 'Visible', 'on');

end

guidata(hObject, handles);

function dataintervento_edit_Callback(hObject, eventdata, handles)
% hObject    handle to dataintervento_edit (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of dataintervento_edit as text
%        str2double(get(hObject,'String')) returns contents of dataintervento_edit as a double


% --- Executes during object creation, after setting all properties.
function dataintervento_edit_CreateFcn(hObject, eventdata, handles)
% hObject    handle to dataintervento_edit (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end



function oraintervento_edit_Callback(hObject, eventdata, handles)
% hObject    handle to oraintervento_edit (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of oraintervento_edit as text
%        str2double(get(hObject,'String')) returns contents of oraintervento_edit as a double
handles.oraintervento = get(handles.oraintervento_edit, 'String');

guidata(hObject, handles);


% --- Executes during object creation, after setting all properties.
function oraintervento_edit_CreateFcn(hObject, eventdata, handles)
% hObject    handle to oraintervento_edit (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end



function tipointervento_edit_Callback(hObject, eventdata, handles)
% hObject    handle to tipointervento_edit (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of tipointervento_edit as text
%        str2double(get(hObject,'String')) returns contents of tipointervento_edit as a double
handles.tipointervento = get(handles.tipointervento_edit, 'String');
guidata(hObject, handles);

% --- Executes during object creation, after setting all properties.
function tipointervento_edit_CreateFcn(hObject, eventdata, handles)
% hObject    handle to tipointervento_edit (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end



function farmaco_edit_Callback(hObject, eventdata, handles)
% hObject    handle to farmaco_edit (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of farmaco_edit as text
%        str2double(get(hObject,'String')) returns contents of farmaco_edit as a double
handles.farmaco = get(handles.farmaco_edit, 'String');
guidata(hObject, handles);

% --- Executes during object creation, after setting all properties.
function farmaco_edit_CreateFcn(hObject, eventdata, handles)
% hObject    handle to farmaco_edit (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end



function vasoculprit_edit_Callback(hObject, eventdata, handles)
% hObject    handle to vasoculprit_edit (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of vasoculprit_edit as text
%        str2double(get(hObject,'String')) returns contents of vasoculprit_edit as a double
handles.vasoculprit = get(handles.vasoculprit_edit, 'String');
guidata(hObject, handles);

% --- Executes during object creation, after setting all properties.
function vasoculprit_edit_CreateFcn(hObject, eventdata, handles)
% hObject    handle to vasoculprit_edit (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end


% --- Executes on button press in pushbutton7.
function pushbutton7_Callback(hObject, eventdata, handles)
% hObject    handle to pushbutton7 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)



function edit23_Callback(hObject, eventdata, handles)
% hObject    handle to dataintervento_edit (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of dataintervento_edit as text
%        str2double(get(hObject,'String')) returns contents of dataintervento_edit as a double


% --- Executes during object creation, after setting all properties.
function edit23_CreateFcn(hObject, eventdata, handles)
% hObject    handle to dataintervento_edit (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end



function edit24_Callback(hObject, eventdata, handles)
% hObject    handle to oraintervento_edit (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of oraintervento_edit as text
%        str2double(get(hObject,'String')) returns contents of oraintervento_edit as a double


% --- Executes during object creation, after setting all properties.
function edit24_CreateFcn(hObject, eventdata, handles)
% hObject    handle to oraintervento_edit (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end



function edit25_Callback(hObject, eventdata, handles)
% hObject    handle to tipointervento_edit (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of tipointervento_edit as text
%        str2double(get(hObject,'String')) returns contents of tipointervento_edit as a double


% --- Executes during object creation, after setting all properties.
function edit25_CreateFcn(hObject, eventdata, handles)
% hObject    handle to tipointervento_edit (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end



function edit26_Callback(hObject, eventdata, handles)
% hObject    handle to farmaco_edit (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of farmaco_edit as text
%        str2double(get(hObject,'String')) returns contents of farmaco_edit as a double


% --- Executes during object creation, after setting all properties.
function edit26_CreateFcn(hObject, eventdata, handles)
% hObject    handle to farmaco_edit (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end



function edit27_Callback(hObject, eventdata, handles)
% hObject    handle to vasoculprit_edit (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of vasoculprit_edit as text
%        str2double(get(hObject,'String')) returns contents of vasoculprit_edit as a double


% --- Executes during object creation, after setting all properties.
function edit27_CreateFcn(hObject, eventdata, handles)
% hObject    handle to vasoculprit_edit (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end


% --- Executes on button press in insert_pushbutton.
function insert_pushbutton_Callback(hObject, eventdata, handles)
% hObject    handle to insert_pushbutton (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)


% --- Executes on button press in surgeryinsert_pushbutton.
function surgeryinsert_pushbutton_Callback(hObject, eventdata, handles)
% hObject    handle to surgeryinsert_pushbutton (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
tablename='Intervento';
colnames= {'DataIntervento','OraIntervento','TipoIntervento','Farmaco','Vasoculprit','CF','DataEvento','OraEvento','DataRicovero','OraRicovero'};

insertdata_array = {handles.dataintervento, handles.oraintervento, handles.tipointervento, handles.farmaco, handles.vasoculprit,handles.pat,handles.dataevento,handles.oraevento,handles.dataricovero,handles.oraricovero};
insertdata = cell2table(insertdata_array, 'VariableNames', colnames);

empty = cellfun('length', insertdata_array);

empty_c = find(empty(1:7) == 0);

if length(empty_c) == 0
   fastinsert(handles.conn,tablename,colnames,insertdata)
   set(handles.warning, 'Visible', 'off');
   set(handles.warn, 'Visible', 'off');
   set(handles.surgeryinsert_pushbutton,'BackgroundColor','green');
else
     
    messaggio = strjust('Warning:');
    
    for i = 1 : length(empty_c)
    
        mes = controllocampivuoti(empty_c(i),1);
        messaggio = strjust(char(messaggio,mes),'center');
        
    end
    set(handles.surgeryinsert_pushbutton,'BackgroundColor','red');
    set(handles.warn, 'String', messaggio);
    set(handles.warning, 'Visible', 'on');
    set(handles.warn, 'Visible', 'on');

end

guidata(hObject, handles);


function edit35_Callback(hObject, eventdata, handles)
% hObject    handle to vasoculprit_edit (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of vasoculprit_edit as text
%        str2double(get(hObject,'String')) returns contents of vasoculprit_edit as a double


% --- Executes during object creation, after setting all properties.
function edit35_CreateFcn(hObject, eventdata, handles)
% hObject    handle to vasoculprit_edit (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end



function edit36_Callback(hObject, eventdata, handles)
% hObject    handle to farmaco_edit (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of farmaco_edit as text
%        str2double(get(hObject,'String')) returns contents of farmaco_edit as a double


% --- Executes during object creation, after setting all properties.
function edit36_CreateFcn(hObject, eventdata, handles)
% hObject    handle to farmaco_edit (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end



function edit37_Callback(hObject, eventdata, handles)
% hObject    handle to tipointervento_edit (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of tipointervento_edit as text
%        str2double(get(hObject,'String')) returns contents of tipointervento_edit as a double


% --- Executes during object creation, after setting all properties.
function edit37_CreateFcn(hObject, eventdata, handles)
% hObject    handle to tipointervento_edit (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end



function edit38_Callback(hObject, eventdata, handles)
% hObject    handle to oraintervento_edit (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of oraintervento_edit as text
%        str2double(get(hObject,'String')) returns contents of oraintervento_edit as a double


% --- Executes during object creation, after setting all properties.
function edit38_CreateFcn(hObject, eventdata, handles)
% hObject    handle to oraintervento_edit (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end



function dataintervento_pushbutton_Callback(hObject, eventdata, handles)
% hObject    handle to dataintervento_pushbutton (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of dataintervento_pushbutton as text
%        str2double(get(hObject,'String')) returns contents of dataintervento_pushbutton as a double
uicalendar('DestinationUI', handles.dataintervento_pushbutton);
waitfor(handles.dataintervento_pushbutton,'String'); 
handles.dataintervento  = get(handles.dataintervento_pushbutton,'String');
data = datetime(handles.dataintervento);
if isempty(data) == 1
    set(handles.dataintervento_pushbutton, 'String', 'Wrn: please select Year - Month -- Day')
else
    handles.dataintervento  = get(handles.dataintervento_pushbutton,'String');
end
%display(handles.datadinascita);
guidata(hObject, handles);

% --- Executes during object creation, after setting all properties.
function dataintervento_pushbutton_CreateFcn(hObject, eventdata, handles)
% hObject    handle to dataintervento_pushbutton (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end

function message = controllocampivuoti(index, b)


    switch index
    case  1
        if b== 0
            message ='Please Select an Acquisition Date';
        elseif b== 1
            message = 'Please select Surgery Date'; 
        elseif b== 2
            message = 'Please select Event Date';
        end
    case  2
        if b== 0
            message = 'Please insert Acquisition Time';
        elseif b== 1
            message = 'Please insert Surgery Time';
        elseif b== 2
            message = 'Please insert Event Time';
        end
    case  3
        if b== 0
            message = 'Please insert cTnT Level';
        elseif b== 1
            message= 'Please insert Type of surgery';
        elseif b== 2 
            message = 'Please select Hospitalization Date';
        end
    case 4
        if b== 0 
            message= 'Please insert Na Level';
        elseif b== 1
            message = 'Please insert Drug';
        elseif b== 2
            message = 'Please insert Hospitalization Time';
        end
    case 5
        if  b== 0
            message = 'Please insert a K Level';
        elseif b== 1
            message = 'Please insert Vasoculprit';
        elseif b== 2
            message = 'Please insert First Medical Contact';
        end
         
    case 6
        message = 'Please insert a CK-MB Level';
    case 7
        if b == 1
            message = 'Select a Hospitalization to continue';
        elseif b  == 0         
            message = 'Select patient';
        end
        
    otherwise
        
        message = 'Select a Hospitalization to continue';
 
       
    end
       
function warn_Callback(hObject, eventdata, handles)
% hObject    handle to warn (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of warn as text
%        str2double(get(hObject,'String')) returns contents of warn as a double


% --- Executes during object creation, after setting all properties.
function warn_CreateFcn(hObject, eventdata, handles)
% hObject    handle to warn (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end


% --- Executes on button press in ok_pushbutton.
function ok_pushbutton_Callback(hObject, eventdata, handles)
% hObject    handle to ok_pushbutton (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
set(handles.warning,'Visible','off');
guidata(hObject, handles);


% --- Executes on button press in refresh_pushbutton.
function refresh_pushbutton_Callback(hObject, eventdata, handles)
% hObject    handle to refresh_pushbutton (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

set(handles.acquisitioninsert_pushbutton,'BackgroundColor','white');
set(handles.surgeryinsert_pushbutton,'BackgroundColor','white');
set(handles.insertricovero_pushbutton,'BackgroundColor','white');
set(handles.dataacquisizione_pushbutton,'String','Select Date');
set(handles.oraacquisizione_edit,'String','');
set(handles.troponina_edit,'String','');
set(handles.na_edit,'String','');
set(handles.potassio_edit,'String','');
set(handles.ckmb_edit,'String','');

set(handles.dataintervento_pushbutton,'String','Select Date');
set(handles.oraintervento_edit,'String','');
set(handles.tipointervento_edit,'String','');
set(handles.farmaco_edit,'String','');
set(handles.vasoculprit_edit,'String','');

set(handles.dataevento_pushbutton,'String','Select Date');
set(handles.oraevento_edit,'String','');
set(handles.dataricovero_pushbutton,'String','');
set(handles.oraricovero_edit,'String','');
set(handles.primocontattomedico_pushbutton,'String','');


handles.dataacquisizione = '';
handles.oraacquisizione = '';
handles.troponina = '';
handles.na = '';
handles.potassio = '';
handles.ckmb = '';

handles.dataintervento = '';
handles.oraintervento = '';
handles.tipointervento = '';
handles.farmaco = '';
handles.vasoculprit = '';

handles.dataricovero='';
handles.oraricovero='';
handles.oraevento='';
handles.dataevento='';

handles.primocontattomedico='';

guidata(hObject, handles);




% --- Executes on button press in ricovero_pushbutton.
function ricovero_pushbutton_Callback(hObject, eventdata, handles)
% hObject    handle to ricovero_pushbutton (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
set(handles.ricovero_panel,'Visible','on');
set(handles.intervento,'Visible','off');
set(handles.acquisizioni,'Visible','off');
set(handles.modifpanel,'Visible','off');
guidata(hObject, handles);

% --- Executes on button press in insertricovero_pushbutton.
function insertricovero_pushbutton_Callback(hObject, eventdata, handles)
% hObject    handle to insertricovero_pushbutton (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
tablename='Ricovero';
colnames= {'DataEvento','OraEvento','DataRicovero','OraRicovero','PrimoContattoMedico','CF'};

insertdata_array = {handles.dataevento, handles.oraevento, handles.dataricovero, handles.oraricovero, handles.primocontattomedico, handles.pat};
insertdata = cell2table(insertdata_array, 'VariableNames', colnames);
empty = cellfun('length', insertdata_array);

empty_c = find(empty == 0);

if length(empty_c) == 0
   
    try
        fastinsert(handles.conn,tablename,colnames,insertdata);
        set(handles.warning, 'Visible', 'off');
        set(handles.warn, 'Visible', 'off');
        set(handles.insertricovero_pushbutton,'BackgroundColor','green');
        
    catch
        set(handles.warning,'Visible','on');
        set(handles.warn,'Visible','on');
        set(handles.warn,'String','This H.admission has already been inserted');
    end

else
    set(handles.insertricovero_pushbutton,'BackgroundColor','red'); 
    messaggio = strjust('Warning:');
    
    for i = 1 : length(empty_c)
    
        mes = controllocampivuoti(empty_c(i),2);
        messaggio = strjust(char(messaggio,mes),'center');
        
    end
    
    set(handles.warn, 'String', messaggio);
    set(handles.warning, 'Visible', 'on');
    set(handles.warn, 'Visible', 'on');

end

guidata(hObject, handles);
% --- Executes on button press in primocontattomedico_pushbutton.
function primocontattomedico_pushbutton_Callback(hObject, eventdata, handles)
% hObject    handle to primocontattomedico_pushbutton (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
uicalendar('DestinationUI', handles.primocontattomedico_pushbutton);
waitfor(handles.primocontattomedico_pushbutton,'String'); 
handles.primocontattomedico = get(handles.primocontattomedico_pushbutton,'String');
data = datetime(handles.primocontattomedico);
if isempty(data) == 1
    set(handles.primocontattomedico_pushbutton, 'String', 'Wrn: please select Year - Month -- Day')
else
    handles.primocontattomedico  = get(handles.primocontattomedico_pushbutton,'String');
end

guidata(hObject, handles);



function oraricovero_edit_Callback(hObject, eventdata, handles)
% hObject    handle to oraricovero_edit (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of oraricovero_edit as text
%        str2double(get(hObject,'String')) returns contents of oraricovero_edit as a double
handles.oraricovero = get(handles.oraricovero_edit, 'String');
guidata(hObject, handles);


% --- Executes during object creation, after setting all properties.
function oraricovero_edit_CreateFcn(hObject, eventdata, handles)
% hObject    handle to oraricovero_edit (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end





% --- Executes during object creation, after setting all properties.
function ospedalizzazione_edit_CreateFcn(hObject, eventdata, handles)
% hObject    handle to ospedalizzazione_edit (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end


% --- Executes on button press in dataricovero_pushbutton.
function dataricovero_pushbutton_Callback(hObject, eventdata, handles)
% hObject    handle to dataricovero_pushbutton (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
uicalendar('DestinationUI', handles.dataricovero_pushbutton);
waitfor(handles.dataricovero_pushbutton,'String'); 
handles.dataricovero = get(handles.dataricovero_pushbutton,'String');
data = datetime(handles.dataricovero);
if isempty(data) == 1
    set(handles.dataricovero_pushbutton, 'String', 'Wrn: please select Year - Month -- Day')
else
    handles.dataricovero  = get(handles.dataricovero_pushbutton,'String');
end

guidata(hObject, handles);


function oraevento_edit_Callback(hObject, eventdata, handles)
% hObject    handle to oraevento_edit (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of oraevento_edit as text
%        str2double(get(hObject,'String')) returns contents of oraevento_edit as a double
handles.oraevento = get(handles.oraevento_edit, 'String');
guidata(hObject, handles);


% --- Executes during object creation, after setting all properties.
function oraevento_edit_CreateFcn(hObject, eventdata, handles)
% hObject    handle to oraevento_edit (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end


% --- Executes on button press in dataevento_pushbutton.
function dataevento_pushbutton_Callback(hObject, eventdata, handles)
% hObject    handle to dataevento_pushbutton (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
uicalendar('DestinationUI', handles.dataevento_pushbutton);
waitfor(handles.dataevento_pushbutton,'String'); 
handles.dataevento = get(handles.dataevento_pushbutton,'String');
data = datetime(handles.dataevento);
if isempty(data) == 1
    set(handles.dataevento_pushbutton, 'String', 'Wrn: please select Year - Month -- Day')
else
    handles.evento  = get(handles.dataevento_pushbutton,'String');
end

guidata(hObject, handles);


% --- Executes on button press in ModifyDataButton.
function ModifyDataButton_Callback(hObject, eventdata, handles)
% hObject    handle to ModifyDataButton (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

set(handles.ricovero_panel,'Visible','off');
set(handles.intervento,'Visible','off');
set(handles.acquisizioni,'Visible','off');
set(handles.modifpanel,'Visible','on');

paziente = handles.pat;
ricovero = handles.dataricovero;



if isempty(ricovero)  
    
    set(handles.warn, 'String', 'Please select a patient and his/her hospitalization');
    set(handles.warning, 'Visible', 'on');
    set(handles.warn, 'Visible', 'on');
    set(handles.modifpanel, 'visible', 'off');
else
    
    set(handles.warning, 'Visible', 'off');
    set(handles.warn, 'Visible', 'off');
    set(handles.modifpanel, 'visible', 'on');
    
    sqlqery= strcat('SELECT DataAcquisizione, OraAcquisizione, LivTroponina, LivSodio, LivPotassio, LivCKMB FROM misure WHERE CF  = "', paziente,'" and DataRicovero = "', char(string(ricovero)), '"');

    curs = exec(handles.conn, sqlqery);
    curs = fetch(curs);
    handles.patModif = curs.Data;
    
    DataOra = cellstr(curs.Data);
    DataOraPopM = strcat(DataOra(:,1),{' '}, DataOra(:,2));

    set(handles.selectacquisition,'String', DataOraPopM);

end
guidata(hObject, handles);

% --- Executes on selection change in selectacquisition.
function selectacquisition_Callback(hObject, eventdata, handles)
% hObject    handle to selectacquisition (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

indexdata= get(handles.selectacquisition, 'Value');
set(handles.ctntMod, 'String', handles.patModif(indexdata, 3));
set(handles.naMod, 'String', handles.patModif(indexdata, 4));
set(handles.ckmbMod, 'String', handles.patModif(indexdata, 6));
set(handles.kMod, 'String', handles.patModif(indexdata, 5));
handles.acquisizioneSelezionata = indexdata;
set(handles.UpPush,'BackgroundColor','w');
guidata(hObject, handles);

% --- Executes during object creation, after setting all properties.
function selectacquisition_CreateFcn(hObject, eventdata, handles)
% hObject    handle to selectacquisition (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: popupmenu controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end



function timeMod_Callback(hObject, eventdata, handles)
% hObject    handle to timeMod (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of timeMod as text
%        str2double(get(hObject,'String')) returns contents of timeMod as a double


% --- Executes during object creation, after setting all properties.
function timeMod_CreateFcn(hObject, eventdata, handles)
% hObject    handle to timeMod (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end



function ctntMod_Callback(hObject, eventdata, handles)
% hObject    handle to ctntMod (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of ctntMod as text
%        str2double(get(hObject,'String')) returns contents of ctntMod as a double


% --- Executes during object creation, after setting all properties.
function ctntMod_CreateFcn(hObject, eventdata, handles)
% hObject    handle to ctntMod (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end



function ckmbMod_Callback(hObject, eventdata, handles)
% hObject    handle to ckmbMod (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of ckmbMod as text
%        str2double(get(hObject,'String')) returns contents of ckmbMod as a double


% --- Executes during object creation, after setting all properties.
function ckmbMod_CreateFcn(hObject, eventdata, handles)
% hObject    handle to ckmbMod (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end



function naMod_Callback(hObject, eventdata, handles)
% hObject    handle to naMod (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of naMod as text
%        str2double(get(hObject,'String')) returns contents of naMod as a double


% --- Executes during object creation, after setting all properties.
function naMod_CreateFcn(hObject, eventdata, handles)
% hObject    handle to naMod (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end



function kMod_Callback(hObject, eventdata, handles)
% hObject    handle to kMod (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of kMod as text
%        str2double(get(hObject,'String')) returns contents of kMod as a double


% --- Executes during object creation, after setting all properties.
function kMod_CreateFcn(hObject, eventdata, handles)
% hObject    handle to kMod (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end


% --- Executes on button press in UpPush.
function UpPush_Callback(hObject, eventdata, handles)
% hObject    handle to UpPush (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
paziente = handles.pat;
ricovero = handles.dataricovero;
ind = handles.acquisizioneSelezionata;

tablename= 'misure';
colnames={'LivTroponina','LivSodio','LivPotassio','LivCKMB'};
whereclause = strcat('WHERE CF= "', paziente,'" AND DataRicovero = "', char(string(ricovero)),'" AND DataAcquisizione = "', char(string(handles.patModif(ind, 1))),'" and OraAcquisizione = "', char(string(handles.patModif(ind, 2))),'"');
ctnt= num2str(char(get(handles.ctntMod,'String')));
na = num2str(char(get(handles.naMod,'String')));
k= num2str(char(get(handles.kMod,'String')));
ckmb= num2str(char(get(handles.ckmbMod,'String')));

exdata(1,1:4)= {ctnt, na, k, ckmb};
update(handles.conn,tablename,colnames,exdata,whereclause)
set(handles.UpPush,'BackgroundColor','green');

guidata(hObject, handles);


% --- Executes on button press in timibutton.
function timibutton_Callback(hObject, eventdata, handles)
% hObject    handle to timibutton (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

run('Timi.m')
guidata(hObject, handles);
